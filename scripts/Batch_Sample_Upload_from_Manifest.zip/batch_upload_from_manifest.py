#!/usr/bin/env python3
import argparse
import csv
import os
import subprocess
import sys
from datetime import datetime

def to_bool(s) -> bool:
    if s is None:
        return False
    s = str(s).strip().lower()
    return s in ("1", "true", "t", "yes", "y")

def add_arg(cmd, flag, value):
    """Append CLI arg if value is non-empty."""
    if value is None:
        return
    v = str(value).strip()
    if v == "":
        return
    cmd.extend([flag, v])

def require_file(path: str, label: str):
    if not path:
        return
    if not os.path.exists(path):
        raise FileNotFoundError(f"{label} not found: {path}")

def tail(s: str, n: int = 800) -> str:
    s = s or ""
    return s[-n:] if len(s) > n else s

def main():
    ap = argparse.ArgumentParser(description="Batch upload Geneyx samples using ga_uploadSample.py + manifest.tsv")
    ap.add_argument("--manifest", default="manifest.tsv", help="Path to manifest TSV")
    ap.add_argument("--config", default="ga.config.yml", help="Path to ga.config.yml")
    ap.add_argument("--uploader", default="ga_uploadSample.py", help="Path to ga_uploadSample.py")
    ap.add_argument("--python", default="python3", help="Python executable to use (python3 or python)")
    ap.add_argument("--log", default="upload_results.csv", help="CSV log output")
    ap.add_argument("--stop-on-fail", action="store_true", help="Stop batch on first failure")
    args = ap.parse_args()

    if not os.path.exists(args.manifest):
        print(f"Manifest not found: {args.manifest}", file=sys.stderr)
        sys.exit(2)

    # Map manifest columns -> uploader CLI flags
    # Column names should match the arg names without leading "--"
    cli_fields = [
        # Files
        ("snvVcf", "--snvVcf"),
        ("svVcf", "--svVcf"),
        ("cnvVcf", "--cnvVcf"),

        # Sample
        ("sampleId", "--sampleId"),
        ("sampleTakenDate", "--sampleTakenDate"),
        ("sampleSequenceDate", "--sampleSequenceDate"),
        ("sampleReceiveDate", "--sampleReceiveDate"),
        ("sampleType", "--sampleType"),
        ("sampleTarget", "--sampleTarget"),
        ("sampleSource", "--sampleSource"),
        ("seqMachineId", "--seqMachineId"),
        ("kitId", "--kitId"),
        ("genomeBuild", "--genomeBuild"),
        ("sampleNotes", "--sampleNotes"),
        ("sampleQcData", "--sampleQcData"),
        ("sampleAdvAnalysis", "--sampleAdvAnalysis"),
        ("excludeFromLAF", "--excludeFromLAF"),
        ("sampleRelation", "--sampleRelation"),
        ("bamUrl", "--bamUrl"),
        ("localBamUrl", "--localBamUrl"),
        ("methylationUrl", "--methylationUrl"),
        ("localMethylationUrl", "--localMethylationUrl"),

        # Patient
        ("patientId", "--patientId"),
        ("patientName", "--patientName"),
        ("patientGender", "--patientGender"),
        ("patientDateOfBirth", "--patientDateOfBirth"),
        ("patientConsanguinity", "--patientConsanguinity"),
        ("patientPopulationType", "--patientPopulationType"),
        ("patientPaternalAncestry", "--patientPaternalAncestry"),
        ("patientMaternalAncestry", "--patientMaternalAncestry"),
        ("patientFamilyHistory", "--patientFamilyHistory"),
        ("patientHasBioSample", "--patientHasBioSample"),
        ("patientUseConsentPersonal", "--patientUseConsentPersonal"),
        ("patientUseConsentClinical", "--patientUseConsentClinical"),

        # Assignment
        ("groupAssignmentCode", "--groupAssignmentCode"),
        ("groupAssignmentName", "--groupAssignmentName"),

        # Account override
        ("customerAccountKey", "--customerAccountKey"),
    ]

    # Write a simple results log (append-safe)
    log_exists = os.path.exists(args.log)
    with open(args.log, "a", newline="", encoding="utf-8") as logf:
        logw = csv.DictWriter(
            logf,
            fieldnames=[
                "timestamp",
                "patientId",
                "sampleId",
                "genomeBuild",
                "sampleTarget",
                "kitId",
                "snvVcf",
                "svVcf",
                "cnvVcf",
                "returncode",
                "status",
                "stdout_tail",
                "stderr_tail",
            ],
        )
        if not log_exists:
            logw.writeheader()

        with open(args.manifest, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f, delimiter="\t")

            # Minimal columns to run an upload (based on your current process)
            required_cols = ["patientId", "genomeBuild", "sampleTarget", "kitId", "snvVcf"]
            for col in required_cols:
                if col not in (reader.fieldnames or []):
                    raise ValueError(f"Manifest missing required column: {col}")

            for i, row in enumerate(reader, start=1):
                patientId = (row.get("patientId") or "").strip()
                sampleId = (row.get("sampleId") or "").strip()

                snvVcf = (row.get("snvVcf") or "").strip()
                svVcf  = (row.get("svVcf") or "").strip()
                cnvVcf = (row.get("cnvVcf") or "").strip()

                # Skip blank lines
                if not patientId and not snvVcf and not svVcf and not cnvVcf:
                    continue

                try:
                    # Validate file paths if provided
                    require_file(snvVcf, "snvVcf")
                    require_file(svVcf, "svVcf")
                    require_file(cnvVcf, "cnvVcf")

                    cmd = [args.python, args.uploader, "--config", args.config]

                    # Add all supported fields
                    for col, flag in cli_fields:
                        add_arg(cmd, flag, row.get(col))

                    # Boolean flag
                    if to_bool(row.get("skipAnnotation")):
                        cmd.append("--skipAnnotation")

                    print(f"\n[{i}] Uploading patientId={patientId} sampleId={sampleId or '(auto)'}")
                    p = subprocess.run(cmd, capture_output=True, text=True)

                    stdout = (p.stdout or "").strip()
                    stderr = (p.stderr or "").strip()
                    status = "SUCCESS" if p.returncode == 0 else "FAIL"

                    logw.writerow(
                        {
                            "timestamp": datetime.utcnow().isoformat() + "Z",
                            "patientId": patientId,
                            "sampleId": sampleId,
                            "genomeBuild": (row.get("genomeBuild") or "").strip(),
                            "sampleTarget": (row.get("sampleTarget") or "").strip(),
                            "kitId": (row.get("kitId") or "").strip(),
                            "snvVcf": snvVcf,
                            "svVcf": svVcf,
                            "cnvVcf": cnvVcf,
                            "returncode": p.returncode,
                            "status": status,
                            "stdout_tail": tail(stdout),
                            "stderr_tail": tail(stderr),
                        }
                    )
                    logf.flush()

                    # Echo key output to console
                    if stdout:
                        print(stdout)
                    if stderr:
                        print(stderr, file=sys.stderr)

                    if p.returncode != 0 and args.stop_on_fail:
                        print("Stopping on first failure (--stop-on-fail).", file=sys.stderr)
                        sys.exit(p.returncode)

                except Exception as e:
                    # Log manifest/validation errors as FAIL rows
                    logw.writerow(
                        {
                            "timestamp": datetime.utcnow().isoformat() + "Z",
                            "patientId": patientId,
                            "sampleId": sampleId,
                            "genomeBuild": (row.get("genomeBuild") or "").strip(),
                            "sampleTarget": (row.get("sampleTarget") or "").strip(),
                            "kitId": (row.get("kitId") or "").strip(),
                            "snvVcf": snvVcf,
                            "svVcf": svVcf,
                            "cnvVcf": cnvVcf,
                            "returncode": 99,
                            "status": "FAIL",
                            "stdout_tail": "",
                            "stderr_tail": str(e),
                        }
                    )
                    logf.flush()
                    print(f"[{i}] FAIL patientId={patientId} — {e}", file=sys.stderr)
                    if args.stop_on_fail:
                        sys.exit(99)

    print(f"\nDone. Results log: {args.log}")

if __name__ == "__main__":
    main()
