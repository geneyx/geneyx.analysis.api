Geneyx Batch Sample Uploader

This tool enables batch uploading of genomic samples into Geneyx using a TSV manifest and the existing ga_uploadSample.py uploader script.

It wraps the uploader in a safe, repeatable workflow with:

Manifest-driven inputs

Optional metadata support (sample + patient)

Automatic file validation

CSV logging of results

Optional stop-on-failure behavior

Files in This Package
File	Purpose
batch_upload_samples.py	Main batch runner (this script)
manifest.tsv	Input manifest listing samples + metadata
ga_uploadSample.py	Geneyx sample uploader (provided by Geneyx)
ga.config.yml	API credentials & environment config
upload_results.csv	Auto-generated upload log
Requirements

Python 3.8+

Geneyx uploader dependencies (same environment as ga_uploadSample.py)

Access to Geneyx Analysis API

Valid VCF files (SNV required; SV/CNV optional)

Quick Start
python batch_upload_samples.py \
  --manifest manifest.tsv \
  --config ga.config.yml


Optional flags:

--log upload_results.csv     # Output log file
--stop-on-fail               # Stop batch on first failure
--python python3             # Python executable to use

Manifest Format

File: manifest.tsv

Delimiter: TAB (not commas)

One row per sample

Empty fields are allowed (they will be skipped)

Required Columns

These must exist in the header (values may be empty if not required for a specific sample):

Column	Description
patientId	Patient identifier
genomeBuild	hg19 or hg38
sampleTarget	WholeGenome / Exome / GenePanel / etc
kitId	Enrichment kit ID
snvVcf	Path to SNV VCF file
Full Manifest Columns
patientId
patientName
patientGender
patientDateOfBirth
patientConsanguinity
patientPopulationType
patientPaternalAncestry
patientMaternalAncestry
patientFamilyHistory
patientHasBioSample
patientUseConsentPersonal
patientUseConsentClinical
sampleId
sampleTakenDate
sampleSequenceDate
sampleReceiveDate
sampleType
sampleTarget
sampleSource
seqMachineId
kitId
genomeBuild
sampleNotes
sampleQcData
sampleAdvAnalysis
excludeFromLAF
sampleRelation
bamUrl
localBamUrl
methylationUrl
localMethylationUrl
groupAssignmentCode
groupAssignmentName
snvVcf
svVcf
cnvVcf
customerAccountKey
skipAnnotation


Column names must exactly match the uploader CLI arguments (without --).

Example Manifest Row
patientId	sampleId	genomeBuild	sampleTarget	kitId	snvVcf	svVcf	cnvVcf	skipAnnotation
P12345	S12345	hg38	WholeGenome	Genome	/data/sample.snv.vcf.gz	/data/sample.sv.vcf.gz		yes

File Handling Rules

snvVcf must exist

svVcf and cnvVcf are optional but validated if provided

Local BAM / methylation files are not validated (passed as-is)

Boolean Fields

These fields accept any of the following values:

true / false
yes / no
1 / 0

Field	Behavior
skipAnnotation	Passed as a flag (--skipAnnotation)
Others	Passed as string values to uploader
Logging & Results

Each run appends to upload_results.csv:

Column	Meaning
timestamp	UTC time of upload
patientId	Patient ID
sampleId	Sample ID
snvVcf / svVcf / cnvVcf	File paths
returncode	Exit code
status	SUCCESS / FAIL
stdout_tail	Last output from uploader
stderr_tail	Error details
Error Handling

Missing or invalid files cause the row to fail

Errors are logged to CSV

Batch continues unless --stop-on-fail is set

Common Issues
“Manifest missing required column”

Ensure:

Tabs (not spaces or commas)

Correct header spelling

“File not found”

Verify absolute paths or relative paths from execution directory.

Upload succeeds but no annotation

Check skipAnnotation column — it may be set to true.

Recommended Workflow

Copy manifest.tsv template

Fill required fields first

Validate file paths

Run batch uploader

Review upload_results.csv

Re-run failed rows only

Optional Enhancements (Not Yet Enabled)

--dry-run mode (print commands only)

Auto-unification of SV/CNV/Repeat files

Parallel uploads

Per-row retry logic

Support

For Geneyx-specific questions or API issues, contact your Geneyx representative.