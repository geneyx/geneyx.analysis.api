
import pandas as pd
import numpy as np
import os

def parse_mapview(mapview_str):
    try:
        chrom_part, pos_part = str(mapview_str).split('-')
        chrom = f"chr{int(chrom_part)}"
        pos = int(pos_part.replace(',', '')) * 1000
        return chrom, pos
    except Exception:
        return None, None

def process_excel_to_vcf(file_path, output_dir):
    xls = pd.ExcelFile(file_path)
    raw_df = pd.read_excel(xls, sheet_name=xls.sheet_names[0], header=None)

    header = raw_df.iloc[4]
    df = raw_df.iloc[12:].copy()
    df.columns = header
    df.reset_index(drop=True, inplace=True)

    if 'Mapview (hg38) in kb' not in df.columns:
        raise ValueError("Expected column 'Mapview (hg38) in kb' not found. Please check file structure.")

    df[['Chromosome', 'Position']] = df['Mapview (hg38) in kb'].apply(
        lambda x: pd.Series(parse_mapview(x)))
    df = df[df['Chromosome'].notna() & df['Position'].notna()]

    sample_columns = df.columns[12:]
    os.makedirs(output_dir, exist_ok=True)

    for sample in sample_columns:
        df['Value'] = pd.to_numeric(df[sample], errors='coerce')
        df['CNV_Type'] = np.where(df['Value'] < 0.6, 'DEL',
                           np.where(df['Value'] > 1.3, 'DUP', 'NORMAL'))
        df['Gene_Chr'] = df['Gene'].astype(str) + "_" + df['Chromosome'].astype(str)
        cnv_only = df[df['CNV_Type'] != 'NORMAL'].copy()
        cnv_only = cnv_only.sort_values(by=['Gene_Chr', 'Position'])

        grouped_events = []
        prev_gene_chr, prev_type, prev_end = None, None, None
        group = []

        for _, row in cnv_only.iterrows():
            gene_chr = row['Gene_Chr']
            cnv_type = row['CNV_Type']
            pos = row['Position']

            if (gene_chr == prev_gene_chr) and (cnv_type == prev_type) and (prev_end is not None and pos <= prev_end + 5000):
                group.append(row)
            else:
                if group:
                    grouped_events.append(group)
                group = [row]
            prev_gene_chr, prev_type, prev_end = gene_chr, cnv_type, pos

        if group:
            grouped_events.append(group)

        vcf_lines = [
            "##fileformat=VCFv4.2",
            "##INFO=<ID=SVLEN,Number=1,Type=Integer,Description=\"Length of structural variant\">",
            "##INFO=<ID=SVTYPE,Number=1,Type=String,Description=\"Type of structural variant\">",
            "##INFO=<ID=END,Number=1,Type=Integer,Description=\"End position of structural variant\">",
            "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\t" + sample
        ]

        for g in grouped_events:
            g_df = pd.DataFrame(g)
            chrom = g_df['Chromosome'].iloc[0]
            start = g_df['Position'].min()
            end = g_df['Position'].max() + 1000
            svlen = end - start
            cnv_type = g_df['CNV_Type'].iloc[0]
            alt = "<DEL>" if cnv_type == 'DEL' else "<DUP>"
            cn = round(g_df['Value'].mean(), 2)
            info = f"SVLEN={svlen};SVTYPE=CNV;END={end}"
            line = f"{chrom}\t{start}\t.\tN\t{alt}\t100\tPASS\t{info}\tCN\t{cn}"
            vcf_lines.append(line)

        vcf_path = os.path.join(output_dir, f"{sample}.vcf")
        with open(vcf_path, 'w') as f:
            f.write("\n".join(vcf_lines))

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python mlpa_to_vcf.py <input_excel_file> <output_directory>")
    else:
        process_excel_to_vcf(sys.argv[1], sys.argv[2])
