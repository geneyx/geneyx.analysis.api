# Geneyx to HL7 Report Integration

This tool automates the process of retrieving genomic report PDFs from Geneyx, encoding them in HL7 `ORU^R01` messages, and (optionally) sending them to a SoftComputer (SCC) HL7 interface.

---

## ✅ Features

- Retrieve signed Geneyx report download links via API
- Download PDF reports
- Base64-encode and embed PDFs into HL7 OBX segments (chunked if needed)
- Generates HL7 `ORU^R01` messages (HL7 v2.5)
- Optionally sends HL7 messages via MLLP
- Includes retry logic and error logging

---

## 📁 Files Required

### `cases.csv` (or custom input)
A CSV file with the following headers:

caseSn,patientId,patientName
EG230329072009 - Copy,123456,Jane Smith


### `.env`
Contains Geneyx API credentials:
API_USER_ID=your_api_user_id
API_USER_KEY=your_api_user_key


---

## 🚀 Usage

### 1. Install dependencies
```bash
pip install requests python-dotenv

python GeneyxHL7.py [optional_input_csv]


 Output
downloads/: Contains all PDF and .hl7 files

error_log.txt: Logs any failed cases or retries