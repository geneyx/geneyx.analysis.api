import os
import csv
import base64
import datetime
import requests
import socket
import time
from dotenv import load_dotenv

load_dotenv()
API_USER_ID = os.getenv("API_USER_ID")
API_USER_KEY = os.getenv("API_USER_KEY")

MAX_RETRIES = 3
CHUNK_SIZE = 64000  # bytes for OBX-5 base64 split

def log_error(message):
    with open("error_log.txt", "a") as f:
        f.write(f"{datetime.datetime.now()}: {message}\n")

def retry_request(func, *args):
    for attempt in range(MAX_RETRIES):
        try:
            return func(*args)
        except Exception as e:
            log_error(f"Attempt {attempt+1} failed: {e}")
            time.sleep(2)
    return None

def get_report_file_name(case_sn):
    url = "https://analysis.geneyx.com/api/CaseReports"
    payload = {"caseSn": case_sn, "ApiUserId": API_USER_ID, "ApiUserKey": API_USER_KEY}
    r = requests.post(url, json=payload)
    r.raise_for_status()
    data = r.json()
    return data["Data"][0]["ReportFileUrl"] if data["Code"] == "success" else None

def get_download_url(file_name):
    url = "https://analysis.geneyx.com/api/ReportUrl"
    payload = {"fileName": file_name.strip(), "ApiUserId": API_USER_ID, "ApiUserKey": API_USER_KEY}
    r = requests.post(url, json=payload)
    r.raise_for_status()
    data = r.json()
    return data["Data"]["fileUrl"] if data["Code"] == "success" else None

def download_pdf(file_url, output_path):
    r = requests.get(file_url)
    r.raise_for_status()
    with open(output_path, "wb") as f:
        f.write(r.content)
    return output_path

def build_hl7_message_chunked(patient_id, patient_name, case_sn, pdf_path):
    with open(pdf_path, "rb") as f:
        encoded = base64.b64encode(f.read()).decode()

    timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M")
    patient_last, patient_first = (patient_name.split() + [""])[:2]

    segments = [
        f"MSH|^~\\&|GENEYX|LAB|SOFT|HOSPITAL|{timestamp}||ORU^R01|MSG{timestamp}|P|2.5",
        f"PID|||{patient_id}||{patient_last}^{patient_first}^^^^L||19800101|M",
        f"ORC|RE||{case_sn}",
        f"OBR|1||{case_sn}^LAB|81247-9^Genetic analysis summary^LN|||{timestamp}"
    ]

    chunks = [encoded[i:i + CHUNK_SIZE] for i in range(0, len(encoded), CHUNK_SIZE)]
    for i, chunk in enumerate(chunks, 1):
        segments.append(f"OBX|{i}|ED|PDF^Geneyx Genomic Report||^application/pdf^Base64^{chunk}||||||F")

    return "\r".join(segments)

def send_hl7_over_mllp(hl7_msg, host, port):
    START_BLOCK = b'\x0b'
    END_BLOCK = b'\x1c'
    CR = b'\x0d'
    message = START_BLOCK + hl7_msg.encode() + END_BLOCK + CR

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((host, port))
        s.sendall(message)
        ack = s.recv(4096)
        print("✅ HL7 ACK:", ack.decode())

def process_cases(input_csv="cases.csv", output_dir="downloads", send_hl7=False, hl7_host="localhost", hl7_port=2575):
    os.makedirs(output_dir, exist_ok=True)

    with open(input_csv, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            case_sn = row["caseSn"]
            patient_id = row["patientId"]
            patient_name = row["patientName"]

            try:
                print(f"\n🔄 Processing: {case_sn}")

                report_file = retry_request(get_report_file_name, case_sn)
                if not report_file:
                    raise Exception("Failed to get report file name.")

                file_url = retry_request(get_download_url, report_file)
                if not file_url:
                    raise Exception("Failed to get download URL.")

                local_pdf = os.path.join(output_dir, report_file.replace(" ", "_"))
                retry_request(download_pdf, file_url, local_pdf)

                hl7_msg = build_hl7_message_chunked(patient_id, patient_name, case_sn, local_pdf)

                hl7_path = os.path.join(output_dir, f"{case_sn.replace(' ', '_')}.hl7")
                with open(hl7_path, "w") as f:
                    f.write(hl7_msg)
                print(f"📄 HL7 saved: {hl7_path}")

                if send_hl7:
                    send_hl7_over_mllp(hl7_msg, hl7_host, hl7_port)

            except Exception as e:
                log_error(f"❌ Error on case {case_sn}: {e}")
                print(f"❌ Failed: {case_sn}")

    print("\n✅ Batch complete.")

if __name__ == "__main__":
    # To send via MLLP, set send_hl7=True and configure host/port
    process_cases(send_hl7=False)
