import pandas as pd
import sys

# Check for the correct number of arguments
if len(sys.argv) != 3:
    print("Usage: python convert_to_format.py <input_file> <output_file>")
    sys.exit(1)

input_file = sys.argv[1]
output_file = sys.argv[2]

try:
    # Read the input file
    data = pd.read_csv(input_file, sep='\t')

    # Function to calculate Size (kbp) from Size(bp)
    def calculate_size_kbp(size_bp):
        return size_bp / 1000 if pd.notna(size_bp) else None

    # Convert data to match the desired output format
    converted_data = {
        'Microarray Nomenclature': data.apply(lambda row: f"arr[GRCh37] {row['Chromosome']}p({row['Start']}_{row['Stop']})x{row['State']}", axis=1),
        'Use In Export': 'true',  # Assuming this is always 'true'
        'File': '',  # Add appropriate file name if needed
        'Type': data['Type'],
        'Chromosome': data['Chromosome'],
        'Cytoband Start': data['Start'],
        'Cytoband End': data['Stop'],
        'Tier or Score': data['Mean Log Ratio/LOH Score'],
        'Size (kbp)': data['Size(bp)'].apply(calculate_size_kbp),
        'Marker Count': data['#Probes'],
        'Call': '',  # Placeholder
        'Segment Interpretation': '',  # Placeholder
        'CN State': data['State'],
        'Genes': data['Gene Name'],
        'Evidence': '',  # Placeholder, you can add additional evidence information if available
        'Call From Prioritization': '',  # Placeholder
        'CytoRegions': '',  # Placeholder
        'Gene Count': data['Gene Name'].apply(lambda genes: len(genes.split(',')) if pd.notna(genes) else 0),
        'Full Location': data.apply(lambda row: f"chr{row['Chromosome']}:{row['Start']}-{row['Stop']}", axis=1),
        'OMIM ® Genes Count': data['Gene Name'].apply(lambda genes: len([g for g in genes.split(',') if 'OMIM' in g]) if pd.notna(genes) else 0),
        'OMIM ® Genes': '',  # Placeholder, you can add OMIM genes here if available
        'DB Count Both': 0,  # Placeholder, adjust as needed
        'Inheritance': '',  # Placeholder
        'Microarray Nomenclature (ISCN 2013)': data.apply(lambda row: f"arr[hg19] {row['Chromosome']}p({row['Start']}-{row['Stop']})x{row['State']}", axis=1),
        'Curation By': '',  # Placeholder
        'Materially Modified Segment': 'false',  # Assuming 'false' by default
    }

    # Convert to DataFrame for export
    converted_df = pd.DataFrame(converted_data)

    # Save the converted data to the output file
    converted_df.to_csv(output_file, sep='\t', index=False)
    print(f"Conversion complete. Output saved to {output_file}")

except Exception as e:
    print(f"An error occurred: {e}")
