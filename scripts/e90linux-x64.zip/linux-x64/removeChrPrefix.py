import pandas as pd
import sys
from io import StringIO

# Check if the correct number of arguments is provided
if len(sys.argv) != 3:
    print("Usage: python remove_chr_prefix.py <input_file> <output_file>")
    sys.exit(1)

input_file = sys.argv[1]
output_file = sys.argv[2]

try:
    # Read the file line by line to find the header start and footer end
    with open(input_file, 'r') as file:
        lines = file.readlines()
    
    # Find the header line (assuming data starts after "Chromosome" header line)
    start_line = None
    for i, line in enumerate(lines):
        if line.startswith("Chromosome"):
            start_line = i
            break

    if start_line is None:
        print("Error: 'Chromosome' header not found in the input file.")
        sys.exit(1)

    # Find the footer line (assuming it starts with "Number of calls per sample:")
    end_line = None
    for i, line in enumerate(lines[start_line:], start=start_line):
        if line.startswith("Number of calls per sample:"):
            end_line = i
            break

    # Extract only the relevant lines (after header, before footer)
    data_lines = lines[start_line:end_line] if end_line else lines[start_line:]

    # Load data into a DataFrame
    data = pd.read_csv(StringIO("".join(data_lines)), sep='\t')

    # Ensure Chromosome column is a string, strip whitespace, and remove 'chr' prefix if present
    if 'Chromosome' in data.columns:
        data['Chromosome'] = data['Chromosome'].astype(str).str.strip()
        data['Chromosome'] = data['Chromosome'].apply(lambda x: x[3:] if x.startswith('chr') else x)

        # Confirm the changes by printing the first few entries
        print("Preview of 'Chromosome' column after removing 'chr' prefix:")
        print(data['Chromosome'].head())
    else:
        print("Error: No 'Chromosome' column found in the input file.")
        sys.exit(1)

    # Save the modified data to the output file
    data.to_csv(output_file, sep='\t', index=False)
    print(f"'chr' prefix removed successfully. Output saved to {output_file}")

except Exception as e:
    print(f"An error occurred: {e}")
