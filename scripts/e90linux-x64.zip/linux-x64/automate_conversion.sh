#!/bin/bash

# Check if the correct number of arguments is provided
if [ "$#" -ne 2 ]; then
    echo "Usage: ./automate_conversion.sh <input_file> <final_vcf_file>"
    exit 1
fi

# Assign arguments to variables
INPUT_FILE=$1
FINAL_VCF_FILE=$2
TEMP_FILE="temp_no_chr.txt"          # Temporary file for the removeChrPrefix.py output
CONVERTED_FILE="converted_output.txt" # Temporary output from NewElta90AffyConverter.py

# Check and install dos2unix if necessary
echo "Checking for dos2unix..."
if ! command -v dos2unix &> /dev/null; then
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        echo "Installing dos2unix on Linux..."
        sudo apt-get install -y dos2unix
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        echo "Installing dos2unix on macOS..."
        brew install dos2unix
    else
        echo "Error: Unsupported OS. Please install dos2unix manually."
        exit 1
    fi
fi

# Convert all scripts and input files to Unix format
echo "Converting files to Unix format..."
dos2unix "$INPUT_FILE"
dos2unix removeChrPrefix.py
dos2unix NewElta90AffyConverter.py

# Run the removeChrPrefix.py script to remove 'chr' prefix and save output to temp file
echo "Running removeChrPrefix.py..."
python3 removeChrPrefix.py "$INPUT_FILE" "$TEMP_FILE"
if [ $? -ne 0 ]; then
    echo "Error: removeChrPrefix.py failed."
    exit 1
fi
echo "Completed removeChrPrefix.py."

# Run the NewElta90AffyConverter.py script on the temp file output
echo "Running NewElta90AffyConverter.py..."
python3 NewElta90AffyConverter.py "$TEMP_FILE" "$CONVERTED_FILE"
if [ $? -ne 0 ]; then
    echo "Error: NewElta90AffyConverter.py failed."
    exit 1
fi
echo "Completed NewElta90AffyConverter.py."

# Run Tgex.Microarray.Converter to produce the final VCF file
echo "Running Tgex.Microarray.Converter..."
./Tgex.Microarray.Converter -i "$CONVERTED_FILE" -f Affymetrix -o "$FINAL_VCF_FILE"
if [ $? -ne 0 ]; then
    echo "Error: Tgex.Microarray.Converter failed."
    exit 1
fi
echo "Completed Tgex.Microarray.Converter. VCF output saved to $FINAL_VCF_FILE."

# Clean up temporary files
rm "$TEMP_FILE" "$CONVERTED_FILE"
echo "Temporary files removed. Conversion process completed successfully."
