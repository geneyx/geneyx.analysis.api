import shutil
import gzip
import os
import logging

def sort_vcf_python(vcf_path):
    try:
        with open(vcf_path, 'r') as f:
            lines = f.readlines()

        header_lines = [line for line in lines if line.startswith("#")]
        content_lines = [line for line in lines if not line.startswith("#") and line.strip() != ""]

        content_lines.sort(key=lambda x: (x.split('\t')[0], int(x.split('\t')[1])))

        with open(vcf_path, 'w') as f:
            f.writelines(header_lines + content_lines)

    except Exception as e:
        logging.error(f"Could not sort VCF: {e}")

def __get_lines__(file_path: str) -> []:
    try:
        with gzip.open(file_path, 'rt') as file_h:
            lines = file_h.readlines()
    except:
        with open(file_path) as file_h:
            lines = file_h.readlines()
    return lines

def __modify_repeat_line__(repeat_line: str) -> str:
    (chrom, pos, id, ref, alt, qual, filter, info, format, _) = repeat_line.split("\t")
    info = info + ';SVTYPE=REP'
    return "\t".join((chrom, pos, id, ref, alt, qual, filter, info, format, _))

def __modify_roh_line__(vcf_line) -> str:
    bed_data = vcf_line.strip().split('\t')
    pos_value = min([int(bed_data[1]), int(bed_data[2])]) + 1
    end_value = max([int(bed_data[1]), int(bed_data[2])])
    chromosome = bed_data[0]
    roh_score = bed_data[3]
    return f"{chromosome}\t{pos_value}\t.\tN\t<ROH>\t.\tPASS\tEND={end_value};SVTYPE=ROH;ROH_SCORE={roh_score}\tGT\t1/1\n"

def __is_valid_line__(line: str) -> bool:
    if line.startswith('#') or not line:
        return True
    cells = line.split('\t')
    info_cell = cells[7]
    format_key = cells[8]
    format_value = cells[9]
    if 'SVTYPE=' in info_cell:
        return True
    gt_index = format_key.split(':').index('GT')
    gt_value = format_value.split(':')[gt_index]
    if gt_index == '0' or gt_value == './.':
        return False
    return True

def __write_vcf_content__(ftype: str, lines_dict: dict, output_h, skip_svtype: bool):
    start_read_content_flag = ftype == 'roh'
    for vcf_line in lines_dict[ftype]:
        if start_read_content_flag:
            if ftype == 'repeat' and not skip_svtype:
                vcf_line = __modify_repeat_line__(vcf_line)
            elif ftype == 'roh':
                vcf_line = __modify_roh_line__(vcf_line)
            output_h.write(vcf_line)
        if vcf_line.find('#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT') != -1:
            start_read_content_flag = True
    if not start_read_content_flag:
        logging.warning(f'No vcf header for given {ftype} file')

def __get_vcf_header_from_lines__(vcf_lines: []):
    vcf_header = ""
    for line in vcf_lines:
        vcf_header += line
        if line.find("#CHROM") != -1:
            break
    return vcf_header

def __is_empty__(lines: []) -> bool:
    for line in lines:
        if line.strip() != '' and not line.startswith('#'):
            return False
    return True

def __create_unified_file__(files_lines: dict, output_path: str, skip_svtype: bool):
    cnv_printed = False
    rep_printed = False
    with open(output_path, 'w+') as output_h:
        if files_lines['sv'] is not None:
            output_h.write("".join(files_lines['sv']))
        elif files_lines['cnv'] is not None:
            cnv_printed = True
            output_h.write("".join(filter(lambda l: __is_valid_line__(l), files_lines['cnv'])))
        elif files_lines['repeat'] is not None:
            rep_printed = True
            rep_header = __get_vcf_header_from_lines__(files_lines['repeat'])
            output_h.write(rep_header)
            __write_vcf_content__('repeat', files_lines, output_h, skip_svtype)
        else:
            logging.warning('Empty/no vcf files to concatenate')
            return

        if files_lines['cnv'] is not None and not cnv_printed:
            __write_vcf_content__('cnv', files_lines, output_h, skip_svtype)
        if files_lines['repeat'] is not None and not rep_printed:
            __write_vcf_content__('repeat', files_lines, output_h, skip_svtype)
        if files_lines['roh'] is not None:
            __write_vcf_content__('roh', files_lines, output_h, skip_svtype)

    sort_vcf_python(output_path)

    # Compress to .vcf.gz using gzip
    with open(output_path, 'rb') as f_in:
        with gzip.open(output_path + '.gz', 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)

def run(output_path: str, sv_path: str = None, cnv_path: str = None, repeat_path: str = None, roh_bed_path : str = None, skip_svtype: bool = False):
    struct_files = {
        'sv': sv_path,
        'cnv': cnv_path,
        'repeat': repeat_path,
        'roh': roh_bed_path
    }
    struct_lines = {}
    for file_type in struct_files.keys():
        struct_lines[file_type] = None
        if struct_files[file_type] is None:
            logging.warning(f'Can\'t unify file type "{file_type}". The file does not exist.')
            continue
        lines = __get_lines__(struct_files[file_type])
        if __is_empty__(lines):
            logging.warning(f'Can\'t unify file type "{file_type}". The file is empty or contains only headers.')
            continue
        struct_lines[file_type] = lines

    __create_unified_file__(struct_lines, output_path, skip_svtype)