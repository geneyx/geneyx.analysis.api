#!/usr/bin/env python3
import argparse
from UnifyVcf import run

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Unify structural VCF files for Dragen data')
    parser.add_argument('-o', '--outputPath', help='Unified output VCF path (required)', required=True)
    parser.add_argument('-s', '--svPath', help='SV input file path (optional)', required=False, default=None)
    parser.add_argument('-c', '--cnvPath', help='CNV input file path (optional)', required=False, default=None)
    parser.add_argument('-r', '--repeatPath', help='Repeat VCF input file path (optional)', required=False, default=None)

    args = parser.parse_args()
    # Assume STRaglr or other tools may need SVTYPE=REP added
    run(output_path=args.outputPath, sv_path=args.svPath, cnv_path=args.cnvPath, repeat_path=args.repeatPath, skip_svtype=False)