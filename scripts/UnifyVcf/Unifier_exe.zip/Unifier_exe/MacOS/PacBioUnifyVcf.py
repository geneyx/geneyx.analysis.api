#!/usr/bin/env python3
import argparse
from UnifyVcf import run

def unify_pacbio(output_path: str, sv_path: str = None, cnv_path: str = None, full_repeat_path: str = None):
    # PacBio repeats need REP tag, so skip_svtype must be False
    run(output_path=output_path, sv_path=sv_path, cnv_path=cnv_path, repeat_path=full_repeat_path, skip_svtype=False)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Unify structural VCF files for PacBio data')
    parser.add_argument('-o', '--outputPath', help='Unified output VCF path (required)', required=True)
    parser.add_argument('-s', '--svPath', help='SV input file path (optional)', required=False, default=None)
    parser.add_argument('-c', '--cnvPath', help='CNV input file path (optional)', required=False, default=None)
    parser.add_argument('-r', '--fullRepeatPath', help='Full repeats input file path (optional)', required=False, default=None)

    args = parser.parse_args()
    unify_pacbio(args.outputPath, args.svPath, args.cnvPath, args.fullRepeatPath)