import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess
import os
import sys

def browse_file(entry):
    filepath = filedialog.askopenfilename()
    if filepath:
        entry.delete(0, tk.END)
        entry.insert(0, filepath)

def browse_output(entry):
    filepath = filedialog.asksaveasfilename(defaultextension=".vcf.gz", filetypes=[("VCF files", "*.vcf.gz")])
    if filepath:
        entry.delete(0, tk.END)
        entry.insert(0, filepath)

def run_unifier():
    platform = platform_var.get()
    output = output_entry.get().strip()
    sv = sv_entry.get().strip()
    cnv = cnv_entry.get().strip()
    repeat = repeat_entry.get().strip()
    roh = roh_entry.get().strip()
    modify = modify_var.get()

    if not platform or not output:
        messagebox.showerror("Missing Info", "Platform and Output path are required.")
        return

    args = [sys.executable, "UnifiedVcfRunner.py", "-p", platform, "-o", output]
    if sv: args += ["-s", sv]
    if cnv: args += ["-c", cnv]
    if repeat: args += ["-r", repeat]
    if platform == "ont" and roh:
        args += ["--roh", roh]
    if platform == "dragen" and modify:
        args.append("--modify")

    try:
        subprocess.run(args, check=True)
        messagebox.showinfo("Success", "Unified VCF created successfully!")
    except subprocess.CalledProcessError as e:
        messagebox.showerror("Error", f"Failed to run unifier:\n{e}")

root = tk.Tk()
root.title("VCF Unifier - macOS")

tk.Label(root, text="Platform:").grid(row=0, column=0, sticky="w")
platform_var = tk.StringVar(value="pacbio")
tk.OptionMenu(root, platform_var, "pacbio", "ont", "dragen").grid(row=0, column=1, sticky="we")

tk.Label(root, text="Output VCF Path:").grid(row=1, column=0, sticky="w")
output_entry = tk.Entry(root, width=60)
output_entry.grid(row=1, column=1)
tk.Button(root, text="Browse", command=lambda: browse_output(output_entry)).grid(row=1, column=2)

tk.Label(root, text="SV VCF Path:").grid(row=2, column=0, sticky="w")
sv_entry = tk.Entry(root, width=60)
sv_entry.grid(row=2, column=1)
tk.Button(root, text="Browse", command=lambda: browse_file(sv_entry)).grid(row=2, column=2)

tk.Label(root, text="CNV VCF Path:").grid(row=3, column=0, sticky="w")
cnv_entry = tk.Entry(root, width=60)
cnv_entry.grid(row=3, column=1)
tk.Button(root, text="Browse", command=lambda: browse_file(cnv_entry)).grid(row=3, column=2)

tk.Label(root, text="Repeat VCF Path:").grid(row=4, column=0, sticky="w")
repeat_entry = tk.Entry(root, width=60)
repeat_entry.grid(row=4, column=1)
tk.Button(root, text="Browse", command=lambda: browse_file(repeat_entry)).grid(row=4, column=2)

tk.Label(root, text="ROH BED Path (ONT only):").grid(row=5, column=0, sticky="w")
roh_entry = tk.Entry(root, width=60)
roh_entry.grid(row=5, column=1)
tk.Button(root, text="Browse", command=lambda: browse_file(roh_entry)).grid(row=5, column=2)

modify_var = tk.BooleanVar()
tk.Checkbutton(root, text="Modify repeat info (Dragen only)", variable=modify_var).grid(row=6, column=1, sticky="w")

tk.Button(root, text="Run Unifier", command=run_unifier).grid(row=7, column=1, pady=10)

root.mainloop()