#!/usr/bin/env python3
import argparse
import logging
from UnifyVcf import run

def run_unifier(platform, output, sv, cnv, repeat, roh, bed, modify_flag):
    if platform == "pacbio":
        # PacBio now uses full repeat file directly
        run(output_path=output, sv_path=sv, cnv_path=cnv, repeat_path=repeat, skip_svtype=False)

    elif platform == "ont":
        run(output_path=output, sv_path=sv, cnv_path=cnv, repeat_path=repeat, roh_bed_path=roh)

    elif platform == "dragen":
        run(output_path=output, sv_path=sv, cnv_path=cnv, repeat_path=repeat, skip_svtype=not modify_flag)

    else:
        logging.error("Unsupported platform. Choose from: pacbio, ont, dragen.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Unified VCF Unifier Tool")
    parser.add_argument('-p', '--platform', required=True, choices=["pacbio", "ont", "dragen"], help='Platform type')
    parser.add_argument('-o', '--output', required=True, help='Unified VCF output path')
    parser.add_argument('-s', '--sv', help='SV VCF path')
    parser.add_argument('-c', '--cnv', help='CNV VCF path')
    parser.add_argument('-r', '--repeat', help='Repeat VCF path')
    parser.add_argument('--roh', help='ROH BED file path (ONT only)')
    parser.add_argument('--bed', help='Repeat BED filter file (PacBio only — deprecated)')
    parser.add_argument('--modify', action='store_true', help='Force modify repeat info (Dragen only)')

    args = parser.parse_args()
    run_unifier(args.platform, args.output, args.sv, args.cnv, args.repeat, args.roh, args.bed, args.modify)