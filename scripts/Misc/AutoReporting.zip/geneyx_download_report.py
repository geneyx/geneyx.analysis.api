#!/usr/bin/env python3
"""
Geneyx report downloader (patient- or case-based) — Python CLI (no external deps).

What it does:
1) POST /Api/PatientReports or /Api/CaseReports (credentials in JSON body)
2) Choose latest report by CreateDate
3) POST /Api/ReportUrl?fileName=... (credentials in headers; fileName also sent in JSON body for compatibility)
4) Download the file

Credentials (recommended):
- Set environment variables:
    GENEYX_API_USER_ID
    GENEYX_API_USER_KEY

Windows CMD (persistent):
    setx GENEYX_API_USER_ID "YOUR_ID"
    setx GENEYX_API_USER_KEY "YOUR_KEY"
  Then close & reopen CMD.

Temporary (current CMD window only):
    set GENEYX_API_USER_ID=YOUR_ID
    set GENEYX_API_USER_KEY=YOUR_KEY

Examples:
  # Download latest data (data.tsv.zip) for a patient
  python geneyx_download_report.py --patient-sn "Auto_Report Test" --kind data --out-dir .

  # Download latest data for a case
  python geneyx_download_report.py --case-sn "G-Q231215142326 - Copy (1)" --kind data --out-dir .

  # Download latest model file (.json.gz) for a case
  python geneyx_download_report.py --case-sn "G-Q231215142326 - Copy (1)" --kind model --out-dir .

Optional:
  --out-name "local_filename.zip"  (save with a different local filename)
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Optional, Tuple

BASE_URL = "https://analysis.geneyx.com"


def eprint(*args: Any) -> None:
    print(*args, file=sys.stderr)


def parse_iso_dt(s: str) -> dt.datetime:
    if not s:
        return dt.datetime.min
    try:
        return dt.datetime.fromisoformat(s)
    except ValueError:
        try:
            return dt.datetime.strptime(s.split(".")[0], "%Y-%m-%dT%H:%M:%S")
        except Exception:
            return dt.datetime.min


def http_json(
    method: str,
    url: str,
    headers: Dict[str, str],
    payload: Optional[Dict[str, Any]] = None,
    timeout: int = 60,
) -> Dict[str, Any]:
    data_bytes = None
    req_headers = dict(headers)

    if payload is not None:
        data_bytes = json.dumps(payload).encode("utf-8")
        req_headers.setdefault("Content-Type", "application/json")

    req = urllib.request.Request(url, data=data_bytes, method=method.upper())
    for k, v in req_headers.items():
        req.add_header(k, v)

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as he:
        body = he.read().decode("utf-8", errors="replace") if hasattr(he, "read") else ""
        raise RuntimeError(f"HTTP {he.code} calling {url}: {body or he.reason}") from he
    except Exception as ex:
        raise RuntimeError(f"Request failed calling {url}: {ex}") from ex

    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        raise RuntimeError(f"Non-JSON response from {url}: {raw[:600]}...")


def choose_latest_item(items: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not items:
        return None
    return sorted(items, key=lambda x: parse_iso_dt(str(x.get("CreateDate", ""))), reverse=True)[0]


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def download_file(url: str, out_path: str, timeout: int = 300) -> Tuple[int, str]:
    req = urllib.request.Request(url, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            total = 0
            with open(out_path, "wb") as f:
                while True:
                    chunk = resp.read(1024 * 1024)
                    if not chunk:
                        break
                    f.write(chunk)
                    total += len(chunk)
            return total, out_path
    except urllib.error.HTTPError as he:
        raise RuntimeError(f"HTTP {he.code} downloading {url}: {he.reason}") from he
    except Exception as ex:
        raise RuntimeError(f"Download failed {url}: {ex}") from ex


def get_creds(args: argparse.Namespace) -> Tuple[str, str]:
    api_user_id = args.api_user_id or os.getenv("GENEYX_API_USER_ID")
    api_user_key = args.api_user_key or os.getenv("GENEYX_API_USER_KEY")
    if not api_user_id or not api_user_key:
        raise SystemExit(
            "Missing credentials.\n"
            "Set env vars GENEYX_API_USER_ID and GENEYX_API_USER_KEY or pass --api-user-id and --api-user-key.\n"
            "Note: If you just ran 'setx' on Windows, close and reopen your terminal first."
        )
    return api_user_id, api_user_key


def main() -> int:
    p = argparse.ArgumentParser(description="Download latest Geneyx report by patient or case.")
    target = p.add_mutually_exclusive_group(required=True)
    target.add_argument("--patient-sn", help="Patient identifier in Geneyx (patientSn).")
    target.add_argument("--case-sn", help="Case identifier in Geneyx (CaseSn).")

    p.add_argument(
        "--kind",
        choices=["data", "model"],
        default="data",
        help="data -> DataFileUrl (tsv.zip), model -> ModelFileUrl (json.gz).",
    )
    p.add_argument("--out-dir", default=".", help="Directory to save the downloaded file.")
    p.add_argument("--out-name", default=None, help="Optional local filename override.")
    p.add_argument("--timeout", type=int, default=60, help="API timeout seconds.")
    p.add_argument("--download-timeout", type=int, default=300, help="Download timeout seconds.")

    # creds (optional flags; env vars recommended)
    p.add_argument("--api-user-id", default=None, help="ApiUserId (or env GENEYX_API_USER_ID).")
    p.add_argument("--api-user-key", default=None, help="ApiUserKey (or env GENEYX_API_USER_KEY).")

    args = p.parse_args()
    api_user_id, api_user_key = get_creds(args)
    ensure_dir(args.out_dir)

    # 1) list reports
    if args.patient_sn:
        list_endpoint = f"{BASE_URL}/Api/PatientReports"
        list_payload = {"patientSn": args.patient_sn, "ApiUserId": api_user_id, "ApiUserKey": api_user_key}
    else:
        list_endpoint = f"{BASE_URL}/Api/CaseReports"
        list_payload = {"CaseSn": args.case_sn, "ApiUserId": api_user_id, "ApiUserKey": api_user_key}

    eprint(f"Querying reports: {list_endpoint}")
    resp = http_json(
        "POST",
        list_endpoint,
        headers={"Accept": "application/json"},
        payload=list_payload,
        timeout=args.timeout,
    )

    if resp.get("Code") != "success":
        raise SystemExit(f"API error listing reports: Code={resp.get('Code')} Info={resp.get('Info')}")

    items = resp.get("Data") or []
    latest = choose_latest_item(items)
    if not latest:
        raise SystemExit("No reports found for the provided patient/case.")

    field = "DataFileUrl" if args.kind == "data" else "ModelFileUrl"
    filename = latest.get(field)
    if not filename:
        raise SystemExit(f"Latest report did not include {field}. Available keys: {list(latest.keys())}")

    eprint(f"Latest CreateDate: {latest.get('CreateDate')}")
    eprint(f"Selected fileName: {filename}")

    # 2) get signed URL
    # IMPORTANT: This endpoint is POST-only in your environment; also, server may require fileName
    # in a specific way. To be maximally compatible, send fileName in BOTH query param and JSON body.
    report_url_endpoint = f"{BASE_URL}/Api/ReportUrl"
    qs = urllib.parse.urlencode({"fileName": filename}, quote_via=urllib.parse.quote)
    signed_url_resp = http_json(
        "POST",
        f"{report_url_endpoint}?{qs}",
        headers={
            "Accept": "application/json",
            "ApiUserId": api_user_id,
            "ApiUserKey": api_user_key,
            "Content-Type": "application/json",
        },
        payload={"fileName": filename},
        timeout=args.timeout,
    )

    if signed_url_resp.get("Code") != "success":
        raise SystemExit(
            f"API error getting signed URL: Code={signed_url_resp.get('Code')} Info={signed_url_resp.get('Info')}"
        )

    file_url = (signed_url_resp.get("Data") or {}).get("fileUrl")
    if not file_url:
        raise SystemExit(f"Signed URL response missing Data.fileUrl: {signed_url_resp}")

    # 3) download
    out_name = args.out_name or filename
    out_path = os.path.join(args.out_dir, out_name)

    eprint(f"Downloading to: {out_path}")
    bytes_written, _ = download_file(file_url, out_path, timeout=args.download_timeout)

    print(out_path)  # prints final path for easy copy/paste
    eprint(f"Done. Downloaded {bytes_written} bytes.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        eprint("Cancelled.")
        raise SystemExit(130)
