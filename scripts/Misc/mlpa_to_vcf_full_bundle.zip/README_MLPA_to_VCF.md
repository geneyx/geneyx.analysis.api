
# MLPA to VCF Converter

This script converts digital MLPA Excel files into individual VCF files for each sample, summarizing Copy Number Variations (CNVs) such as deletions and duplications.

## Features

- Reads Excel files with MLPA data
- Parses chromosomal coordinates from the "Mapview (hg38) in kb" column
- Identifies deletions (CN < 0.6) and duplications (CN > 1.3)
- Merges contiguous CNV events per gene if within 5,000 base pairs
- Outputs standard-compliant VCF files with rounded average CN values per event

## Usage

### Requirements

- Python 3.x
- pandas, numpy (install via `pip install pandas numpy`)

### Command Line

```bash
python mlpa_to_vcf_5kb.py <input_excel_file> <output_directory>
```

### Example

```bash
python mlpa_to_vcf_5kb.py Subset.xlsx ./vcf_output
```

This will generate a VCF file for each sample in the specified output directory.

## Output Format

Each VCF entry includes:

- `CHROM`, `POS`, `END`, `SVLEN`: Genomic coordinates
- `ALT`: `<DEL>` or `<DUP>`
- `INFO`: Structural variant metadata
- `CN`: Average CN value for merged region (to two decimal places)

## Notes

- Assumes headers are in row 5 and data starts at row 13
- Uses the "Mapview (hg38) in kb" column for position parsing
- Designed for digital MLPA output format

## License

MIT License
