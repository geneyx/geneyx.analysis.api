
#!/bin/bash
echo "Welcome to the MLPA to VCF converter"

read -p "Enter the name of your Excel file (e.g., Subset.xlsx): " inputfile
read -p "Enter the output folder name (e.g., results): " outfolder

python3 mlpa_to_vcf_10kb_ratio_in_qual.py "$inputfile" "$outfolder"

echo
echo "Done! VCFs are saved in: $outfolder"
