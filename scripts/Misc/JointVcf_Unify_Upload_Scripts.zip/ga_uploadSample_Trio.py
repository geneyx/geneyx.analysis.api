#!/usr/bin/env python3
"""
ga_uploadSample.py (rewritten)

Uploads VCF(s) as sample(s) to Geneyx Analysis.

Supports:
- Single-sample VCF upload (default behavior)
- Jointly called (multi-sample) VCFs via --joined (splits per sample with bcftools)
- Optional trio/sample mapping via --sampleMap (CSV/TSV): sampleId,patientId,relation
- Optional SV+CNV combine per sample (keeps your prior behavior, but done per-sample when joined)
- Skips empty fields from payload (avoids sending "" for optional fields)
- Dry-run mode

Requirements:
- python3
- bcftools + tabix on PATH (required if --joined or combining gz inputs)
- requests, pyyaml
"""

import argparse
import os
import sys
import ntpath
import json
import logging
import subprocess
from typing import Dict, List, Optional, Tuple

import requests
import ga_helperFunctions as funcs


# -----------------------
# Utilities
# -----------------------
def ensure_exists(path: Optional[str], label: str):
    if path is None:
        return
    if not os.path.exists(path):
        raise FileNotFoundError(f'{label} file does not exist: {path}')

def run_cmd(cmd: List[str], check: bool = True, capture: bool = False) -> str:
    logging.debug("Running: %s", " ".join(cmd))
    if capture:
        out = subprocess.check_output(cmd, text=True)
        return out
    subprocess.run(cmd, check=check)
    return ""

def is_vcf_like(path: str) -> bool:
    return (".vcf" in path)  # allows .vcf.gz etc

def strip_vcf_extensions(filename: str) -> str:
    # turns X.vcf.gz -> X, X.vcf -> X
    if filename.endswith(".vcf.gz"):
        return filename[:-7]
    if filename.endswith(".vcf"):
        return filename[:-4]
    # fallback: peel until .vcf appears in chain
    base = filename
    suf = ""
    while base and suf != ".vcf":
        base, suf = os.path.splitext(base)
    return base if base else filename

def vcf_samples(vcf_path: str) -> List[str]:
    # bcftools query -l works for .vcf and .vcf.gz
    out = run_cmd(["bcftools", "query", "-l", vcf_path], capture=True)
    samples = [s.strip() for s in out.splitlines() if s.strip()]
    return samples

def split_vcf_by_sample(vcf_path: str, sample: str, out_path: str):
    """
    Splits a multi-sample VCF into a single-sample bgzipped VCF.
    -c 1 keeps sites even if sample is hom-ref/no-call (safer for downstream).
    """
    run_cmd(["bcftools", "view", "-s", sample, "-c", "1", "-Oz", "-o", out_path, vcf_path])
    run_cmd(["tabix", "-f", "-p", "vcf", out_path])

def open_text_maybe_gzip_for_cat(path: str) -> List[str]:
    # For shell-based zcat -f usage in combine step
    return ["zcat", "-f", path]

def combine_sv_cnv(sv_path: str, cnv_path: str, out_path: str):
    """
    Combines SV + CNV into one VCF (keeps header from SV, appends both bodies).
    Uses zcat -f so it works for .vcf and .vcf.gz inputs.
    Output is plain .vcf (not gz). You can bgzip+tabix later if desired.
    """
    # Write header from SV
    with open(out_path, "w", encoding="utf-8") as out_h:
        # header from sv
        sv_header = subprocess.check_output(open_text_maybe_gzip_for_cat(sv_path), text=True)
        for line in sv_header.splitlines(True):
            if line.startswith("#"):
                out_h.write(line)
            else:
                break

    # Append SV body
    with open(out_path, "a", encoding="utf-8") as out_h:
        sv_all = subprocess.check_output(open_text_maybe_gzip_for_cat(sv_path), text=True)
        for line in sv_all.splitlines(True):
            if not line.startswith("#") and line.strip():
                out_h.write(line)

        # Append CNV body
        cnv_all = subprocess.check_output(open_text_maybe_gzip_for_cat(cnv_path), text=True)
        for line in cnv_all.splitlines(True):
            if not line.startswith("#") and line.strip():
                out_h.write(line)

def load_sample_map(map_path: str) -> Dict[str, Tuple[str, str]]:
    """
    Reads CSV/TSV with columns: sampleId,patientId,relation
    Delimiter auto-detected by presence of tab vs comma.
    Returns dict sampleId -> (patientId, relation)
    """
    mapping: Dict[str, Tuple[str, str]] = {}
    with open(map_path, "r", encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            delim = "\t" if "\t" in line else ","
            parts = [p.strip() for p in line.split(delim)]
            if len(parts) < 2:
                raise ValueError(f"Bad sampleMap line (need sampleId,patientId[,relation]): {raw}")
            sample_id = parts[0]
            patient_id = parts[1]
            relation = parts[2] if len(parts) >= 3 and parts[2] else "Self"
            mapping[sample_id] = (patient_id, relation)
    return mapping

def prune_empty_fields(d: Dict) -> Dict:
    """
    Remove keys with None or empty string values to avoid sending empty fields.
    Keep False/0 as valid.
    """
    out = {}
    for k, v in d.items():
        if v is None:
            continue
        if isinstance(v, str) and v.strip() == "":
            continue
        out[k] = v
    return out

def post_create_sample(api_url: str, data: Dict, files: Dict, dry_run: bool):
    if dry_run:
        logging.info("[DRY RUN] Would POST %s", api_url)
        logging.info("[DRY RUN] Data keys: %s", ", ".join(sorted(data.keys())))
        logging.info("[DRY RUN] Files: %s", ", ".join(sorted(files.keys())))
        return

    r = requests.post(api_url, data=data, files=files)
    print(r)
    print(r.content)
    r.raise_for_status()


# -----------------------
# Upload logic
# -----------------------
def upload_one_sample(
    *,
    api_url: str,
    config: Dict,
    args,
    sample_id: str,
    patient_id: str,
    relation: str,
    snv_vcf_path: Optional[str],
    sv_vcf_path: Optional[str],
    dry_run: bool
):
    # base names for API fields
    snv_base = ntpath.basename(snv_vcf_path) if snv_vcf_path else None
    sv_base = ntpath.basename(sv_vcf_path) if sv_vcf_path else None

    data = {
        "ApiUserKey": config["apiUserKey"],
        "ApiUserID": config["apiUserId"],
        "CustomerAccountKey": args.customerAccountKey,

        "SampleSerialNumber": sample_id,
        "SampleSequenceDate": args.sampleSequenceDate,
        "SampleTakenDate": args.sampleTakenDate,
        "SampleReceivedDate": args.sampleReceiveDate,
        "SampleType": args.sampleType,
        "SampleTarget": args.sampleTarget,
        "SampleSource": args.sampleSource,
        "SampleSequenceMachineId": args.seqMachineId,
        "SampleEnrichmentKitId": args.kitId,
        "SampleGenomeBuild": args.genomeBuild,
        "SampleNotes": args.sampleNotes,
        "SampleRelation": relation,
        "SampleQcData": args.sampleQcData,
        "SampleAdvAnalysis": args.sampleAdvAnalysis,
        "ExcludeFromLAF": args.excludeFromLAF,

        "bamUrl": args.bamUrl,
        "localBamUrl": args.localBamUrl,
        "methylationUrl": args.methylationUrl,
        "localMethylationUrl": args.localMethylationUrl,

        "SnvFile": snv_base,
        "StructFile": sv_base,

        "SubjectId": patient_id,
        "SubjectName": args.patientName,
        "SubjectGender": args.patientGender,
        "SubjectDateOfBirth": args.patientDateOfBirth,
        "SubjectConsanguinity": args.patientConsanguinity,
        "SubjectPopulationType": args.patientPopulationType,
        "SubjectPaternalAncestry": args.patientPaternalAncestry,
        "SubjectMaternalAncestry": args.patientMaternalAncestry,
        "SubjectFamilyHistory": args.patientFamilyHistory,
        "SubjectHasBioSample": args.patientHasBioSample,
        "SubjectUseConsentPersonal": args.patientUseConsentPersonal,
        "SubjectUseConsentClinical": args.patientUseConsentClinical,

        "SkipAnnotation": args.skipAnnotation,
    }

    # Group assignment (optional)
    if args.groupAssignmentCode is not None and args.groupAssignmentName is not None:
        data["GroupAssignment"] = json.dumps([{"Code": args.groupAssignmentCode, "Name": args.groupAssignmentName}])

    data = prune_empty_fields(data)

    files = {}
    opened = []
    try:
        if snv_vcf_path:
            f = open(snv_vcf_path, "rb")
            opened.append(f)
            files["snvFile"] = f
        if sv_vcf_path:
            f = open(sv_vcf_path, "rb")
            opened.append(f)
            files["svFile"] = f

        logging.info("Uploading sample %s (patient %s, relation %s)", sample_id, patient_id, relation)
        post_create_sample(api_url, data, files, dry_run=dry_run)
    finally:
        for f in opened:
            try:
                f.close()
            except Exception:
                pass


# -----------------------
# Main
# -----------------------
def main():
    logging.basicConfig(level=logging.INFO, format="%(levelname)s:%(message)s")

    parser = argparse.ArgumentParser(
        prog="ga_uploadSample.py",
        description="Uploads VCF file(s) as sample(s) to Geneyx Analysis (supports joined VCFs via --joined)."
    )

    # VCFs
    parser.add_argument("--snvVcf", help="Path to the SNV VCF file (can be joint if --joined)")
    parser.add_argument("--svVcf", help="Path to the SV VCF file (can be joint if --joined)")
    parser.add_argument("--cnvVcf", help="Path to the CNV VCF file (can be joint if --joined)")

    # sample data
    parser.add_argument("--sampleId", help="Sample id (serial number) (single-sample mode). If omitted, inferred from file.")
    parser.add_argument("--sampleTakenDate", help="Sample taken date")
    parser.add_argument("--sampleSequenceDate", help="Sample sequence date")
    parser.add_argument("--sampleReceiveDate", help="Sample receive date")
    parser.add_argument("--sampleType", help="Sample type", choices=["RnaSeq", "DnaSeq"], default="DnaSeq")
    parser.add_argument("--sampleTarget", help="Sample target", choices=["WholeGenome", "Exome", "GenePanel", "TargetRegion", "ClinicalExome"], default="Exome")
    parser.add_argument("--sampleSource", help="Sample source", choices=["GermLine", "Tumor", "Blood", "Buccal", "Mitochondria", "Saliva"], default="GermLine")
    parser.add_argument("--seqMachineId", help="Sequence machine id")
    parser.add_argument("--kitId", help="Enrichment kit id")
    parser.add_argument("--genomeBuild", help="Genome build", choices=["hg19", "hg38"], default="hg19")
    parser.add_argument("--sampleNotes", help="Sample notes")
    parser.add_argument("--sampleQcData", help="Sample QC data as json string")
    parser.add_argument("--sampleAdvAnalysis", help="Sample advanced analysis data as json string")
    parser.add_argument("--excludeFromLAF", help="Exclude sample from local AF statistics")
    parser.add_argument("--sampleRelation", help="Sample relation (single-sample mode default)", choices=[
        "Self","Mother","Father","Sibling","Twin","MotherRelative","FatherRelative","Other"
    ], default="Self")

    # external files
    parser.add_argument("--bamUrl", help="Url of BAM file")
    parser.add_argument("--localBamUrl", help="Local BAM path")
    parser.add_argument("--methylationUrl", help="Url of methylation file")
    parser.add_argument("--localMethylationUrl", help="Local methylation path")

    # patient data
    parser.add_argument("--patientId", help="Patient id (serial number). In --joined mode, can be overridden via --sampleMap.", required=True)
    parser.add_argument("--patientName", help="Patient name")
    parser.add_argument("--patientGender", help="Patient gender", choices=["F", "M", ""], default="")
    parser.add_argument("--patientDateOfBirth", help="Patient DOB")
    parser.add_argument("--patientConsanguinity", help="Patient consanguinity")
    parser.add_argument("--patientPopulationType", help="Patient population type")
    parser.add_argument("--patientPaternalAncestry", help="Patient paternal ancestry")
    parser.add_argument("--patientMaternalAncestry", help="Patient maternal ancestry")
    parser.add_argument("--patientFamilyHistory", help="Patient family history")
    parser.add_argument("--patientHasBioSample", help="Patient indicates bio sample exists")
    parser.add_argument("--patientUseConsentPersonal", help="Personal use consent")
    parser.add_argument("--patientUseConsentClinical", help="Clinical use consent")

    # assignment
    parser.add_argument("--groupAssignmentCode", help="Group assignment code")
    parser.add_argument("--groupAssignmentName", help="Group assignment name")

    # commands
    parser.add_argument("--skipAnnotation", help="Skip performing annotation after upload", action="store_true")
    parser.add_argument("--config", "-c", help="Config file", default="ga.config.yml")
    parser.add_argument("--customerAccountKey", "-a", help="Customer account key", default=None)

    # joined support
    parser.add_argument("--joined", action="store_true",
                        help="Treat input VCF(s) as jointly called (multi-sample). Splits per sample and uploads one sample per API call.")
    parser.add_argument("--tmpDir", default="_split_vcfs",
                        help="Temporary output directory for split per-sample VCFs (used in --joined mode).")
    parser.add_argument("--sampleMap", default=None,
                        help="Optional CSV/TSV mapping: sampleId,patientId,relation (used in --joined mode).")
    parser.add_argument("--dryRun", action="store_true", help="Print what would be uploaded without calling the API.")
    parser.add_argument("--keepTemp", action="store_true", help="Do not delete temp split/combined files (joined mode).")

    args = parser.parse_args()

    # Read config
    config = funcs.loadYamlFile(args.config)
    if not config or "server" not in config or "apiUserKey" not in config or "apiUserId" not in config:
        raise Exception("Config file missing required fields: server, apiUserKey, apiUserId")

    api_url = config["server"].rstrip("/") + "/api/CreateSample"

    # Validate inputs
    ensure_exists(args.snvVcf, "SNV")
    ensure_exists(args.svVcf, "SV")
    ensure_exists(args.cnvVcf, "CNV")

    if args.snvVcf is None and args.svVcf is None and args.cnvVcf is None:
        raise Exception("No SNV nor SV/CNV file were provided")

    if args.svVcf and not is_vcf_like(args.svVcf):
        raise Exception("SV file does not seem to be a VCF file")
    if args.cnvVcf and not is_vcf_like(args.cnvVcf):
        raise Exception("CNV file does not seem to be a VCF file")
    if args.snvVcf and not is_vcf_like(args.snvVcf):
        raise Exception("SNV file does not seem to be a VCF file")

    # Load mapping if provided
    mapping: Dict[str, Tuple[str, str]] = {}
    if args.sampleMap:
        ensure_exists(args.sampleMap, "sampleMap")
        mapping = load_sample_map(args.sampleMap)

    # Single-sample mode (original behavior)
    if not args.joined:
        # prepare svVcf (combine sv+cnv if both provided)
        snv_vcf = args.snvVcf
        sv_vcf = None

        if args.svVcf is not None and args.cnvVcf is not None:
            combined_path = args.svVcf.split(".vcf")[0] + ".combined.vcf"
            logging.info("Both SV and CNV provided; combining into %s", combined_path)
            combine_sv_cnv(args.svVcf, args.cnvVcf, combined_path)
            sv_vcf = combined_path
        elif args.svVcf is not None:
            sv_vcf = args.svVcf
        elif args.cnvVcf is not None:
            sv_vcf = args.cnvVcf

        if snv_vcf is None and sv_vcf is None:
            raise Exception("No SNV nor SV/CNV file were provided")

        sample_id = args.sampleId
        if sample_id is None:
            # infer from file
            if snv_vcf:
                sample_id = ntpath.basename(snv_vcf)
            elif sv_vcf:
                sample_id = ntpath.basename(sv_vcf)

        upload_one_sample(
            api_url=api_url,
            config=config,
            args=args,
            sample_id=sample_id,
            patient_id=args.patientId,
            relation=args.sampleRelation,
            snv_vcf_path=snv_vcf,
            sv_vcf_path=sv_vcf,
            dry_run=args.dryRun,
        )

        # cleanup combined file unless keepTemp
        if args.svVcf and args.cnvVcf and not args.keepTemp:
            try:
                os.remove(sv_vcf)
            except Exception:
                pass

        return

    # Joined mode
    os.makedirs(args.tmpDir, exist_ok=True)

    driver = args.snvVcf or args.svVcf or args.cnvVcf
    if driver is None:
        raise Exception("Joined mode requires at least one VCF input")

    samples = vcf_samples(driver)
    if not samples:
        raise Exception(f"Could not detect samples from VCF: {driver}")

    logging.info("Detected joint VCF samples: %s", ", ".join(samples))

    temp_files_to_cleanup: List[str] = []

    for s in samples:
        # Determine patientId + relation for this sample
        patient_id = args.patientId
        relation = args.sampleRelation
        if s in mapping:
            patient_id, relation = mapping[s]

        # Split SNV/SV/CNV per sample
        snv_split = None
        sv_split = None
        cnv_split = None

        if args.snvVcf:
            snv_split = os.path.join(args.tmpDir, f"{s}.snv.vcf.gz")
            split_vcf_by_sample(args.snvVcf, s, snv_split)
            temp_files_to_cleanup.extend([snv_split, snv_split + ".tbi"])

        if args.svVcf:
            sv_split = os.path.join(args.tmpDir, f"{s}.sv.vcf.gz")
            split_vcf_by_sample(args.svVcf, s, sv_split)
            temp_files_to_cleanup.extend([sv_split, sv_split + ".tbi"])

        if args.cnvVcf:
            cnv_split = os.path.join(args.tmpDir, f"{s}.cnv.vcf.gz")
            split_vcf_by_sample(args.cnvVcf, s, cnv_split)
            temp_files_to_cleanup.extend([cnv_split, cnv_split + ".tbi"])

        # Combine SV+CNV per sample if both exist
        sv_upload_path = None
        if sv_split and cnv_split:
            combined_path = os.path.join(args.tmpDir, f"{s}.sv_cnv.combined.vcf")
            logging.info("Combining per-sample SV+CNV for %s into %s", s, combined_path)
            combine_sv_cnv(sv_split, cnv_split, combined_path)
            sv_upload_path = combined_path
            temp_files_to_cleanup.append(combined_path)
        else:
            sv_upload_path = sv_split or cnv_split

        if snv_split is None and sv_upload_path is None:
            logging.warning("Skipping %s: no per-sample SNV or SV/CNV data after splitting", s)
            continue

        upload_one_sample(
            api_url=api_url,
            config=config,
            args=args,
            sample_id=s,
            patient_id=patient_id,
            relation=relation,
            snv_vcf_path=snv_split,
            sv_vcf_path=sv_upload_path,
            dry_run=args.dryRun,
        )

    # Cleanup temp files (optional)
    if not args.keepTemp:
        for p in temp_files_to_cleanup:
            try:
                if p and os.path.exists(p):
                    os.remove(p)
            except Exception:
                pass
        # optionally remove tmpDir if empty
        try:
            if os.path.isdir(args.tmpDir) and not os.listdir(args.tmpDir):
                os.rmdir(args.tmpDir)
        except Exception:
            pass


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] Command failed: {e}", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        sys.exit(1)
