#!/usr/bin/env python3
"""
UnifyVcf.py (fully compatible / joint-VCF friendly)

What this version fixes / guarantees:
1) When TRGT repeats are included, it injects required TRGT INFO/FORMAT header lines
   BEFORE the #CHROM line, so bcftools can subset (-s) and region-filter (-R) safely.
2) Works with multi-sample (joint) VCFs (repeat lines can have many sample columns).
3) Produces a bgzipped, indexed VCF (.vcf.gz + .tbi) at the end.
4) More robust header/content handling:
   - Writes exactly one header block
   - Appends other file contents without duplicate headers
5) Avoids common parsing pitfalls in __is_valid_line__ for multi-sample/no-genotype cases.

Dependencies:
- gzip (python stdlib)
- bgzip + tabix available on PATH
"""

import gzip
import os
import logging
import shutil
import subprocess
from typing import Dict, List, Optional

# -----------------------------
# TRGT header definitions
# -----------------------------
TRGT_HEADER_LINES = [
    '##INFO=<ID=TRID,Number=1,Type=String,Description="TRGT repeat id">',
    '##INFO=<ID=MOTIFS,Number=.,Type=String,Description="TRGT motifs">',
    '##INFO=<ID=STRUC,Number=1,Type=String,Description="TRGT structure">',
    '##FORMAT=<ID=AL,Number=.,Type=String,Description="TRGT allele lengths">',
    '##FORMAT=<ID=ALLR,Number=.,Type=String,Description="TRGT allele log ratios or related metric">',
    '##FORMAT=<ID=SD,Number=1,Type=String,Description="TRGT supporting depth or stdev metric">',
    '##FORMAT=<ID=MC,Number=1,Type=String,Description="TRGT motif count or metric">',
    '##FORMAT=<ID=MS,Number=1,Type=String,Description="TRGT motif sequence or metric">',
    '##FORMAT=<ID=AP,Number=1,Type=String,Description="TRGT allele purity or metric">',
    '##FORMAT=<ID=AM,Number=1,Type=String,Description="TRGT allele motif annotation or metric">',
]

# -----------------------------
# Helpers
# -----------------------------
def _run(cmd: List[str], check: bool = True):
    logging.debug("Running: %s", " ".join(cmd))
    subprocess.run(cmd, check=check)

def __get_lines__(file_path: str) -> List[str]:
    """
    Read file lines from gzipped or plain text VCF/BED.
    """
    try:
        with gzip.open(file_path, "rt") as file_h:
            return file_h.readlines()
    except Exception:
        with open(file_path, "r") as file_h:
            return file_h.readlines()

def __inject_header_lines__(header_text: str, extra_meta_lines: List[str]) -> str:
    """
    Insert extra '##' meta-lines into a VCF header BEFORE the #CHROM line.
    Avoid duplicates. Preserve existing order.
    """
    lines = header_text.splitlines(True)  # keep newline chars
    out: List[str] = []
    inserted = False

    existing = set(l.rstrip("\n") for l in lines if l.startswith("##"))

    for line in lines:
        if (not inserted) and line.startswith("#CHROM"):
            for meta in extra_meta_lines:
                if meta not in existing:
                    out.append(meta + "\n")
            inserted = True
        out.append(line)

    if not inserted:
        # header missing #CHROM (shouldn't happen); append at end
        for meta in extra_meta_lines:
            if meta not in existing:
                out.append(meta + "\n")

    return "".join(out)

def __get_vcf_header_from_lines__(vcf_lines: List[str]) -> str:
    """
    Return header text including the #CHROM line.
    """
    vcf_header = []
    for line in vcf_lines:
        vcf_header.append(line)
        if line.startswith("#CHROM"):
            break
    return "".join(vcf_header)

def __is_empty__(lines: List[str]) -> bool:
    """
    Empty means: no non-header variant records.
    """
    for line in lines:
        s = line.strip()
        if s and not s.startswith("#"):
            return False
    return True

# -----------------------------
# Record modifications
# -----------------------------
def __modify_repeat_line__(repeat_line: str) -> str:
    """
    Ensure SVTYPE exists in INFO for repeat records.
    Preserve all genotype columns (multi-sample safe).
    """
    repeat_line = repeat_line.rstrip("\n")
    cols = repeat_line.split("\t")

    # VCF requires at least 8 fixed fields
    if len(cols) < 8:
        return repeat_line + "\n"

    chrom, pos, vid, ref, alt, qual, flt, info = cols[:8]
    fmt = cols[8] if len(cols) > 8 else None
    sample_cols = cols[9:] if len(cols) > 9 else []

    # Add SVTYPE=STR if missing (Geneyx recognizes STR/REP)
    if info in (".", "", None):
        info = "SVTYPE=STR"
    elif "SVTYPE=" not in info:
        info = info + ";SVTYPE=STR"

    out = [chrom, pos, vid, ref, alt, qual, flt, info]
    if fmt is not None:
        out.append(fmt)
        out.extend(sample_cols)

    return "\t".join(out) + "\n"

def __modify_roh_line__(vcf_line: str) -> str:
    bed_data = vcf_line.strip().split("\t")
    # BED is 0-based; VCF is 1-based
    pos_value = min(int(bed_data[1]), int(bed_data[2])) + 1
    end_value = max(int(bed_data[1]), int(bed_data[2]))
    chromosome = bed_data[0]
    roh_score = bed_data[3] if len(bed_data) > 3 else "."
    return f"{chromosome}\t{pos_value}\t.\tN\t<ROH>\t.\tPASS\tEND={end_value};SVTYPE=ROH;ROH_SCORE={roh_score}\tGT\t1/1\n"

def __is_valid_line__(line: str) -> bool:
    """
    Keep headers as-is.
    For variants: keep if SVTYPE exists OR genotype indicates something called.
    Robust to multi-sample: only checks the first sample column if present.
    """
    if not line or line.startswith("#"):
        return True

    cells = line.rstrip("\n").split("\t")
    if len(cells) < 8:
        return True

    info_cell = cells[7]
    if "SVTYPE=" in info_cell:
        return True

    # If no FORMAT/sample columns, keep line (can't evaluate GT)
    if len(cells) < 10:
        return True

    fmt_keys = cells[8].split(":")
    sample0 = cells[9].split(":") if cells[9] else []

    if "GT" not in fmt_keys:
        return True

    gt_idx = fmt_keys.index("GT")
    if gt_idx >= len(sample0):
        return True

    gt_value = sample0[gt_idx]

    # treat no-call as invalid
    if gt_value == "./.":
        return False

    # keep otherwise
    return True

# -----------------------------
# Writing / concatenation
# -----------------------------
def __write_vcf_content__(ftype: str, lines_dict: Dict[str, List[str]], output_h, skip_svtype: bool):
    """
    Write content lines (after header) for a given file type, transforming as needed.
    """
    start_read_content = False

    for vcf_line in lines_dict[ftype]:
        if vcf_line.startswith("#CHROM"):
            start_read_content = True
            continue
        if not start_read_content:
            continue

        if ftype == "repeat" and not skip_svtype:
            vcf_line = __modify_repeat_line__(vcf_line)
        elif ftype == "roh":
            vcf_line = __modify_roh_line__(vcf_line)

        output_h.write(vcf_line)

    if not start_read_content:
        logging.warning(f'No vcf header for given {ftype} file')

def __sort_and_bgzip_and_index__(vcf_file_path: str):
    """
    Sort body lines and bgzip + tabix index.
    Produces <vcf_file_path>.gz and <vcf_file_path>.gz.tbi
    """
    temp_dir_name = "vcf-temp"
    os.makedirs(temp_dir_name, exist_ok=True)

    try:
        header_file_path = os.path.join(temp_dir_name, "header.txt")
        content_file_path = os.path.join(temp_dir_name, "content.vcf")
        sorted_content_file_path = os.path.join(temp_dir_name, "sorted_content.vcf")
        rebuilt_vcf_path = os.path.join(temp_dir_name, "rebuilt.vcf")

        # split header/content
        with open(vcf_file_path, "r") as inp, open(header_file_path, "w") as hh, open(content_file_path, "w") as cc:
            for line in inp:
                if line.startswith("#"):
                    hh.write(line)
                else:
                    cc.write(line)

        # sort content:
        # -k1,1V uses "version" sort (chr2 < chr10)
        # -k2,2n numeric position
        _run(["bash", "-lc", f'sort -k1,1V -k2,2n "{content_file_path}" > "{sorted_content_file_path}"'])

        # rebuild
        _run(["bash", "-lc", f'cat "{header_file_path}" "{sorted_content_file_path}" > "{rebuilt_vcf_path}"'])

        # overwrite original vcf with rebuilt
        shutil.copyfile(rebuilt_vcf_path, vcf_file_path)

        # bgzip to vcf.gz (force)
        # bgzip outputs <file>.gz by default; we want predictable name: vcf_file_path + ".gz"
        out_gz = vcf_file_path + ".gz"
        _run(["bash", "-lc", f'bgzip -f -c "{vcf_file_path}" > "{out_gz}"'])

        # tabix index
        _run(["tabix", "-f", "-p", "vcf", out_gz])

    finally:
        if os.path.exists(temp_dir_name):
            shutil.rmtree(temp_dir_name, ignore_errors=True)

def __create_unified_file__(files_lines: Dict[str, Optional[List[str]]], output_path: str, skip_svtype: bool):
    """
    Writes unified VCF (plain .vcf), then sorts/bgzip/indexes to .vcf.gz/.tbi
    """
    cnv_printed = False
    rep_printed = False

    include_trgt_meta = files_lines.get("repeat") is not None

    with open(output_path, "w", encoding="utf-8") as output_h:

        # Choose base header source: sv > cnv > repeat
        if files_lines["sv"] is not None:
            sv_text = "".join(files_lines["sv"])
            if include_trgt_meta:
                sv_text = __inject_header_lines__(sv_text, TRGT_HEADER_LINES)
            output_h.write(sv_text)

        elif files_lines["cnv"] is not None:
            cnv_printed = True
            cnv_text = "".join(filter(lambda l: __is_valid_line__(l), files_lines["cnv"]))
            if include_trgt_meta:
                cnv_text = __inject_header_lines__(cnv_text, TRGT_HEADER_LINES)
            output_h.write(cnv_text)

        elif files_lines["repeat"] is not None:
            rep_printed = True
            rep_header = __get_vcf_header_from_lines__(files_lines["repeat"])
            rep_header = __inject_header_lines__(rep_header, TRGT_HEADER_LINES)
            output_h.write(rep_header)
            __write_vcf_content__("repeat", files_lines, output_h, skip_svtype)

        else:
            logging.warning("Empty/no vcf files to concatenate")
            return

        # Append CNV (no header) if SV header used
        if files_lines["cnv"] is not None and not cnv_printed:
            __write_vcf_content__("cnv", files_lines, output_h, skip_svtype)

        # Append repeats (no header) if SV/CNV header used
        if files_lines["repeat"] is not None and not rep_printed:
            __write_vcf_content__("repeat", files_lines, output_h, skip_svtype)

        # Append ROH if present
        if files_lines["roh"] is not None:
            __write_vcf_content__("roh", files_lines, output_h, skip_svtype)

        output_h.flush()

    # Sort + bgzip + tabix
    __sort_and_bgzip_and_index__(output_path)

# -----------------------------
# Public entry point
# -----------------------------
def run(
    output_path: str,
    sv_path: str = None,
    cnv_path: str = None,
    repeat_path: str = None,
    roh_bed_path: str = None,
    skip_svtype: bool = False,
):
    """
    Create a unified VCF from SV, CNV, Repeat(TRGT), and ROH sources.

    Output:
      - Writes <output_path> (plain VCF)
      - Then produces <output_path>.gz + <output_path>.gz.tbi

    Notes:
      - If repeat_path is provided, TRGT header lines are injected automatically.
      - Multi-sample VCFs are supported; repeat genotype columns are preserved.
    """
    struct_files = {
        "sv": sv_path,
        "cnv": cnv_path,
        "repeat": repeat_path,
        "roh": roh_bed_path,  # this is a BED, but we treat it as lines and convert in __modify_roh_line__
    }

    struct_lines: Dict[str, Optional[List[str]]] = {k: None for k in struct_files.keys()}

    for file_type, path in struct_files.items():
        if path is None:
            logging.warning(f'Can\'t unify file type "{file_type}". The file does not exist.')
            continue
        if not os.path.exists(path):
            logging.warning(f'Can\'t unify file type "{file_type}". "{path}" does not exist.')
            continue

        lines = __get_lines__(path)
        if __is_empty__(lines):
            logging.warning(f'Can\'t unify file type "{file_type}". The file is empty or contains only headers.')
            continue

        # For CNV we filter invalid lines early if it becomes the base header; content append is handled later.
        struct_lines[file_type] = lines

    __create_unified_file__(struct_lines, output_path, skip_svtype)
