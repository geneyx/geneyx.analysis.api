##PacBio SV + TRGT Unified VCF (Joint-Calling Compatible)

This repository provides a fully joint-VCF–compatible unification and upload workflow for PacBio structural variants (SV), tandem repeat genotyping (TRGT), and optional CNV/ROH inputs, designed to work cleanly with:

Joint / multi-sample VCFs (trios, families)

bcftools subsetting (-s, -R)

Geneyx Analysis CreateSample API, which expects one sample per upload

The pipeline produces a valid, indexed unified VCF that can safely be split per sample and uploaded without header or indexing issues.


The unified output VCF is:

✅ Multi-sample safe
✅ bcftools-compatible (view -s, view -R)
✅ bgzipped and tabix-indexed
✅ TRGT header-complete (no undefined tag errors)
✅ Geneyx-ready for per-sample upload

##Inputs supported
Type	Description
SV	PacBio SV VCF (single or joint)
CNV	Optional CNV VCF
TRGT	Tandem repeat VCF (single or joint)
ROH	Optional BED file
BED	TRGT locus BED for filtering

All VCFs may be gzipped or plain text.

##Output

For an output path Test_merged.vcf, the script produces:

Test_merged.vcf.gz
Test_merged.vcf.gz.tbi


Sorted by chromosome + position

bgzipped

tabix indexed


##Example usage
Unify SV + TRGT (joint VCFs)
python3 PacBioUnifyVcf.py \
  -o Test_merged.vcf \
  -s HG002_trio_revio.joint.GRCh38.pbsv.phased.vcf.gz \
  -r trio.trgt.merged.renamed.vcf.gz \
  -b STRchive-disease-loci.hg38.TRGT.bed


After completion:

ls Test_merged.vcf.gz*


You should see:

Test_merged.vcf.gz
Test_merged.vcf.gz.tbi

##Verifying the output (recommended)
Check header correctness
bcftools view -h Test_merged.vcf.gz | grep -E 'TRID|MOTIFS|AL'

Check sample names
bcftools query -l Test_merged.vcf.gz

Subset by sample (must succeed)
bcftools view -s HG002 -Oz -o HG002.sv.vcf.gz Test_merged.vcf.gz

Region filter (must succeed)
bcftools view -R STRchive-disease-loci.hg38.TRGT.bed Test_merged.vcf.gz

##Downstream: Geneyx joint upload

This unified VCF is designed to be used with a joint-aware uploader that:

Detects samples in the VCF

Splits per sample

Uploads one Geneyx sample per VCF sample

Applies relationships using a sample map

##Example:

python3 ga_uploadSample_Trio.py \
  --snvVcf Trio_revio.joint.GRCh38.deepvariant.glnexus.phased.vcf.gz \
  --svVcf Test_merged.vcf.gz \
  --joined \
  --sampleMap trio_sample_map.tsv \
  --patientId HG002 \
  --genomeBuild hg38

##Sample map format

trio_sample_map.tsv

HG002	HG002	Self
HG003	HG003	Father
HG004	HG004	Mother


Columns:

sampleId    patientId    relation


sampleId must match the VCF column name exactly

relation must be a valid Geneyx relation

##Common failure modes (and why they’re fixed here)
Problem	Cause	Fixed by
bcftools “undefined tags”	Missing TRGT header lines	Header injection
bcftools -R fails	Missing .tbi index	Auto tabix
Joint VCF upload errors	Multi-sample ambiguity	Per-sample splitting
TRGT genotypes dropped	Single-sample assumptions	Multi-sample-safe parsing

##Design principles

Unification is the source of truth

Headers must be complete before downstream tools

Joint VCFs are split, not shared

Indexing is mandatory, not optional

Repeat annotations must be Geneyx-readable (SVTYPE=STR)

##Summary

This script turns complex PacBio + TRGT joint outputs into a clean, standards-compliant, production-ready VCF that works seamlessly with:

bcftools

IGV

Geneyx Analysis

Trio and family workflows