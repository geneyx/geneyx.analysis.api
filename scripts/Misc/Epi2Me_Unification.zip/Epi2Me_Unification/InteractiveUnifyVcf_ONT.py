#!/usr/bin/env python3

import gzip
import os
import platform
import re
import tempfile
from collections import Counter
from pathlib import Path
from typing import Optional, TextIO

from UnifyVcf import run


# -------------------------------------------------------------------------
# Operating-system detection
# -------------------------------------------------------------------------

SYSTEM_NAME = platform.system()
IS_WINDOWS = SYSTEM_NAME == "Windows"
IS_MACOS = SYSTEM_NAME == "Darwin"
IS_LINUX = SYSTEM_NAME == "Linux"


def is_wsl() -> bool:
    """Return True when running inside Windows Subsystem for Linux."""
    if not IS_LINUX:
        return False

    try:
        release = platform.release().lower()

        if "microsoft" in release or "wsl" in release:
            return True

        version_file = Path("/proc/version")

        if version_file.is_file():
            version_text = version_file.read_text(
                encoding="utf-8",
                errors="ignore",
            ).lower()

            return "microsoft" in version_text
    except OSError:
        pass

    return False


IS_WSL = is_wsl()


# -------------------------------------------------------------------------
# General path handling
# -------------------------------------------------------------------------

def clean_dragged_path(path_text: str) -> str:
    """
    Clean a path pasted or dragged into a terminal.

    Handles:
      - surrounding single or double quotes
      - escaped spaces such as My\\ Folder
      - file:// URLs sometimes produced on macOS
    """
    cleaned = path_text.strip()

    if (
        len(cleaned) >= 2
        and cleaned[0] == cleaned[-1]
        and cleaned[0] in ("'", '"')
    ):
        cleaned = cleaned[1:-1]

    cleaned = cleaned.strip()

    if cleaned.startswith("file://"):
        cleaned = cleaned[7:]

    # Common terminal escaping when dragging paths with spaces.
    cleaned = cleaned.replace("\\ ", " ")

    return cleaned


def windows_path_to_wsl(path_text: str) -> str:
    """
    Convert a Windows drive path into a WSL-mounted path.

    Example:
        C:\\Users\\eliws\\Data
        -> /mnt/c/Users/eliws/Data
    """
    match = re.match(
        r"^([A-Za-z]):[\\/](.*)$",
        path_text,
    )

    if not match:
        return path_text

    drive = match.group(1).lower()
    remainder = match.group(2).replace("\\", "/")

    return f"/mnt/{drive}/{remainder}"


def normalize_path(
    path_text: str,
    base_directory: Optional[Path] = None,
) -> Path:
    """
    Normalize Windows, macOS, Linux, WSL, quoted, dragged, and relative paths.

    Examples:
        C:\\Users\\eliws\\Customer\\HG002
        C:/Users/eliws/Customer/HG002
        /mnt/c/Users/eliws/Customer/HG002
        /Users/eli/Documents/HG002
        /home/eli/HG002
        ~/Downloads/HG002
        .
        ../results
    """
    cleaned = clean_dragged_path(path_text)
    cleaned = os.path.expandvars(os.path.expanduser(cleaned))

    windows_match = re.match(
        r"^([A-Za-z]):[\\/](.*)$",
        cleaned,
    )

    if windows_match:
        if IS_WINDOWS:
            # Native Windows Python understands the path directly.
            cleaned = cleaned.replace("/", "\\")
        elif IS_WSL:
            cleaned = windows_path_to_wsl(cleaned)
        else:
            # A Windows path is not valid natively on macOS or standard Linux.
            raise ValueError(
                "A Windows drive path was entered, but this script is not "
                "running on Windows or WSL."
            )

    path = Path(cleaned)

    if not path.is_absolute() and base_directory is not None:
        path = base_directory / path

    return path.resolve()


def is_vcf_path(path: Path) -> bool:
    """Return True when the path has a VCF or compressed VCF extension."""
    lower_name = path.name.lower()

    return (
        lower_name.endswith(".vcf")
        or lower_name.endswith(".vcf.gz")
    )


# -------------------------------------------------------------------------
# Interactive path prompts
# -------------------------------------------------------------------------

def prompt_directory() -> Path:
    """Prompt until the user supplies a valid directory."""
    print()
    print("Select the folder containing the VCF files.")
    print("You may drag the folder here or paste its path.")
    print("Press Enter to use the current directory.")
    print()

    while True:
        value = input("> ").strip()

        if not value:
            value = "."

        try:
            directory = normalize_path(value)
        except ValueError as error:
            print()
            print(f"Invalid path: {error}")
            print("Please try again.")
            print()
            continue

        if directory.is_dir():
            print()
            print("Using directory:")
            print(directory)
            return directory

        print()
        print("Directory not found:")
        print(directory)
        print("Please try again.")
        print()


def prompt_file_path(
    label: str,
    current_path: Optional[str] = None,
    base_directory: Optional[Path] = None,
) -> Optional[str]:
    """
    Prompt the user to drag or paste a VCF path.

    Enter:
      - a file path to replace the current selection
      - Enter to keep the current selection
      - 0 to skip this file type
    """
    print()

    if current_path:
        print(f"Current {label} file:")
        print(current_path)
        print()
        print(
            f"Drag or paste the correct {label} VCF, "
            "press Enter to keep the current selection, "
            "or enter 0 to skip."
        )
    else:
        print(
            f"Drag or paste the {label} VCF, "
            "or enter 0 to skip."
        )

    while True:
        value = input("> ").strip()

        if not value and current_path:
            return current_path

        if value == "0":
            return None

        if not value:
            print("Enter a file path or 0 to skip.")
            continue

        try:
            file_path = normalize_path(
                value,
                base_directory=base_directory,
            )
        except ValueError as error:
            print()
            print(f"Invalid path: {error}")
            print("Please try again.")
            continue

        if not file_path.is_file():
            print()
            print("File not found:")
            print(file_path)
            print("Please try again.")
            continue

        if not is_vcf_path(file_path):
            print()
            print(
                "Warning: the selected file does not end with "
                ".vcf or .vcf.gz."
            )

            if not prompt_yes_no(
                "Use this file anyway?",
                default=False,
            ):
                continue

        return str(file_path)


# -------------------------------------------------------------------------
# VCF reading and repeat normalization
# -------------------------------------------------------------------------

def open_vcf(path: str, mode: str) -> TextIO:
    """Open a plain-text or gzip-compressed VCF."""
    if path.lower().endswith(".gz"):
        return gzip.open(
            path,
            mode,
            encoding="utf-8",
        )

    return open(
        path,
        mode,
        encoding="utf-8",
    )


def modify_repeat_vcf(
    input_vcf: str,
    output_vcf: str,
) -> tuple[int, int]:
    """
    Normalize STR records so INFO contains SVTYPE=REP.

    For records whose ALT field contains STR:
      - SVTYPE=DUP becomes SVTYPE=REP
      - existing SVTYPE=REP is preserved
      - SVTYPE=REP is added when missing

    Returns:
        total_records, modified_records
    """
    total_records = 0
    modified_records = 0

    with open_vcf(input_vcf, "rt") as infile, open_vcf(
        output_vcf,
        "wt",
    ) as outfile:
        for line in infile:
            if line.startswith("#"):
                outfile.write(line)
                continue

            total_records += 1

            fields = line.rstrip("\r\n").split("\t")

            if len(fields) < 8:
                outfile.write(line)
                continue

            alt = fields[4]
            info = fields[7]

            if "STR" not in alt.upper():
                outfile.write(line)
                continue

            original_info = info
            info_parts = [] if info in ("", ".") else info.split(";")

            updated_parts = []
            has_svtype_rep = False

            for item in info_parts:
                if item == "SVTYPE=DUP":
                    updated_parts.append("SVTYPE=REP")
                    has_svtype_rep = True
                elif item == "SVTYPE=REP":
                    updated_parts.append(item)
                    has_svtype_rep = True
                else:
                    updated_parts.append(item)

            if not has_svtype_rep:
                updated_parts.append("SVTYPE=REP")

            fields[7] = ";".join(updated_parts)

            if fields[7] != original_info:
                modified_records += 1

            outfile.write("\t".join(fields) + "\n")

    return total_records, modified_records


# -------------------------------------------------------------------------
# General user prompts
# -------------------------------------------------------------------------

def prompt_yes_no(
    prompt_text: str,
    default: bool = False,
) -> bool:
    """Prompt for a yes/no answer."""
    display = "Y/n" if default else "y/N"

    while True:
        answer = input(
            f"{prompt_text} [{display}]: "
        ).strip().lower()

        if not answer:
            return default

        if answer in ("y", "yes"):
            return True

        if answer in ("n", "no"):
            return False

        print("Please enter y or n.")


def prompt_sample_name(
    inferred_sample: Optional[str],
) -> str:
    """Prompt for a sample name with an inferred default."""
    while True:
        if inferred_sample:
            value = input(
                f"Sample name [{inferred_sample}]: "
            ).strip()

            if not value:
                return inferred_sample
        else:
            value = input("Sample name: ").strip()

        if value:
            return value

        print("A sample name is required.")


# -------------------------------------------------------------------------
# File naming patterns
# -------------------------------------------------------------------------

VCF_SUFFIXES = (
    ".vcf",
    ".vcf.gz",
)


SV_PATTERNS = (
    ".wf_sv.vcf.gz",
    ".wf_sv.vcf",
    "_wf_sv.vcf.gz",
    "_wf_sv.vcf",
    ".sv.vcf.gz",
    ".sv.vcf",
    "_sv.vcf.gz",
    "_sv.vcf",
    ".pbsv.vcf.gz",
    ".pbsv.vcf",
    ".sniffles.vcf.gz",
    ".sniffles.vcf",
)


CNV_PATTERNS = (
    ".wf_cnv.vcf.gz",
    ".wf_cnv.vcf",
    "_wf_cnv.vcf.gz",
    "_wf_cnv.vcf",
    ".cnv.vcf.gz",
    ".cnv.vcf",
    "_cnv.vcf.gz",
    "_cnv.vcf",
)


REPEAT_PATTERNS = (
    ".wf_str.vcf.gz",
    ".wf_str.vcf",
    "_wf_str.vcf.gz",
    "_wf_str.vcf",
    ".str.vcf.gz",
    ".str.vcf",
    "_str.vcf.gz",
    "_str.vcf",
    ".repeat.vcf.gz",
    ".repeat.vcf",
    ".repeats.vcf.gz",
    ".repeats.vcf",
    ".trgt.vcf.gz",
    ".trgt.vcf",
    ".trgt.sorted.vcf.gz",
    ".trgt.sorted.vcf",
)


# -------------------------------------------------------------------------
# VCF discovery and sample inference
# -------------------------------------------------------------------------

def list_vcf_files(directory: Path) -> list[Path]:
    """Return all VCF and VCF.GZ files directly inside a directory."""
    files = []

    for path in directory.iterdir():
        if path.is_file() and is_vcf_path(path):
            files.append(path)

    return sorted(
        files,
        key=lambda item: item.name.lower(),
    )


def remove_known_suffix(filename: str) -> Optional[str]:
    """Remove a recognized caller suffix and return the sample prefix."""
    all_patterns = (
        SV_PATTERNS
        + CNV_PATTERNS
        + REPEAT_PATTERNS
    )

    lower_filename = filename.lower()

    for pattern in sorted(
        all_patterns,
        key=len,
        reverse=True,
    ):
        if lower_filename.endswith(pattern.lower()):
            return filename[:-len(pattern)]

    return None


def infer_sample_names(
    vcf_files: list[Path],
) -> list[tuple[str, int]]:
    """
    Return recognized sample prefixes ordered by frequency.

    Example:
        HG002.wf_sv.vcf.gz
        HG002.wf_cnv.vcf.gz
        HG002.wf_str.vcf.gz

    Returns:
        [("HG002", 3)]
    """
    prefixes = []

    for path in vcf_files:
        prefix = remove_known_suffix(path.name)

        if prefix:
            prefixes.append(prefix)

    return Counter(prefixes).most_common()


def choose_inferred_sample(
    sample_counts: list[tuple[str, int]],
) -> Optional[str]:
    """
    Select an inferred sample.

    A single detected sample is selected automatically. When several sample
    prefixes are present, the user may choose one.
    """
    if not sample_counts:
        return None

    if len(sample_counts) == 1:
        return sample_counts[0][0]

    print()
    print("Multiple possible sample names were detected:")

    for index, (sample_name, count) in enumerate(
        sample_counts,
        start=1,
    ):
        print(
            f"  {index}. {sample_name} "
            f"({count} recognized file(s))"
        )

    print("  0. Enter a sample name manually")

    while True:
        choice = input("Select the sample: ").strip()

        if choice == "0":
            return None

        if not choice.isdigit():
            print("Enter a number from the list.")
            continue

        selected_index = int(choice)

        if 1 <= selected_index <= len(sample_counts):
            return sample_counts[selected_index - 1][0]

        print("Invalid selection.")


def filename_matches_sample(
    filename: str,
    sample_name: str,
) -> bool:
    """Check whether a filename begins with the selected sample name."""
    filename_lower = filename.lower()
    sample_lower = sample_name.lower()

    return (
        filename_lower.startswith(sample_lower + ".")
        or filename_lower.startswith(sample_lower + "_")
        or filename_lower == sample_lower
    )


def find_matching_files(
    directory: Path,
    sample_name: str,
    patterns: tuple[str, ...],
) -> list[Path]:
    """Find files matching a sample name and recognized caller suffix."""
    matches = []

    for path in directory.iterdir():
        if not path.is_file():
            continue

        if not filename_matches_sample(
            path.name,
            sample_name,
        ):
            continue

        lower_name = path.name.lower()

        if any(
            lower_name.endswith(pattern.lower())
            for pattern in patterns
        ):
            matches.append(path)

    return sorted(
        set(matches),
        key=lambda item: item.name.lower(),
    )


def select_detected_match(
    label: str,
    matches: list[Path],
) -> Optional[str]:
    """
    Select one automatically detected file.

    A single match is selected automatically. Multiple matches are presented
    as a menu.
    """
    if not matches:
        print(f"{label}: not detected")
        return None

    if len(matches) == 1:
        selected = matches[0]
        print(f"{label}: {selected.name}")
        return str(selected)

    print()
    print(f"Multiple {label} files detected:")

    for index, path in enumerate(matches, start=1):
        print(f"  {index}. {path.name}")

    print("  0. Skip")

    while True:
        choice = input(
            f"Select the {label} file: "
        ).strip()

        if choice == "0":
            return None

        if not choice.isdigit():
            print("Enter a number from the list.")
            continue

        selected_index = int(choice)

        if 1 <= selected_index <= len(matches):
            return str(matches[selected_index - 1])

        print("Invalid selection.")


def detect_sample_files(
    directory: Path,
    sample_name: str,
) -> tuple[
    Optional[str],
    Optional[str],
    Optional[str],
]:
    """Detect likely SV, CNV, and repeat VCFs."""
    sv_matches = find_matching_files(
        directory,
        sample_name,
        SV_PATTERNS,
    )

    cnv_matches = find_matching_files(
        directory,
        sample_name,
        CNV_PATTERNS,
    )

    repeat_matches = find_matching_files(
        directory,
        sample_name,
        REPEAT_PATTERNS,
    )

    print()
    print("Automatically detected files:")
    print()

    sv_path = select_detected_match(
        "SV",
        sv_matches,
    )

    cnv_path = select_detected_match(
        "CNV",
        cnv_matches,
    )

    repeat_path = select_detected_match(
        "Repeat",
        repeat_matches,
    )

    return sv_path, cnv_path, repeat_path


# -------------------------------------------------------------------------
# File review and correction
# -------------------------------------------------------------------------

def display_path(path: Optional[str]) -> str:
    """Return a friendly display value for an optional path."""
    return path if path else "Not selected"


def print_file_selections(
    sv_path: Optional[str],
    cnv_path: Optional[str],
    repeat_path: Optional[str],
) -> None:
    """Display the current VCF selections."""
    print()
    print("Current file selections:")
    print(f"  SV:     {display_path(sv_path)}")
    print(f"  CNV:    {display_path(cnv_path)}")
    print(f"  Repeat: {display_path(repeat_path)}")


def review_file_selections(
    directory: Path,
    sv_path: Optional[str],
    cnv_path: Optional[str],
    repeat_path: Optional[str],
) -> tuple[
    Optional[str],
    Optional[str],
    Optional[str],
]:
    """
    Let the user confirm or replace automatically detected VCFs.

    Replacement files can be dragged or pasted and may be located outside the
    originally selected directory.
    """
    print_file_selections(
        sv_path,
        cnv_path,
        repeat_path,
    )

    if prompt_yes_no(
        "\nAre these files correct?",
        default=True,
    ):
        return sv_path, cnv_path, repeat_path

    while True:
        print()
        print("Which selection would you like to change?")
        print("  1. SV")
        print("  2. CNV")
        print("  3. Repeat")
        print("  4. Review current selections")
        print("  0. Finish selecting files")

        choice = input("Selection: ").strip()

        if choice == "1":
            sv_path = prompt_file_path(
                "SV",
                current_path=sv_path,
                base_directory=directory,
            )

        elif choice == "2":
            cnv_path = prompt_file_path(
                "CNV",
                current_path=cnv_path,
                base_directory=directory,
            )

        elif choice == "3":
            repeat_path = prompt_file_path(
                "repeat",
                current_path=repeat_path,
                base_directory=directory,
            )

        elif choice == "4":
            print_file_selections(
                sv_path,
                cnv_path,
                repeat_path,
            )

        elif choice == "0":
            return sv_path, cnv_path, repeat_path

        else:
            print("Enter a number from the menu.")


# -------------------------------------------------------------------------
# Output path handling
# -------------------------------------------------------------------------

def safe_sample_filename(sample_name: str) -> str:
    """Convert a sample name into a safe output filename component."""
    cleaned = re.sub(
        r'[<>:"/\\|?*\x00-\x1f]',
        "_",
        sample_name,
    )

    cleaned = cleaned.strip().strip(".")

    return cleaned or "sample"


def default_output_path(
    directory: Path,
    sample_name: str,
) -> Path:
    """Build the default unified VCF output path."""
    safe_name = safe_sample_filename(sample_name)

    return directory / f"{safe_name}_unified.vcf"


def prompt_output_path(
    default_path: Path,
) -> str:
    """
    Prompt for the unified VCF output path.

    The user may:
      - press Enter to accept the default
      - enter only a filename
      - drag or paste a complete Windows, macOS, Linux, or WSL path
    """
    print()
    print("Unified output VCF")
    print(f"Default: {default_path}")
    print(
        "Press Enter to use the default, "
        "or drag/paste another output path."
    )

    while True:
        value = input("> ").strip()

        if not value:
            output_path = default_path
        else:
            cleaned = clean_dragged_path(value)

            # A plain filename is written inside the original directory.
            is_windows_absolute = bool(
                re.match(
                    r"^[A-Za-z]:[\\/]",
                    cleaned,
                )
            )

            appears_absolute = (
                is_windows_absolute
                or cleaned.startswith(("/", "~", "."))
            )

            try:
                if appears_absolute:
                    output_path = normalize_path(cleaned)
                else:
                    output_path = (
                        default_path.parent / cleaned
                    ).resolve()
            except ValueError as error:
                print()
                print(f"Invalid output path: {error}")
                print("Please try again.")
                continue

        output_parent = output_path.parent

        if not output_parent.is_dir():
            print()
            print("Output directory does not exist:")
            print(output_parent)
            print("Please try again.")
            continue

        if not is_vcf_path(output_path):
            print()
            print(
                "The output filename does not end with "
                ".vcf or .vcf.gz."
            )

            if not prompt_yes_no(
                "Use this output filename anyway?",
                default=False,
            ):
                continue

        if output_path.exists():
            print()
            print("The output file already exists:")
            print(output_path)

            if not prompt_yes_no(
                "Overwrite it?",
                default=False,
            ):
                continue

        return str(output_path)


# -------------------------------------------------------------------------
# Main workflow
# -------------------------------------------------------------------------

def main() -> None:
    print("=" * 68)
    print("Interactive VCF Unification Tool")
    print("=" * 68)
    print(f"Platform: {SYSTEM_NAME}")

    if IS_WSL:
        print("Environment: Windows Subsystem for Linux")
    elif IS_WINDOWS:
        print("Environment: Native Windows")
    elif IS_MACOS:
        print("Environment: macOS")
    elif IS_LINUX:
        print("Environment: Linux")

    directory = prompt_directory()
    vcf_files = list_vcf_files(directory)

    if not vcf_files:
        print()
        print("No .vcf or .vcf.gz files were found in:")
        print(directory)
        return

    print()
    print(f"Found {len(vcf_files)} VCF file(s):")

    for path in vcf_files:
        print(f"  - {path.name}")

    sample_counts = infer_sample_names(vcf_files)
    inferred_sample = choose_inferred_sample(sample_counts)

    print()

    if inferred_sample:
        print(f"Inferred sample name: {inferred_sample}")
    else:
        print("A sample name could not be inferred automatically.")

    sample_name = prompt_sample_name(inferred_sample)

    sv_path, cnv_path, repeat_path = detect_sample_files(
        directory,
        sample_name,
    )

    sv_path, cnv_path, repeat_path = review_file_selections(
        directory=directory,
        sv_path=sv_path,
        cnv_path=cnv_path,
        repeat_path=repeat_path,
    )

    if not any([sv_path, cnv_path, repeat_path]):
        print()
        print("No input VCF files were selected.")
        return

    suggested_output = default_output_path(
        directory,
        sample_name,
    )

    output_path = prompt_output_path(suggested_output)

    print()
    print("=" * 68)
    print("Final configuration")
    print("=" * 68)
    print(f"Sample: {sample_name}")
    print(f"SV:     {display_path(sv_path)}")
    print(f"CNV:    {display_path(cnv_path)}")
    print(f"Repeat: {display_path(repeat_path)}")
    print(f"Output: {output_path}")
    print()

    if not prompt_yes_no(
        "Continue with VCF unification?",
        default=True,
    ):
        print("Cancelled.")
        return

    repeat_path_for_unification = repeat_path
    temporary_repeat_path = None

    try:
        if repeat_path:
            modify_repeats = prompt_yes_no(
                "Modify repeat calls to use SVTYPE=REP?",
                default=True,
            )

            if modify_repeats:
                temp_file = tempfile.NamedTemporaryFile(
                    prefix=(
                        f"{safe_sample_filename(sample_name)}"
                        "_modified_repeats_"
                    ),
                    suffix=".vcf",
                    delete=False,
                )
                temp_file.close()

                temporary_repeat_path = temp_file.name

                print()
                print("Modifying repeat calls...")
                print(f"  Input:  {repeat_path}")
                print(f"  Output: {temporary_repeat_path}")

                total, modified = modify_repeat_vcf(
                    input_vcf=repeat_path,
                    output_vcf=temporary_repeat_path,
                )

                print(
                    f"Processed {total} repeat records; "
                    f"modified {modified}."
                )

                repeat_path_for_unification = (
                    temporary_repeat_path
                )

        print()
        print("Running VCF unification...")

        run(
            output_path=output_path,
            sv_path=sv_path,
            cnv_path=cnv_path,
            repeat_path=repeat_path_for_unification,
            skip_svtype=True,
        )

        print()
        print("VCF unification completed successfully.")
        print(f"Unified VCF saved to: {output_path}")

    except KeyboardInterrupt:
        print()
        print("Operation cancelled by user.")

    except Exception as error:
        print()
        print(f"VCF unification failed: {error}")
        raise

    finally:
        if (
            temporary_repeat_path
            and os.path.exists(temporary_repeat_path)
        ):
            try:
                os.remove(temporary_repeat_path)
                print("Temporary modified repeat VCF removed.")
            except OSError as error:
                print(
                    "Warning: temporary repeat VCF could not "
                    f"be removed: {error}"
                )


if __name__ == "__main__":
    main()