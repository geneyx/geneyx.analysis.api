# ONT VCF Unification

This utility unifies Oxford Nanopore (EPI2ME) structural variant, copy number variant, and repeat VCFs into a single VCF compatible with downstream Geneyx workflows.

The script automatically detects common EPI2ME output files, optionally modifies repeat records for compatibility, and creates a unified VCF.

---

## Features

- Interactive command-line interface
- Works on Windows (WSL), Linux, and macOS
- Accepts dragged-and-dropped folders or pasted paths
- Automatically detects:
  - SV VCF
  - CNV VCF
  - Repeat VCF
- Allows manual correction if detection is incorrect
- Supports:
  - `.vcf`
  - `.vcf.gz`
- Optionally modifies STR records by adding `SVTYPE=REP`
- Produces a unified VCF

---

## Requirements

- Python 3.10+
- UnifyVcf.py

No additional dependencies are required.

---

## Directory Structure

```
ONT_Unification/
│
├── InteractiveEpi2meUnifyVcf.py
├── UnifyVcf.py
└── README.md
```

---

## Supported Inputs

The script automatically detects files such as

```
Sample.wf_sv.vcf.gz
Sample.wf_cnv.vcf.gz
Sample.wf_str.vcf.gz

Sample.wf_sv.vcf
Sample.wf_cnv.vcf
Sample.wf_str.vcf
```

Additional supported naming includes:

```
*.sv.vcf*
*.cnv.vcf*
*.str.vcf*
```

---

## Running

```
python3 InteractiveEpi2meUnifyVcf.py
```

The script will ask for:

1. Folder containing VCF files
2. Sample name (auto-detected when possible)
3. Confirmation of detected files
4. Output filename

---

## Repeat Modification

EPI2ME repeat calls can optionally be modified before unification.

The script converts

```
SVTYPE=DUP
```

to

```
SVTYPE=REP
```

or adds

```
SVTYPE=REP
```

when missing.

This option should be enabled for STRaglr-compatible EPI2ME repeat outputs.

---

## Output

Example:

```
HG002_unified.vcf
```

---

## Supported Platforms

- Ubuntu
- Windows Subsystem for Linux (WSL)
- macOS