#!/usr/bin/env python3

import os
import platform
import re
import shutil
import subprocess
import tempfile
from collections import Counter
from pathlib import Path
from typing import Optional

from UnifyVcf import run


# =========================================================================
# Platform detection
# =========================================================================

SYSTEM_NAME = platform.system()
IS_WINDOWS = SYSTEM_NAME == "Windows"
IS_MACOS = SYSTEM_NAME == "Darwin"
IS_LINUX = SYSTEM_NAME == "Linux"


def is_wsl() -> bool:
    """Return True when running inside Windows Subsystem for Linux."""
    if not IS_LINUX:
        return False

    release = platform.release().lower()

    if "microsoft" in release or "wsl" in release:
        return True

    try:
        version_text = Path("/proc/version").read_text(
            encoding="utf-8",
            errors="ignore",
        ).lower()

        return "microsoft" in version_text
    except OSError:
        return False


IS_WSL = is_wsl()
SCRIPT_DIRECTORY = Path(__file__).resolve().parent

DEFAULT_BED_FILENAME = "STRchive-disease-loci.hg38.TRGT.bed"
DEFAULT_BED_PATH = SCRIPT_DIRECTORY / DEFAULT_BED_FILENAME


# =========================================================================
# Path handling
# =========================================================================

def clean_dragged_path(path_text: str) -> str:
    """
    Clean a path pasted or dragged into a terminal.

    Handles:
      - surrounding quotes
      - escaped spaces
      - file:// paths from macOS
    """
    cleaned = path_text.strip()

    if (
        len(cleaned) >= 2
        and cleaned[0] == cleaned[-1]
        and cleaned[0] in ("'", '"')
    ):
        cleaned = cleaned[1:-1]

    if cleaned.startswith("file://"):
        cleaned = cleaned[7:]

    cleaned = cleaned.replace("\\ ", " ")

    return cleaned.strip()


def windows_path_to_wsl(path_text: str) -> str:
    """
    Convert a Windows path to a WSL-mounted path.

    Example:
        C:\\Users\\eliws\\Data
        -> /mnt/c/Users/eliws/Data
    """
    match = re.match(r"^([A-Za-z]):[\\/](.*)$", path_text)

    if not match:
        return path_text

    drive = match.group(1).lower()
    remainder = match.group(2).replace("\\", "/")

    return f"/mnt/{drive}/{remainder}"


def normalize_path(
    path_text: str,
    base_directory: Optional[Path] = None,
) -> Path:
    """
    Normalize Windows, macOS, Linux, WSL, and relative paths.
    """
    cleaned = clean_dragged_path(path_text)
    cleaned = os.path.expandvars(os.path.expanduser(cleaned))

    is_windows_path = bool(
        re.match(r"^[A-Za-z]:[\\/]", cleaned)
    )

    if is_windows_path:
        if IS_WINDOWS:
            cleaned = cleaned.replace("/", "\\")
        elif IS_WSL:
            cleaned = windows_path_to_wsl(cleaned)
        else:
            raise ValueError(
                "A Windows drive path was entered, but the script is "
                "not running on Windows or WSL."
            )

    path = Path(cleaned)

    if not path.is_absolute() and base_directory is not None:
        path = base_directory / path

    return path.resolve()


def is_vcf_path(path: Path) -> bool:
    """Return True for .vcf or .vcf.gz files."""
    lower_name = path.name.lower()

    return (
        lower_name.endswith(".vcf")
        or lower_name.endswith(".vcf.gz")
    )


# =========================================================================
# General prompts
# =========================================================================

def prompt_yes_no(
    prompt_text: str,
    default: bool = False,
) -> bool:
    """Prompt for a yes/no response."""
    display = "Y/n" if default else "y/N"

    while True:
        answer = input(
            f"{prompt_text} [{display}]: "
        ).strip().lower()

        if not answer:
            return default

        if answer in ("y", "yes"):
            return True

        if answer in ("n", "no"):
            return False

        print("Please enter y or n.")


def prompt_directory() -> Path:
    """Prompt for the directory containing PacBio VCF files."""
    print()
    print("Select the folder containing the PacBio VCF files.")
    print("Drag the folder here, paste its path, or press Enter")
    print("to use the current directory.")
    print()

    while True:
        value = input("> ").strip() or "."

        try:
            directory = normalize_path(value)
        except ValueError as error:
            print()
            print(f"Invalid path: {error}")
            continue

        if directory.is_dir():
            print()
            print("Using directory:")
            print(directory)
            return directory

        print()
        print("Directory not found:")
        print(directory)
        print("Please try again.")


def prompt_sample_name(
    inferred_sample: Optional[str],
) -> str:
    """Prompt for the sample name."""
    while True:
        if inferred_sample:
            value = input(
                f"Sample name [{inferred_sample}]: "
            ).strip()

            if not value:
                return inferred_sample
        else:
            value = input("Sample name: ").strip()

        if value:
            return value

        print("A sample name is required.")


def prompt_file_path(
    label: str,
    current_path: Optional[str],
    base_directory: Path,
    required_suffixes: tuple[str, ...] = (".vcf", ".vcf.gz"),
) -> Optional[str]:
    """
    Prompt for a replacement input file.

    Enter:
      - a path to select a file
      - Enter to keep the current file
      - 0 to skip this file type
    """
    print()

    if current_path:
        print(f"Current {label} file:")
        print(current_path)
        print()
        print(
            f"Drag or paste the correct {label} file, press Enter "
            "to keep the current selection, or enter 0 to skip."
        )
    else:
        print(
            f"Drag or paste the {label} file, or enter 0 to skip."
        )

    while True:
        value = input("> ").strip()

        if not value and current_path:
            return current_path

        if value == "0":
            return None

        if not value:
            print("Enter a file path or 0 to skip.")
            continue

        try:
            file_path = normalize_path(
                value,
                base_directory=base_directory,
            )
        except ValueError as error:
            print()
            print(f"Invalid path: {error}")
            continue

        if not file_path.is_file():
            print()
            print("File not found:")
            print(file_path)
            continue

        lower_name = file_path.name.lower()

        if not any(
            lower_name.endswith(suffix.lower())
            for suffix in required_suffixes
        ):
            print()
            print(
                "Warning: the file does not have an expected extension."
            )

            if not prompt_yes_no(
                "Use this file anyway?",
                default=False,
            ):
                continue

        return str(file_path)


# =========================================================================
# PacBio filename patterns
# =========================================================================

SV_CNV_PATTERNS = (
    # Current Sawfish combined SV/CNV output
    ".structural_variants.phased.vcf.gz",
    ".structural_variants.phased.vcf",
    "_structural_variants.phased.vcf.gz",
    "_structural_variants.phased.vcf",

    # Other PacBio structural-variant naming
    ".structural_variants.vcf.gz",
    ".structural_variants.vcf",
    "_structural_variants.vcf.gz",
    "_structural_variants.vcf",

    ".pbsv.vcf.gz",
    ".pbsv.vcf",
    "_pbsv.vcf.gz",
    "_pbsv.vcf",

    ".sv.vcf.gz",
    ".sv.vcf",
    "_sv.vcf.gz",
    "_sv.vcf",
)


LEGACY_CNV_PATTERNS = (
    # Separate CNV VCFs from older workflows
    ".cnv.vcf.gz",
    ".cnv.vcf",
    "_cnv.vcf.gz",
    "_cnv.vcf",

    ".pbsv.cnv.vcf.gz",
    ".pbsv.cnv.vcf",
    "_pbsv_cnv.vcf.gz",
    "_pbsv_cnv.vcf",

    ".structural_variants.cnv.vcf.gz",
    ".structural_variants.cnv.vcf",
)


REPEAT_PATTERNS = (
    ".trgt.sorted.vcf.gz",
    ".trgt.sorted.vcf",
    "_trgt.sorted.vcf.gz",
    "_trgt.sorted.vcf",

    ".trgt.vcf.gz",
    ".trgt.vcf",
    "_trgt.vcf.gz",
    "_trgt.vcf",

    ".repeats.vcf.gz",
    ".repeats.vcf",
    ".repeat.vcf.gz",
    ".repeat.vcf",
)


GENOME_BUILD_TOKENS = (
    "grch38",
    "hg38",
    "grch37",
    "hg19",
    "t2t-chm13",
    "chm13",
)


# =========================================================================
# File discovery
# =========================================================================

def list_vcf_files(directory: Path) -> list[Path]:
    """Return VCF files directly inside the selected directory."""
    return sorted(
        [
            path
            for path in directory.iterdir()
            if path.is_file() and is_vcf_path(path)
        ],
        key=lambda path: path.name.lower(),
    )


def remove_genome_build_suffix(prefix: str) -> str:
    """Remove a trailing genome-build token from a sample prefix."""
    for build in GENOME_BUILD_TOKENS:
        for separator in (".", "_", "-"):
            suffix = f"{separator}{build}"

            if prefix.lower().endswith(suffix.lower()):
                return prefix[:-len(suffix)]

    return prefix


def remove_known_suffix(filename: str) -> Optional[str]:
    """
    Remove a recognized caller suffix and genome-build token.

    Example:
        HG002.GRCh38.trgt.sorted.vcf.gz
        -> HG002
    """
    patterns = (
        SV_CNV_PATTERNS
        + LEGACY_CNV_PATTERNS
        + REPEAT_PATTERNS
    )

    lower_filename = filename.lower()

    for pattern in sorted(
        patterns,
        key=len,
        reverse=True,
    ):
        if lower_filename.endswith(pattern.lower()):
            prefix = filename[:-len(pattern)]

            return remove_genome_build_suffix(prefix)

    return None


def infer_sample_names(
    vcf_files: list[Path],
) -> list[tuple[str, int]]:
    """Return inferred sample prefixes ordered by frequency."""
    prefixes = []

    for path in vcf_files:
        prefix = remove_known_suffix(path.name)

        if prefix:
            prefixes.append(prefix)

    return Counter(prefixes).most_common()


def choose_inferred_sample(
    sample_counts: list[tuple[str, int]],
) -> Optional[str]:
    """Choose an inferred sample when several are detected."""
    if not sample_counts:
        return None

    if len(sample_counts) == 1:
        return sample_counts[0][0]

    print()
    print("Multiple possible sample names were detected:")

    for index, (sample_name, count) in enumerate(
        sample_counts,
        start=1,
    ):
        print(
            f"  {index}. {sample_name} "
            f"({count} recognized file(s))"
        )

    print("  0. Enter a sample name manually")

    while True:
        choice = input("Select the sample: ").strip()

        if choice == "0":
            return None

        if choice.isdigit():
            selected_index = int(choice)

            if 1 <= selected_index <= len(sample_counts):
                return sample_counts[selected_index - 1][0]

        print("Enter a valid number from the list.")


def filename_matches_sample(
    filename: str,
    sample_name: str,
) -> bool:
    """Check whether a filename belongs to the selected sample."""
    filename_lower = filename.lower()
    sample_lower = sample_name.lower()

    return (
        filename_lower.startswith(sample_lower + ".")
        or filename_lower.startswith(sample_lower + "_")
        or filename_lower.startswith(sample_lower + "-")
        or filename_lower == sample_lower
    )


def matches_variant_pattern(
    filename: str,
    patterns: tuple[str, ...],
) -> bool:
    """Check whether a filename ends with a recognized suffix."""
    lower_filename = filename.lower()

    return any(
        lower_filename.endswith(pattern.lower())
        for pattern in patterns
    )


def find_matching_files(
    directory: Path,
    sample_name: str,
    patterns: tuple[str, ...],
) -> list[Path]:
    """Find files matching the selected sample and file type."""
    matches = []

    for path in directory.iterdir():
        if not path.is_file():
            continue

        if not filename_matches_sample(
            path.name,
            sample_name,
        ):
            continue

        if matches_variant_pattern(
            path.name,
            patterns,
        ):
            matches.append(path)

    return sorted(
        set(matches),
        key=lambda path: path.name.lower(),
    )


def select_detected_match(
    label: str,
    matches: list[Path],
) -> Optional[str]:
    """Select a detected file or prompt when several match."""
    if not matches:
        print(f"{label}: not detected")
        return None

    if len(matches) == 1:
        print(f"{label}: {matches[0].name}")
        return str(matches[0])

    print()
    print(f"Multiple {label} files were detected:")

    for index, path in enumerate(matches, start=1):
        print(f"  {index}. {path.name}")

    print("  0. Skip")

    while True:
        choice = input(
            f"Select the {label} file: "
        ).strip()

        if choice == "0":
            return None

        if choice.isdigit():
            selected_index = int(choice)

            if 1 <= selected_index <= len(matches):
                return str(matches[selected_index - 1])

        print("Enter a valid number from the list.")


def detect_sample_files(
    directory: Path,
    sample_name: str,
) -> tuple[Optional[str], Optional[str], Optional[str]]:
    """Detect combined SV/CNV, legacy CNV, and TRGT files."""
    print()
    print("Automatically detected PacBio files:")
    print()

    sv_cnv_path = select_detected_match(
        "SV/CNV",
        find_matching_files(
            directory,
            sample_name,
            SV_CNV_PATTERNS,
        ),
    )

    legacy_cnv_path = select_detected_match(
        "Separate CNV (legacy/optional)",
        find_matching_files(
            directory,
            sample_name,
            LEGACY_CNV_PATTERNS,
        ),
    )

    repeat_path = select_detected_match(
        "TRGT repeat",
        find_matching_files(
            directory,
            sample_name,
            REPEAT_PATTERNS,
        ),
    )

    return sv_cnv_path, legacy_cnv_path, repeat_path


# =========================================================================
# Selection review
# =========================================================================

def display_path(path: Optional[str]) -> str:
    """Return a readable value for an optional path."""
    return path if path else "Not selected"


def print_file_selections(
    sv_cnv_path: Optional[str],
    legacy_cnv_path: Optional[str],
    repeat_path: Optional[str],
) -> None:
    """Display current selections."""
    print()
    print("Current file selections:")
    print(f"  SV/CNV:                {display_path(sv_cnv_path)}")
    print(f"  Separate CNV (legacy): {display_path(legacy_cnv_path)}")
    print(f"  TRGT repeat:           {display_path(repeat_path)}")


def review_file_selections(
    directory: Path,
    sv_cnv_path: Optional[str],
    legacy_cnv_path: Optional[str],
    repeat_path: Optional[str],
) -> tuple[Optional[str], Optional[str], Optional[str]]:
    """Allow the user to replace detected files."""
    print_file_selections(
        sv_cnv_path,
        legacy_cnv_path,
        repeat_path,
    )

    if prompt_yes_no(
        "\nAre these files correct?",
        default=True,
    ):
        return sv_cnv_path, legacy_cnv_path, repeat_path

    while True:
        print()
        print("Which selection would you like to change?")
        print("  1. SV/CNV")
        print("  2. Separate CNV (legacy/optional)")
        print("  3. TRGT repeat")
        print("  4. Review current selections")
        print("  0. Finish selecting files")

        choice = input("Selection: ").strip()

        if choice == "1":
            sv_cnv_path = prompt_file_path(
                "SV/CNV",
                current_path=sv_cnv_path,
                base_directory=directory,
            )

        elif choice == "2":
            legacy_cnv_path = prompt_file_path(
                "separate CNV",
                current_path=legacy_cnv_path,
                base_directory=directory,
            )

        elif choice == "3":
            repeat_path = prompt_file_path(
                "TRGT repeat",
                current_path=repeat_path,
                base_directory=directory,
            )

        elif choice == "4":
            print_file_selections(
                sv_cnv_path,
                legacy_cnv_path,
                repeat_path,
            )

        elif choice == "0":
            return sv_cnv_path, legacy_cnv_path, repeat_path

        else:
            print("Enter a valid number from the menu.")


# =========================================================================
# Optional BED filtering
# =========================================================================

def prompt_bed_file(
    directory: Path,
) -> Optional[str]:
    """
    Find or prompt for the STRchive BED file.

    Returns None when the user chooses to continue without filtering.
    """
    suggested_bed: Optional[Path] = None

    if DEFAULT_BED_PATH.is_file():
        suggested_bed = DEFAULT_BED_PATH
    else:
        local_bed = directory / DEFAULT_BED_FILENAME

        if local_bed.is_file():
            suggested_bed = local_bed

    if suggested_bed:
        print()
        print("Detected STRchive BED file:")
        print(suggested_bed)

        if prompt_yes_no(
            "Use this BED file?",
            default=True,
        ):
            return str(suggested_bed)

    print()
    print("No STRchive BED file has been selected.")
    print()
    print("  1. Drag or paste a BED file")
    print("  2. Continue without repeat filtering")
    print("  0. Cancel")

    while True:
        choice = input("Selection: ").strip()

        if choice == "2":
            return None

        if choice == "0":
            raise KeyboardInterrupt

        if choice != "1":
            print("Enter 1, 2, or 0.")
            continue

        print()
        print("Drag or paste the STRchive BED file.")

        value = input("> ").strip()

        if not value:
            print("No path was entered.")
            continue

        try:
            bed_path = normalize_path(
                value,
                base_directory=directory,
            )
        except ValueError as error:
            print(f"Invalid path: {error}")
            continue

        if not bed_path.is_file():
            print(f"File not found: {bed_path}")
            continue

        if not bed_path.name.lower().endswith(
            (".bed", ".bed.gz")
        ):
            print(
                "Warning: the selected file does not end with "
                ".bed or .bed.gz."
            )

            if not prompt_yes_no(
                "Use it anyway?",
                default=False,
            ):
                continue

        return str(bed_path)


def ensure_bedtools_available() -> None:
    """Raise an informative error if bedtools is unavailable."""
    if shutil.which("bedtools") is None:
        raise RuntimeError(
            "bedtools was not found.\n\n"
            "Ubuntu/WSL:\n"
            "  sudo apt update && sudo apt install -y bedtools\n\n"
            "macOS with Homebrew:\n"
            "  brew install bedtools"
        )


def strip_vcf_extensions(filename: str) -> str:
    """Remove .vcf or .vcf.gz from a filename."""
    lower_name = filename.lower()

    if lower_name.endswith(".vcf.gz"):
        return filename[:-7]

    if lower_name.endswith(".vcf"):
        return filename[:-4]

    return Path(filename).stem


def filter_repeats_vcf(
    repeat_path: str,
    bed_path: str,
    output_path: str,
) -> str:
    """Filter a TRGT VCF using bedtools intersect."""
    ensure_bedtools_available()

    repeat_file = Path(repeat_path)
    bed_file = Path(bed_path)
    filtered_file = Path(output_path)

    if not repeat_file.is_file():
        raise FileNotFoundError(
            f"Repeat VCF does not exist: {repeat_file}"
        )

    if not bed_file.is_file():
        raise FileNotFoundError(
            f"BED file does not exist: {bed_file}"
        )

    filtered_file.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    command = [
        "bedtools",
        "intersect",
        "-a",
        str(repeat_file),
        "-b",
        str(bed_file),
        "-header",
    ]

    with filtered_file.open(
        "w",
        encoding="utf-8",
    ) as output_handle:
        result = subprocess.run(
            command,
            stdout=output_handle,
            stderr=subprocess.PIPE,
            text=True,
            check=False,
        )

    if result.returncode != 0:
        try:
            filtered_file.unlink()
        except OSError:
            pass

        raise RuntimeError(
            "bedtools repeat filtering failed.\n"
            f"Command: {' '.join(command)}\n"
            f"Error: {result.stderr.strip()}"
        )

    return str(filtered_file)


def count_vcf_records(vcf_path: str) -> int:
    """Count non-header records in an uncompressed VCF."""
    count = 0

    with open(
        vcf_path,
        "r",
        encoding="utf-8",
    ) as handle:
        for line in handle:
            if line and not line.startswith("#"):
                count += 1

    return count


# =========================================================================
# Output handling
# =========================================================================

def safe_sample_filename(sample_name: str) -> str:
    """Convert a sample name into a safe filename component."""
    cleaned = re.sub(
        r'[<>:"/\\|?*\x00-\x1f]',
        "_",
        sample_name,
    )

    return cleaned.strip().strip(".") or "sample"


def prompt_output_path(
    directory: Path,
    sample_name: str,
) -> str:
    """Prompt for the unified output VCF."""
    default_path = (
        directory
        / f"{safe_sample_filename(sample_name)}_unified.vcf"
    )

    print()
    print("Unified output VCF")
    print(f"Default: {default_path}")
    print("Press Enter to use the default or enter another path.")

    while True:
        value = input("> ").strip()

        if not value:
            output_path = default_path
        else:
            cleaned = clean_dragged_path(value)

            is_complete_path = (
                bool(re.match(r"^[A-Za-z]:[\\/]", cleaned))
                or cleaned.startswith(("/", "~", "."))
            )

            try:
                if is_complete_path:
                    output_path = normalize_path(cleaned)
                else:
                    output_path = (
                        directory / cleaned
                    ).resolve()
            except ValueError as error:
                print(f"Invalid output path: {error}")
                continue

        if not output_path.parent.is_dir():
            print(
                f"Output directory does not exist: "
                f"{output_path.parent}"
            )
            continue

        if not output_path.name.lower().endswith(".vcf"):
            print(
                "The unified output should normally end with .vcf."
            )

            if not prompt_yes_no(
                "Use this filename anyway?",
                default=False,
            ):
                continue

        if output_path.exists():
            if not prompt_yes_no(
                f"{output_path.name} already exists. Overwrite it?",
                default=False,
            ):
                continue

        return str(output_path)


# =========================================================================
# Main workflow
# =========================================================================

def main() -> None:
    """Run the interactive PacBio unification workflow."""
    print("=" * 72)
    print("Interactive PacBio VCF Unification Tool")
    print("=" * 72)
    print(f"Platform: {SYSTEM_NAME}")

    if IS_WSL:
        print("Environment: Windows Subsystem for Linux")
    elif IS_MACOS:
        print("Environment: macOS")
    elif IS_WINDOWS:
        print("Environment: native Windows")
        print(
            "Note: bedtools must be available in PATH if repeat "
            "filtering is selected."
        )
    elif IS_LINUX:
        print("Environment: Linux")

    directory = prompt_directory()
    vcf_files = list_vcf_files(directory)

    if not vcf_files:
        print()
        print("No .vcf or .vcf.gz files were found in:")
        print(directory)
        return

    print()
    print(f"Found {len(vcf_files)} VCF file(s):")

    for path in vcf_files:
        print(f"  - {path.name}")

    sample_counts = infer_sample_names(vcf_files)
    inferred_sample = choose_inferred_sample(sample_counts)

    print()

    if inferred_sample:
        print(f"Inferred sample name: {inferred_sample}")
    else:
        print("A sample name could not be inferred automatically.")

    sample_name = prompt_sample_name(inferred_sample)

    sv_cnv_path, legacy_cnv_path, repeat_path = detect_sample_files(
        directory,
        sample_name,
    )

    sv_cnv_path, legacy_cnv_path, repeat_path = review_file_selections(
        directory=directory,
        sv_cnv_path=sv_cnv_path,
        legacy_cnv_path=legacy_cnv_path,
        repeat_path=repeat_path,
    )

    if not any(
        [
            sv_cnv_path,
            legacy_cnv_path,
            repeat_path,
        ]
    ):
        print()
        print("No input VCF files were selected.")
        return

    # Prevent the same combined Sawfish file from being used twice.
    if (
        sv_cnv_path
        and legacy_cnv_path
        and Path(sv_cnv_path).resolve()
        == Path(legacy_cnv_path).resolve()
    ):
        print()
        print(
            "The same file was selected as both SV/CNV and separate CNV."
        )
        print(
            "The combined file must only be passed once. "
            "The separate CNV selection will be cleared."
        )

        legacy_cnv_path = None

    filter_repeats = False
    bed_path: Optional[str] = None

    if repeat_path:
        print()
        filter_repeats = prompt_yes_no(
            "Filter TRGT repeats to STRchive disease loci?",
            default=True,
        )

        if filter_repeats:
            bed_path = prompt_bed_file(directory)

            if not bed_path:
                print()
                print(
                    "No BED file was selected. The complete TRGT VCF "
                    "will be used without filtering."
                )

                filter_repeats = False

    output_path = prompt_output_path(
        directory,
        sample_name,
    )

    print()
    print("=" * 72)
    print("Final configuration")
    print("=" * 72)
    print(f"Sample:                {sample_name}")
    print(f"SV/CNV:                {display_path(sv_cnv_path)}")
    print(f"Separate CNV (legacy): {display_path(legacy_cnv_path)}")
    print(f"TRGT repeat:           {display_path(repeat_path)}")
    print(
        f"Repeat filtering:      "
        f"{'STRchive disease loci' if filter_repeats else 'None'}"
    )
    print(f"STRchive BED:          {display_path(bed_path)}")
    print(f"Output:                {output_path}")
    print()

    if not prompt_yes_no(
        "Continue with PacBio VCF unification?",
        default=True,
    ):
        print("Cancelled.")
        return

    filtered_repeat_path: Optional[str] = None
    temporary_filtered_path: Optional[str] = None

    try:
        # By default, use the complete TRGT VCF.
        repeat_path_for_unification = repeat_path

        if repeat_path and filter_repeats and bed_path:
            keep_filtered = prompt_yes_no(
                "Keep the filtered TRGT VCF?",
                default=True,
            )

            repeat_file = Path(repeat_path)
            base_name = strip_vcf_extensions(repeat_file.name)

            if keep_filtered:
                filtered_path = (
                    repeat_file.parent
                    / f"{base_name}_filtered.vcf"
                )
            else:
                temp_file = tempfile.NamedTemporaryFile(
                    prefix=(
                        f"{safe_sample_filename(sample_name)}"
                        "_filtered_trgt_"
                    ),
                    suffix=".vcf",
                    delete=False,
                )
                temp_file.close()

                filtered_path = Path(temp_file.name)
                temporary_filtered_path = str(filtered_path)

            print()
            print("Filtering TRGT repeat calls...")
            print(f"  Repeat VCF: {repeat_path}")
            print(f"  BED file:   {bed_path}")
            print(f"  Output:     {filtered_path}")

            filtered_repeat_path = filter_repeats_vcf(
                repeat_path=repeat_path,
                bed_path=bed_path,
                output_path=str(filtered_path),
            )

            repeat_count = count_vcf_records(
                filtered_repeat_path
            )

            print(
                f"Filtered repeat VCF contains "
                f"{repeat_count} record(s)."
            )

            if repeat_count == 0:
                print()
                print(
                    "Warning: no repeat records overlapped the BED file."
                )
                print(
                    "Confirm that the VCF and BED use matching chromosome "
                    "names, such as chr1 versus 1."
                )

                if prompt_yes_no(
                    "Use the complete unfiltered TRGT VCF instead?",
                    default=True,
                ):
                    repeat_path_for_unification = repeat_path
                elif prompt_yes_no(
                    "Continue with the empty filtered repeat VCF?",
                    default=False,
                ):
                    repeat_path_for_unification = filtered_repeat_path
                else:
                    print("Cancelled.")
                    return
            else:
                repeat_path_for_unification = filtered_repeat_path

        print()
        print("Running VCF unification...")

        run(
            output_path=output_path,
            sv_path=sv_cnv_path,
            cnv_path=legacy_cnv_path,
            repeat_path=repeat_path_for_unification,
            skip_svtype=False,
        )

        print()
        print("PacBio VCF unification completed successfully.")
        print(f"Unified VCF saved to: {output_path}")

        if (
            filtered_repeat_path
            and not temporary_filtered_path
        ):
            print(
                "Filtered TRGT VCF saved to: "
                f"{filtered_repeat_path}"
            )

    except KeyboardInterrupt:
        print()
        print("Operation cancelled by user.")

    except Exception as error:
        print()
        print(f"PacBio VCF unification failed: {error}")
        raise

    finally:
        if (
            temporary_filtered_path
            and Path(temporary_filtered_path).exists()
        ):
            try:
                Path(temporary_filtered_path).unlink()
                print("Temporary filtered TRGT VCF removed.")
            except OSError as error:
                print(
                    "Warning: the temporary filtered VCF could not "
                    f"be removed: {error}"
                )


if __name__ == "__main__":
    main()