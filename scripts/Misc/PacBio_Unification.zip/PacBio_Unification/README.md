# PacBio VCF Unification

This utility unifies PacBio structural variant, copy number variant, and TRGT repeat VCFs into a single VCF compatible with downstream Geneyx workflows.

The script supports both legacy PacBio outputs and current Sawfish/TRGT workflows.

---

## Features

- Interactive command-line interface
- Windows (WSL), Linux, and macOS support
- Drag-and-drop folder selection
- Automatic sample detection
- Automatic file detection
- Manual correction of detected files
- Optional STRchive repeat filtering
- Supports:
  - `.vcf`
  - `.vcf.gz`

---

## Requirements

Python 3.10+

Required files:

```
InteractivePacBioUnifyVcf.py
UnifyVcf.py
```

Optional:

```
STRchive-disease-loci.hg38.TRGT.bed
```

Only required when filtering TRGT repeats.

If filtering repeats, install:

Ubuntu / WSL

```
sudo apt install bedtools
```

macOS

```
brew install bedtools
```

---

## Directory Structure

```
PacBio_Unification/
│
├── InteractivePacBioUnifyVcf.py
├── UnifyVcf.py
├── STRchive-disease-loci.hg38.TRGT.bed
└── README.md
```

---

## Supported Inputs

### Current PacBio (Sawfish)

Automatically detects

```
HG002.GRCh38.structural_variants.phased.vcf.gz
HG002.GRCh38.trgt.sorted.vcf.gz
```

The structural variants file contains both

- Structural Variants
- Copy Number Variants

and is passed as the SV input.

---

### Legacy PacBio

Also supports separate CNV VCFs such as

```
sample.cnv.vcf.gz
sample.pbsv.cnv.vcf.gz
```

---

### Repeat Files

Supports

```
sample.trgt.sorted.vcf.gz
sample.trgt.vcf.gz
sample.repeat.vcf.gz
sample.repeats.vcf.gz
```

---

## Running

```
python3 InteractivePacBioUnifyVcf.py
```

The script will prompt for:

1. Folder containing PacBio VCFs
2. Sample name
3. File confirmation
4. Optional STRchive filtering
5. Output filename

---

## Repeat Filtering

If a TRGT VCF is detected the script asks

```
Filter TRGT repeats to STRchive disease loci?
```

Selecting **Yes**

- filters the repeat VCF with bedtools
- requires the STRchive BED file

Selecting **No**

- uses the complete TRGT VCF
- no BED file required

---

## Output

Example

```
HG002_unified.vcf
```

---

## Supported Platforms

- Ubuntu
- Windows Subsystem for Linux (WSL)
- macOS

---

## Notes

Current PacBio Sawfish output combines structural variants and copy number variants into a single VCF.

For current workflows, the script passes

```
structural_variants.phased.vcf.gz
```

only once to avoid duplicate records.

Separate CNV files are only used for legacy workflows.