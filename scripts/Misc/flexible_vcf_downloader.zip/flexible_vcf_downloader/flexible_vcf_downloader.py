
import requests
import sys

# Constants – replace with actual credentials
API_USER_ID = "enter_apiId"
API_USER_KEY = "enter_apiKey"
GET_SAMPLE_LIST_URL = "https://analysis.geneyx.com/api/Samples"
GET_VCF_FILE_URL = "https://analysis.geneyx.com/api/GetVcfSampleFile"

def get_all_samples():
    payload = {
        "ApiUserId": API_USER_ID,
        "ApiUserKey": API_USER_KEY,
        "pageSize": "1000"
    }
    response = requests.post(GET_SAMPLE_LIST_URL, json=payload)
    if response.status_code == 200:
        response_data = response.json()
        sample_sns = response_data.get("Data", [])
        print("\nAvailable Samples:")
        for sn in sample_sns:
            print("-", sn)
        return sample_sns
    else:
        print("Failed to fetch sample list:", response.status_code, response.text)
        return []

def download_files_for_sample(sample_sn):
    file_types = ["Snv", "Cnv", "Sv"]
    for file_type in file_types:
        payload = {
            "ApiUserId": API_USER_ID,
            "ApiUserKey": API_USER_KEY,
            "fileType": file_type,
            "sampleSn": sample_sn
        }
        response = requests.post(GET_VCF_FILE_URL, json=payload)
        if response.status_code == 200:
            filename = f"{sample_sn}_{file_type}.vcf"
            with open(filename, "wb") as f:
                f.write(response.content)
            print(f"Downloaded: {filename}")
        elif response.status_code == 404:
            print(f"No {file_type} file found for sample {sample_sn} (404 Not Found)")
        else:
            print(f"Failed to download {file_type} file: {response.status_code} - {response.text}")

def main():
    print("Choose an option:")
    print("1. View all available samples")
    print("2. Download all files for all samples")
    print("3. Enter specific sampleSn(s) to download")

    choice = input("Enter 1, 2, or 3: ").strip()

    if choice == "1":
        get_all_samples()
    elif choice == "2":
        samples = get_all_samples()
        for sn in samples:
            download_files_for_sample(sn)
    elif choice == "3":
        sn_input = input("Enter sampleSn(s), comma-separated: ")
        samples = [s.strip() for s in sn_input.split(",")]
        for sn in samples:
            download_files_for_sample(sn)
    else:
        print("Invalid option. Exiting.")

if __name__ == "__main__":
    main()
