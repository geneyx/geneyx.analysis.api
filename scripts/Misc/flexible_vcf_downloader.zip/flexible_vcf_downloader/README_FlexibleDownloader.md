
# Flexible Geneyx VCF Downloader

This Python-based utility lets you interact with the Geneyx API to:
- View all available samples
- Download all associated VCF files (SNV, CNV, SV)
- Download files for specific sampleSn IDs

---

## 🛠 Requirements

- Python 3.x
- `requests` package (install with `pip install requests`)

---

## 🚀 Usage

### Windows:
Double-click `run_flexible_downloader.bat`

### macOS/Linux:
Run the shell script:
```bash
chmod +x run_flexible_downloader.sh
./run_flexible_downloader.sh
```

---

## 🧠 Script Options

Upon running, you'll be prompted to choose:

1. **View all samples** — lists all available `sampleSn` values.
2. **Download all files** — fetches SNV, CNV, and SV VCFs for every sample.
3. **Enter specific sampleSn(s)** — input one or more comma-separated IDs to download VCFs just for them.

---

## 🔐 API Credentials

Before using the script, open `flexible_vcf_downloader.py` and replace the placeholders:

```python
API_USER_ID = "enter_apiId"
API_USER_KEY = "enter_apiKey"
```

You’ll find these in your Geneyx API settings.

---

## 📁 Output

For each sample, the script creates:

```
<sampleSn>_Snv.vcf
<sampleSn>_Cnv.vcf
<sampleSn>_Sv.vcf
```

Missing files (404s) are reported clearly.

---

## 💬 Support

If you encounter issues, contact your administrator or the Geneyx support team.
