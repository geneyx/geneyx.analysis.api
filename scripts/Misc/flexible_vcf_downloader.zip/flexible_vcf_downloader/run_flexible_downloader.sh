
#!/bin/bash
python3 flexible_vcf_downloader.py
