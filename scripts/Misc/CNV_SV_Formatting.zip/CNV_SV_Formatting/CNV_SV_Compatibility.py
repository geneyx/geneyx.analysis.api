import vcf

def check_variants(vcf_file_path):
    vcf_reader = vcf.Reader(open(vcf_file_path, 'r'))

    incompatible_variants = 0

    for record in vcf_reader:
        if record.FORMAT is None:
            print(f"Variant at {record.CHROM}:{record.POS} is missing a FORMAT field.")
            incompatible_variants += 1
            continue

        format_tags = record.FORMAT.split(':')
        gt_present = 'GT' in format_tags
        cn_present = 'CN' in format_tags
        loh_present = 'LOH' in format_tags

        incompatible = False

        for sample in record.samples:
            sample_data = sample.data
            if (gt_present and ('GT' not in sample_data._fields or sample_data.GT is None)) or \
               (cn_present and ('CN' not in sample_data._fields or sample_data.CN is None)) or \
               (loh_present and ('LOH' not in sample_data._fields or sample_data.LOH is None)):
                print(f"Variant at {record.CHROM}:{record.POS} does not have an associated value for GT, CN, or LOH in the sample.")
                incompatible = True

        if incompatible:
            incompatible_variants += 1

    if incompatible_variants == 0:
        print("All variants in the VCF file appear to be compatible with the CNV/SV requirements for import.")
    elif incompatible_variants > 100:
        print("Please ensure the VCF is in the proper format before uploading.")
    else:
        print(f"Found {incompatible_variants} variants that are not compatible with the CNV/SV requirements for import.")

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        print("Usage: python3 script.py <path_to_vcf_file>")
    else:
        vcf_file_path = sys.argv[1]
        check_variants(vcf_file_path)
