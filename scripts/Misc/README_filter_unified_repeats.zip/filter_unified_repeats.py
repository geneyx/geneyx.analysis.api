#!/usr/bin/env python3
"""Filter an already-unified VCF: keep every non-repeat record (SV/CNV/etc.),
and keep SVTYPE=REP records only if they overlap a region in the BED file.

Overlap rule matches `bedtools intersect` (0-based half-open), record span is
[POS-1, END) using INFO/END, falling back to POS-1+len(REF).
Each record is written at most once (like `bedtools intersect -u`).

Usage: filter_unified_repeats.py -i in.vcf.gz -b repeats.bed -o out.vcf.gz
"""
import argparse, gzip, re, bisect, collections

def load_bed(path):
    regions = collections.defaultdict(list)
    with open(path) as fh:
        for line in fh:
            if not line.strip() or line.startswith(('#', 'track', 'browser')):
                continue
            f = line.split('\t')
            regions[f[0]].append((int(f[1]), int(f[2])))
    for c in regions:
        regions[c].sort()
    return regions

def overlaps(regions, chrom, start, end):
    ivs = regions.get(chrom)
    if not ivs:
        return False
    # candidates: intervals whose start < end; check any with end > start
    i = bisect.bisect_left(ivs, (end, -1))
    return any(e > start for s, e in ivs[max(0, i - 50):i])

def main():
    p = argparse.ArgumentParser()
    p.add_argument('-i', '--input', required=True)
    p.add_argument('-b', '--bed', required=True)
    p.add_argument('-o', '--output', required=True)
    a = p.parse_args()

    regions = load_bed(a.bed)
    end_re = re.compile(r'(?:^|;)END=(\d+)')
    opener = gzip.open if a.input.endswith('.gz') else open
    stats = collections.Counter()

    if a.output.endswith('.gz'):
        import pysam
        out = pysam.BGZFile(a.output, 'wb')
        write = lambda s: out.write(s.encode())
    else:
        out = open(a.output, 'w')
        write = out.write

    with opener(a.input, 'rt') as fh:
        for line in fh:
            if line.startswith('#'):
                write(line)
                continue
            f = line.split('\t', 8)
            info = f[7]
            if 'SVTYPE=REP' not in info.split(';'):
                stats['non_repeat_kept'] += 1
                write(line)
                continue
            start = int(f[1]) - 1
            m = end_re.search(info)
            end = int(m.group(1)) if m else start + len(f[3])
            if overlaps(regions, f[0], start, end):
                stats['repeat_kept'] += 1
                write(line)
            else:
                stats['repeat_removed'] += 1
    out.close()
    if a.output.endswith('.gz'):
        import pysam
        pysam.tabix_index(a.output, preset='vcf', force=True)
    for k, v in stats.items():
        print(f'{k}\t{v}')

if __name__ == '__main__':
    main()
