# filter_unified_repeats.py

Filters a **unified VCF** (SV + CNV + STR records in one file) so that only
**STRs at known pathogenic loci** are kept, while all other structural
variants pass through untouched.

Typical use: a PacBio/TRGT unified VCF has thousands of tandem-repeat calls
genome-wide. Most are not clinically relevant. This script drops every repeat
call that doesn't overlap a disease locus from STRchive, so the file uploaded
to Geneyx contains only the repeats worth reviewing.

## What it does

For every record in the input VCF:

| Record type | Action |
|---|---|
| Not a repeat (DEL, DUP, INS, INV, BND, CNV, ...) | **Kept** as-is |
| Repeat (`SVTYPE=REP`) overlapping a BED region | **Kept** |
| Repeat (`SVTYPE=REP`) not overlapping any BED region | **Removed** |

- The VCF header is copied unchanged.
- Each record is written at most once, even if it overlaps several BED regions.
- Record order is preserved, so a sorted input gives a sorted output.

### How overlap is decided

- A record covers `[POS-1, END)` (0-based, half-open, the same as BED).
  `END` comes from the INFO field; if there is none, `POS-1 + length(REF)` is used.
- A BED line `chrom  start  end` covers `[start, end)`.
- A record overlaps if the two ranges share at least one base. This is the
  same rule as `bedtools intersect -u`.

## Requirements

- Python 3
- `pysam` (only needed when the output name ends in `.gz`):
  ```bash
  pip install pysam
  ```

Run it in WSL/Linux. pysam is hard to install on native Windows Python.

## Usage

```bash
python filter_unified_repeats.py \
  -i SAMPLE_unified.vcf.gz \
  -b STRchive-disease-loci.hg38.TRGT.bed \
  -o SAMPLE_unified_STRchive_filtered.vcf.gz
```

| Option | Meaning |
|---|---|
| `-i`, `--input` | Unified VCF, `.vcf` or `.vcf.gz` |
| `-b`, `--bed` | BED file of regions to keep repeats in (e.g. STRchive pathogenic loci) |
| `-o`, `--output` | Output VCF. A name ending in `.gz` gives a bgzipped file **plus a `.tbi` index**; otherwise plain text |

When it finishes, it prints counts:

```
non_repeat_kept   62572
repeat_kept       68
repeat_removed    ...
```

### Example: UDN217065

`UDN217065_unified_STRchive_filtered.vcf.gz` was made with this script.
It contains 68 repeat records (out of the 75 loci in the STRchive BED in
Downloads) plus all of the sample's DEL/DUP/INS/INV/BND records.

Upload it to Geneyx as the structural file:

```bash
curl -X POST 'https://analysis.geneyx.com/Api/UploadFilesToSample' -H 'Accept: application/json' -F 'sampleSn=UDN217065' -F 'apiUserId=...' -F 'apiUserKey=...' -F 'customerAccountKey=...' -F 'structFile=@UDN217065_unified_STRchive_filtered.vcf.gz'
```

## The BED file

`STRchive-disease-loci.hg38.TRGT.bed` is the STRchive catalog of
disease-associated repeat loci in TRGT format. Only the first three columns
(chrom, start, end) are used; the 4th column (`ID=...;MOTIFS=...;STRUC=<TR>`)
is ignored. Lines starting with `#`, `track` or `browser` are skipped.

There are two versions on this machine. Use the same one for every sample in
a batch:

| Location | Size | Loci |
|---|---|---|
| `Downloads\STRchive-disease-loci.hg38.TRGT.bed` | 5,119 bytes | 75 |
| `Customer\ARUP\Proband_m8331\STRchive-disease-loci.hg38.TRGT.bed` | 5,890 bytes | 82 |

Any BED file works. For example, a gene-panel BED keeps only repeats in those genes.

## Things to watch for

- **Chromosome names must match.** The BED uses `chr1`, `chr2`, ... If the
  VCF uses `1`, `2`, ..., nothing will overlap and **every repeat is removed**.
  If `repeat_kept` is 0, check this first.
- **Genome build must match.** The BED is hg38; don't use it with hg19 VCFs.
- **Only `SVTYPE=REP` counts as a repeat.** If your unifier marks repeats
  differently (e.g. `SVTYPE=STR` or a `TRID=` tag with no SVTYPE), those
  records are treated as non-repeats and always kept.
- **Overwrites the output** without asking.
- **Only very small, non-overlapping BEDs are fully supported.** To find
  overlaps quickly, the script checks only the 50 BED regions starting just
  before each record's end. That covers STRchive and similar small catalogs.
  It can miss an overlap if a long BED region has more than 50 shorter regions
  starting inside it, so for large or nested BEDs, merge them first
  (`bedtools merge`).
