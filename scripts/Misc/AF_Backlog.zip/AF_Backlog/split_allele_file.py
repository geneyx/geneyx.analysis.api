import sys
input_file = sys.argv[1]
output_prefix = "allele_freq_part"

# -------- settings --------
CHUNK_SIZE_MB = 50   # for testing; later you can set to 450, etc.
# --------------------------
chunk_size_bytes = CHUNK_SIZE_MB * 1_000_000


def score_line(line: str) -> int:
    """
    Score = sum of numeric columns from 5th column onward (0-based index 4).
    Non-numeric fields are treated as 0.
    """
    parts = line.rstrip("\n").split("\t")
    total = 0
    for x in parts[4:]:
        try:
            total += int(x)
        except ValueError:
            try:
                total += float(x)
            except ValueError:
                pass
    return int(total)


def split_with_dedupe():
    with open(input_file, "r", encoding="utf-8") as fin:
        header = fin.readline()
        if not header:
            return

        part = 1
        fout = open(f"{output_prefix}_{part}.txt", "w", encoding="utf-8")
        fout.write(header)
        bytes_written = len(header.encode("utf-8"))

        current_key = None
        best_line = None
        best_score = -1

        def write_line(line: str):
            nonlocal part, fout, bytes_written
            line_bytes = len(line.encode("utf-8"))

            if bytes_written + line_bytes > chunk_size_bytes:
                fout.close()
                part += 1
                fout = open(f"{output_prefix}_{part}.txt", "w", encoding="utf-8")
                fout.write(header)
                bytes_written = len(header.encode("utf-8"))

            fout.write(line)
            bytes_written += line_bytes

        for line in fin:
            # split key: chr + pos (first two columns)
            parts = line.rstrip("\n")
            cols = parts.split("\t")
            if len(cols) < 2:
                # malformed line, just write as-is
                write_line(line)
                continue

            key = (cols[0], cols[1])
            s = score_line(line)

            if current_key is None:
                current_key = key
                best_line = line
                best_score = s
            elif key == current_key:
                # same position -> keep the one with higher score
                if s > best_score:
                    best_line = line
                    best_score = s
            else:
                # new position -> flush best_line for previous key
                if best_line is not None:
                    write_line(best_line)

                current_key = key
                best_line = line
                best_score = s

        # flush last pending line
        if best_line is not None:
            write_line(best_line)

        fout.close()


if __name__ == "__main__":
    split_with_dedupe()
    print("Done.")
