import glob
import os
import re
import copy
import time
import requests

UPLOAD_URL = "https://ga-us.geneyx.com/File/UploadLocalFreqBacklog"
CREATE_URL = "https://ga-us.geneyx.com/BacklogAf/Create"

# --- YOUR CREDENTIALS ---
COOKIE_HEADER = "xxx"
XSRF_TOKEN = "xxx"

FILE_PATTERN = "allele_freq_part_*.txt"

CREATE_BASE = {
    "GenomeBuild": 1,
    "PipelineType": 1,
    "SamplesCount": "20000",
}


def numeric_key(path: str) -> int:
    """Sort allele_freq_part_1,2,10,... in numeric order."""
    m = re.search(r'_(\d+)\.txt$', os.path.basename(path))
    return int(m.group(1)) if m else 0


def upload_and_create_all():
    files_to_upload = sorted(glob.glob(FILE_PATTERN), key=numeric_key)
    if not files_to_upload:
        print(f"No files found matching: {FILE_PATTERN}")
        return

    session = requests.Session()
    session.headers.update({
        "Cookie": COOKIE_HEADER,
        "Origin": "https://ga-us.geneyx.com",
        "Referer": "https://ga-us.geneyx.com/",
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "X-Xsrf-Token": XSRF_TOKEN,
        "Accept": "application/json, text/plain, */*",
    })

    total = len(files_to_upload)
    for i, path in enumerate(files_to_upload, start=1):

        filename = os.path.basename(path)
        print(f"\n===== Processing {i}/{total}: {filename} =====")

        # --------------------
        # (1) Upload file
        # --------------------
        with open(path, "rb") as f:
            files = {"file": (filename, f, "text/plain")}
            up_resp = session.post(UPLOAD_URL, files=files, timeout=600)

        print("Upload status:", up_resp.status_code)
        if up_resp.status_code != 200:
            print("Upload failed, body:")
            print(up_resp.text[:400])
            continue

        # --------------------
        # (2) Create backlog row
        # --------------------
        payload = copy.deepcopy(CREATE_BASE)
        payload["FileName"] = filename

        cr_resp = session.post(CREATE_URL, json=payload, timeout=600)
        print("Create status:", cr_resp.status_code)
        try:
            print("Create response:", cr_resp.json())
        except Exception:
            print("Create response text:", cr_resp.text[:400])

        # --------------------
        # (3) WAIT 20 MINUTES BEFORE NEXT CHUNK
        # --------------------
        if i < total:  # don’t wait after the very last file
            wait_seconds = 1 * 60
            next_time = time.strftime(
                "%Y-%m-%d %H:%M:%S",
                time.localtime(time.time() + wait_seconds)
            )
            print(f"\nWaiting 3 minutes before next chunk...")
            print(f"Next upload will begin at: {next_time}\n")
            time.sleep(wait_seconds)


if __name__ == "__main__":
    upload_and_create_all()
