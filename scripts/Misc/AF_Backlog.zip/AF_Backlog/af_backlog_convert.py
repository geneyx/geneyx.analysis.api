#!/usr/bin/env python3
import argparse, re

HEADER = ["chr","pos","ref","alt","hem","hom","het"]

def normalize_chr(v):
    v = v.strip()
    if v.upper() in {"M","MT"}: return "chrM"
    return v if v.startswith("chr") else "chr"+v

def split_fields(line):
    if "\t" in line:
        return line.rstrip("\n\r").split("\t")
    return re.split(r"\s+", line.strip())

def is_int(s): return re.fullmatch(r"\d+", s or "") is not None

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-i","--input", required=True)
    p.add_argument("-o","--output", required=True)   # use .txt
    p.add_argument("--crlf", action="store_true", help="Force Windows CRLF endings")
    args = p.parse_args()

    out_newline = "\r\n" if args.crlf else "\n"
    total=kept=skipped=0
    wrote_header=False

    with open(args.input, "r", encoding="utf-8", errors="replace") as fin, \
         open(args.output, "w", encoding="utf-8", newline="") as fout:

        for raw in fin:
            line = raw.strip("\r\n")
            if not line: 
                continue
            # skip your description lines like "#chr - Chromosome"
            if line.startswith("#"): 
                continue

            fields = split_fields(line)

            # write header once (normalized)
            if not wrote_header:
                # if the first non-comment line looks like a header, skip it
                lower = [c.lower() for c in fields]
                if set(lower) >= set(HEADER) or lower[:7]==HEADER:
                    wrote_header=True
                    fout.write("\t".join(HEADER) + out_newline)
                    continue
                # otherwise, assume data and still write header
                wrote_header=True
                fout.write("\t".join(HEADER) + out_newline)

            total += 1
            if len(fields) < 7:
                skipped += 1
                continue

            chr_v = normalize_chr(fields[0])
            pos, ref, alt = fields[1], fields[2].upper(), fields[3].upper()
            hem, hom, het = fields[4], fields[5], fields[6]

            if not (pos and re.fullmatch(r"\d+", pos)): 
                skipped += 1; continue
            if not (is_int(hem) and is_int(hom) and is_int(het)):
                skipped += 1; continue

            fout.write("\t".join([chr_v, pos, ref, alt, hem, hom, het]) + out_newline)
            kept += 1

    print(f"Done. rows_in={total}, rows_out={kept}, skipped={skipped}, out='{args.output}'")

if __name__ == "__main__":
    main()
