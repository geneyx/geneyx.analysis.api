import csv

input_file = "Geneyx_reformat_variants.txt"
filtered_file = "allele_frequency_filtered.txt"
removed_file = "allele_frequency_removed.txt"

with open(input_file, newline='') as infile, \
     open(filtered_file, 'w', newline='') as keep_out, \
     open(removed_file, 'w', newline='') as remove_out:

    reader = csv.reader(infile, delimiter='\t')
    keep_writer = csv.writer(keep_out, delimiter='\t', quoting=csv.QUOTE_NONE, escapechar='\\')
    remove_writer = csv.writer(remove_out, delimiter='\t', quoting=csv.QUOTE_NONE, escapechar='\\')

    header = next(reader)
    keep_writer.writerow(header)
    remove_writer.writerow(header)

    for row in reader:
        try:
            numeric_values = [float(x) for x in row[4:]]
        except ValueError:
            keep_writer.writerow(row)
            continue

        if all(v == 0 for v in numeric_values):
            remove_writer.writerow(row)
        else:
            keep_writer.writerow(row)

print("✅ Files successfully written with preserved tab formatting.")
