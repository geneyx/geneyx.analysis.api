#!/usr/bin/env python3
import argparse, csv, os, subprocess, sys
from datetime import datetime, timezone
from PacBioUnifyVcf import filter_and_run as pacbio_unify
from UnifyVcf import run as unify

def b(v): return str(v or '').strip().lower() in ('1','true','t','yes','y')
def val(row,k): return (row.get(k) or '').strip()
def req(path,label):
    if path and not os.path.exists(path): raise FileNotFoundError(f'{label} not found: {path}')
def add(cmd,flag,value):
    if value is not None and str(value).strip(): cmd.extend([flag,str(value).strip()])
def tail(s,n=1000): return (s or '')[-n:]

def prepare_structural(row, prepared_dir, default_pacbio_bed):
    sv,cnv,rep,roh=val(row,'svVcf'),val(row,'cnvVcf'),val(row,'repeatVcf'),val(row,'rohBed')
    for p,l in [(sv,'svVcf'),(cnv,'cnvVcf'),(rep,'repeatVcf'),(roh,'rohBed')]: req(p,l)
    if not rep and not roh and sum(bool(x) for x in (sv,cnv)) <= 1: return sv or cnv, ''
    platform=val(row,'platform').lower()
    if rep and not platform: raise ValueError('repeatVcf is present but platform is blank (use PacBio, ONT, or DRAGEN)')
    sid=val(row,'sampleId') or val(row,'patientId') or 'sample'
    out_base=os.path.join(prepared_dir,f'{sid}.structural.unified.vcf')
    if platform=='pacbio':
        bed=val(row,'repeatBed') or default_pacbio_bed
        if rep:
            if val(row,'genomeBuild').lower()!='hg38' and not val(row,'repeatBed'):
                raise ValueError('PacBio repeats for non-hg38 require repeatBed in the manifest')
            req(bed,'PacBio repeat BED')
        result=pacbio_unify(out_base,sv or None,cnv or None,rep or None,bed or None)
    elif platform=='ont':
        caller=val(row,'repeatCaller').lower()
        modify=b(row.get('modifyRepeatSvtype')) or caller=='straglr'
        result=unify(out_base,sv or None,cnv or None,rep or None,roh_bed_path=roh or None,skip_svtype=not modify)
    elif platform=='dragen':
        result=unify(out_base,sv or None,cnv or None,rep or None,roh_bed_path=roh or None,skip_svtype=False)
    elif rep:
        raise ValueError(f'Unsupported platform for repeatVcf: {val(row,"platform")}')
    else:
        result=unify(out_base,sv or None,cnv or None,None,roh_bed_path=roh or None,skip_svtype=True)
    return result, result

def main():
    root=os.path.dirname(os.path.abspath(__file__))
    p=argparse.ArgumentParser(description='Batch upload Geneyx samples from a TSV manifest')
    p.add_argument('--manifest',default='manifest.tsv'); p.add_argument('--config',default='ga.config.yml'); p.add_argument('--uploader',default=os.path.join(root,'ga_uploadSample.py'))
    p.add_argument('--python',default=sys.executable); p.add_argument('--log',default='upload_results.csv'); p.add_argument('--prepared-dir',default='_prepared_vcfs')
    p.add_argument('--pacbio-bed',default=os.path.join(root,'reference','STRchive-disease-loci.hg38.TRGT.bed')); p.add_argument('--stop-on-fail',action='store_true'); p.add_argument('--dry-run',action='store_true')
    a=p.parse_args(); req(a.manifest,'manifest'); os.makedirs(a.prepared_dir,exist_ok=True)
    cli=[('sampleId','--sampleId'),('sampleTakenDate','--sampleTakenDate'),('sampleSequenceDate','--sampleSequenceDate'),('sampleReceiveDate','--sampleReceiveDate'),('sampleType','--sampleType'),('sampleTarget','--sampleTarget'),('sampleSource','--sampleSource'),('seqMachineId','--seqMachineId'),('kitId','--kitId'),('genomeBuild','--genomeBuild'),('sampleNotes','--sampleNotes'),('sampleQcData','--sampleQcData'),('sampleAdvAnalysis','--sampleAdvAnalysis'),('excludeFromLAF','--excludeFromLAF'),('sampleRelation','--sampleRelation'),('bamUrl','--bamUrl'),('localBamUrl','--localBamUrl'),('methylationUrl','--methylationUrl'),('localMethylationUrl','--localMethylationUrl'),('patientId','--patientId'),('patientName','--patientName'),('patientGender','--patientGender'),('patientDateOfBirth','--patientDateOfBirth'),('patientConsanguinity','--patientConsanguinity'),('patientPopulationType','--patientPopulationType'),('patientPaternalAncestry','--patientPaternalAncestry'),('patientMaternalAncestry','--patientMaternalAncestry'),('patientFamilyHistory','--patientFamilyHistory'),('patientHasBioSample','--patientHasBioSample'),('patientUseConsentPersonal','--patientUseConsentPersonal'),('patientUseConsentClinical','--patientUseConsentClinical'),('groupAssignmentCode','--groupAssignmentCode'),('groupAssignmentName','--groupAssignmentName'),('customerAccountKey','--customerAccountKey')]
    fields=['timestamp','patientId','sampleId','platform','snvVcf','svVcf','cnvVcf','repeatVcf','preparedStructVcf','returncode','status','stdout_tail','stderr_tail']
    exists=os.path.exists(a.log)
    with open(a.log,'a',newline='',encoding='utf-8') as lf, open(a.manifest,'r',encoding='utf-8-sig',newline='') as mf:
        w=csv.DictWriter(lf,fieldnames=fields); 
        if not exists: w.writeheader()
        r=csv.DictReader(mf,delimiter='\t')
        for required in ('patientId','genomeBuild','sampleTarget','snvVcf'):
            if required not in (r.fieldnames or []): raise ValueError(f'Manifest missing required column: {required}')
        for i,row in enumerate(r,1):
            if not any(val(row,k) for k in ('patientId','snvVcf','svVcf','cnvVcf','repeatVcf')): continue
            prepared=''; rc=99; stdout=''; stderr=''
            try:
                snv=val(row,'snvVcf'); req(snv,'snvVcf')
                struct,prepared=prepare_structural(row,a.prepared_dir,a.pacbio_bed)
                cmd=[a.python,a.uploader,'--config',a.config]
                if snv: add(cmd,'--snvVcf',snv)
                if struct: add(cmd,'--svVcf',struct)
                for k,f in cli: add(cmd,f,row.get(k))
                if b(row.get('skipAnnotation')): cmd.append('--skipAnnotation')
                if a.dry_run: cmd.append('--dryRun')
                print(f'[{i}] {val(row,"sampleId") or val(row,"patientId")} platform={val(row,"platform") or "standard"}')
                q=subprocess.run(cmd,capture_output=True,text=True); rc=q.returncode; stdout=q.stdout or ''; stderr=q.stderr or ''
                if stdout: print(stdout.strip())
                if stderr: print(stderr.strip(),file=sys.stderr)
            except Exception as e: stderr=str(e)
            status='SUCCESS' if rc==0 else 'FAIL'
            w.writerow({'timestamp':datetime.now(timezone.utc).isoformat(),'patientId':val(row,'patientId'),'sampleId':val(row,'sampleId'),'platform':val(row,'platform'),'snvVcf':val(row,'snvVcf'),'svVcf':val(row,'svVcf'),'cnvVcf':val(row,'cnvVcf'),'repeatVcf':val(row,'repeatVcf'),'preparedStructVcf':prepared,'returncode':rc,'status':status,'stdout_tail':tail(stdout),'stderr_tail':tail(stderr)}); lf.flush()
            if rc!=0 and a.stop_on_fail: return rc
    print(f'Done. Results log: {a.log}'); return 0
if __name__=='__main__':
    try: sys.exit(main())
    except Exception as e: print(f'[ERROR] {e}',file=sys.stderr); sys.exit(1)
