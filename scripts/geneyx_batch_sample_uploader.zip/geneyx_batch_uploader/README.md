# Geneyx Batch Sample Uploader

Manifest-driven batch uploader for Geneyx. It supports standard SNV/SV/CNV uploads plus automatic structural-file preparation for **PacBio, ONT, and DRAGEN** repeat workflows.

## What the package does

For every manifest row, the batch runner validates the supplied files, prepares structural data when needed, and calls `ga_uploadSample.py`. Geneyx still receives the normal API inputs `snvFile` and `svFile`; repeats are prepared before upload rather than sent as a new API field.

### Structural workflow by platform

| Platform | Repeat handling | BED required? | SVTYPE behavior |
|---|---|---:|---|
| PacBio | Repeat VCF is filtered to configured disease loci, then unified with SV/CNV | Yes | Adds `SVTYPE=REP` when absent |
| ONT | Repeat VCF is unified directly | No | Existing recognized `SVTYPE` is preserved; STRaglr can add `SVTYPE=REP` |
| DRAGEN | Repeat VCF is unified directly | No | Adds `SVTYPE=REP` when absent |
| Standard / blank | SNV and optional SV/CNV upload; SV+CNV can be unified | No | No repeat-specific processing |

PacBio hg38 uses the bundled `reference/STRchive-disease-loci.hg38.TRGT.bed` by default. A different BED can be supplied per row in `repeatBed`. PacBio repeat rows using another genome build must specify a BED explicitly.

## Package contents

- `batch_upload_from_manifest.py` — main batch runner
- `ga_uploadSample.py` — Geneyx API uploader
- `UnifyVcf.py` — shared structural VCF unifier
- `PacBioUnifyVcf.py` — PacBio repeat filtering + unification
- `ONTUnifyVcf.py` — standalone ONT unifier
- `DragenUnifyVcf.py` — standalone DRAGEN unifier
- `ga_helperFunctions.py` — YAML/config helper
- `manifest.tsv` — blank full manifest template
- `examples/manifest_examples.tsv` — platform examples
- `reference/STRchive-disease-loci.hg38.TRGT.bed` — default PacBio hg38 repeat BED
- `ga.config.example.yml` — safe config template
- `legacy/ga_uploadSample_Trio.py` — previously created joined/trio uploader retained for reference

## Requirements

Python 3.8+ and:

```bash
pip install -r requirements.txt
```

System tools:

- `bgzip` — required whenever a unified structural VCF is created
- `bedtools` — required only when a PacBio `repeatVcf` is supplied

`bcftools`/`tabix` are only needed by the retained legacy trio uploader.

## Configure access

Copy the example config and fill in your Geneyx credentials:

```bash
cp ga.config.example.yml ga.config.yml
```

Then edit:

```yaml
server: https://YOUR-GENEYX-SERVER
apiUserId: YOUR_API_USER_ID
apiUserKey: YOUR_API_USER_KEY
```

Do not distribute a populated `ga.config.yml`.

## Manifest

The manifest is tab-delimited and contains one sample per row. Existing columns are preserved. The structural/repeat workflow adds these optional columns:

| Column | Purpose |
|---|---|
| `platform` | `PacBio`, `ONT`, `DRAGEN`, or blank for standard upload |
| `repeatVcf` | Original repeat VCF |
| `repeatCaller` | Optional caller name; `STRaglr` automatically enables repeat SVTYPE modification for ONT |
| `modifyRepeatSvtype` | `true/false`; forces `SVTYPE=REP` addition for ONT when needed |
| `repeatBed` | Optional PacBio repeat BED override |
| `rohBed` | Optional ROH BED, primarily for DRAGEN |

Core file columns are:

- `snvVcf`
- `svVcf`
- `cnvVcf`
- `repeatVcf`

`repeatVcf` is optional. If it is present, `platform` must also be present.

## PacBio example

```text
platform = PacBio
snvVcf = sample.small_variants.vcf.gz
svVcf = sample.structural_variants.vcf.gz
repeatVcf = sample.trgt.vcf.gz
genomeBuild = hg38
```

Processing is automatic:

1. Filter `repeatVcf` against the bundled disease-loci BED.
2. Add `SVTYPE=REP` to repeat records when needed.
3. Unify SV + CNV (if supplied) + filtered repeats.
4. Sort and bgzip the unified VCF.
5. Upload it through the existing Geneyx `svFile` field.

## ONT example

ONT does not require a repeat BED. Repeat files already containing a Geneyx-recognized structural type can be unified unchanged.

For STRaglr:

```text
platform = ONT
repeatCaller = STRaglr
repeatVcf = sample.straglr.vcf.gz
```

This adds `SVTYPE=REP` when it is absent.

## DRAGEN example

DRAGEN repeat files are unified directly; no repeat BED is required. `rohBed` may also be supplied.

## Run

```bash
python3 batch_upload_from_manifest.py \
  --manifest manifest.tsv \
  --config ga.config.yml
```

Useful options:

```bash
--dry-run              # prepare/check files and invoke uploader in dry-run mode
--stop-on-fail          # stop on first failed manifest row
--log upload_results.csv
--prepared-dir _prepared_vcfs
--pacbio-bed /path/to/alternate.hg38.bed
```

## Output and logging

`upload_results.csv` records the original SNV/SV/CNV/repeat inputs, platform, generated unified structural VCF, return code, status, and output/error tails. Prepared unified VCFs are retained in `_prepared_vcfs` for troubleshooting.

## Important VCF improvement

The shared unifier merges and deduplicates header declarations from all supplied VCFs instead of taking only the SV header and appending records from the other callers. This reduces the risk that CNV/repeat records reference INFO/FORMAT definitions missing from the final file.

## Notes

- The current Geneyx API still receives only `snvFile` and `svFile`.
- The manifest `repeatVcf` field is a preprocessing convenience, not a new Geneyx API parameter.
- Do not package or commit live API credentials.
