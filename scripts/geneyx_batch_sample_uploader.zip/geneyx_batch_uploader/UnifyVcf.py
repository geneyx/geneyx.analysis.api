#!/usr/bin/env python3
"""Utilities for creating one structural VCF from SV/CNV/repeat/ROH inputs."""
from __future__ import annotations
import gzip
import os
import shutil
import subprocess
from typing import Iterable, List, Optional, Tuple


def _open_text(path: str):
    return gzip.open(path, "rt", encoding="utf-8", errors="replace") if path.endswith(".gz") else open(path, "r", encoding="utf-8", errors="replace")


def _read_vcf(path: str) -> Tuple[List[str], str, List[str]]:
    meta, chrom, records = [], "", []
    with _open_text(path) as fh:
        for line in fh:
            if line.startswith("##"):
                meta.append(line)
            elif line.startswith("#CHROM"):
                chrom = line
            elif line.startswith("#"):
                meta.append(line)
            elif line.strip():
                records.append(line if line.endswith("\n") else line + "\n")
    if not chrom:
        raise ValueError(f"VCF is missing #CHROM header: {path}")
    return meta, chrom, records


def _merge_headers(parts: Iterable[Tuple[List[str], str, List[str]]]) -> Tuple[List[str], str]:
    seen, merged, chrom = set(), [], ""
    for meta, c, _ in parts:
        if not chrom:
            chrom = c
        for line in meta:
            key = line.rstrip("\n")
            if key not in seen:
                seen.add(key)
                merged.append(line if line.endswith("\n") else line + "\n")
    # Ensure REP/ROH symbolic ALT and INFO declarations exist when needed.
    additions = [
        '##ALT=<ID=REP,Description="Repeat expansion / repeat variant">\n',
        '##ALT=<ID=ROH,Description="Region of homozygosity">\n',
        '##INFO=<ID=SVTYPE,Number=1,Type=String,Description="Type of structural variant">\n',
        '##INFO=<ID=END,Number=1,Type=Integer,Description="End position of the variant">\n',
        '##INFO=<ID=ROH_SCORE,Number=1,Type=String,Description="ROH score">\n',
    ]
    for line in additions:
        if line.rstrip("\n") not in seen:
            merged.append(line)
            seen.add(line.rstrip("\n"))
    return merged, chrom


def _add_svtype_rep(line: str) -> str:
    cols = line.rstrip("\n").split("\t")
    if len(cols) < 8:
        raise ValueError("Repeat VCF record has fewer than 8 columns")
    info = cols[7]
    if "SVTYPE=" not in info:
        cols[7] = (info + ";" if info and info != "." else "") + "SVTYPE=REP"
    return "\t".join(cols) + "\n"


def _roh_records(path: str) -> List[str]:
    out = []
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if not line.strip() or line.startswith("#"):
                continue
            p = line.rstrip("\n").split("\t")
            if len(p) < 3:
                continue
            start, end = int(p[1]), int(p[2])
            pos = min(start, end) + 1
            end1 = max(start, end)
            score = p[3] if len(p) > 3 else "."
            out.append(f"{p[0]}\t{pos}\t.\tN\t<ROH>\t.\tPASS\tEND={end1};SVTYPE=ROH;ROH_SCORE={score}\tGT\t1/1\n")
    return out


def _sort_key(line: str):
    p = line.split("\t", 3)
    chrom = p[0]
    try:
        pos = int(p[1])
    except Exception:
        pos = 0
    # Natural-ish chromosome ordering; nonstandard contigs follow lexically.
    c = chrom.lower().removeprefix("chr")
    if c.isdigit():
        rank = (0, int(c))
    elif c == "x": rank = (1, 23)
    elif c == "y": rank = (1, 24)
    elif c in ("m", "mt"): rank = (1, 25)
    else: rank = (2, c)
    return rank, pos


def run(output_path: str, sv_path: Optional[str] = None, cnv_path: Optional[str] = None,
        repeat_path: Optional[str] = None, roh_bed_path: Optional[str] = None,
        skip_svtype: bool = False, bgzip_output: bool = True) -> str:
    inputs = [("sv", sv_path), ("cnv", cnv_path), ("repeat", repeat_path)]
    parsed = []
    records = []
    for kind, path in inputs:
        if not path:
            continue
        if not os.path.exists(path):
            raise FileNotFoundError(f"{kind} file not found: {path}")
        part = _read_vcf(path)
        parsed.append(part)
        recs = part[2]
        if kind == "repeat" and not skip_svtype:
            recs = [_add_svtype_rep(x) for x in recs]
        records.extend(recs)

    if roh_bed_path:
        if not os.path.exists(roh_bed_path):
            raise FileNotFoundError(f"ROH BED not found: {roh_bed_path}")
        records.extend(_roh_records(roh_bed_path))

    if not parsed and not roh_bed_path:
        raise ValueError("No structural input files were provided")
    if not parsed:
        raise ValueError("At least one VCF input is required when using ROH")

    meta, chrom = _merge_headers(parsed)
    records.sort(key=_sort_key)
    plain = output_path[:-3] if output_path.endswith(".gz") else output_path
    os.makedirs(os.path.dirname(os.path.abspath(plain)), exist_ok=True)
    with open(plain, "w", encoding="utf-8") as out:
        out.writelines(meta)
        out.write(chrom)
        out.writelines(records)

    if bgzip_output:
        bgzip = shutil.which("bgzip")
        if not bgzip:
            raise RuntimeError("bgzip is required to create the unified .vcf.gz output")
        subprocess.run([bgzip, "-f", plain], check=True)
        return plain + ".gz"
    return plain
