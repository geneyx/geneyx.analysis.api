#!/usr/bin/env python3
import argparse, json, ntpath, os, sys
import requests
import ga_helperFunctions as funcs
from UnifyVcf import run as unify_vcfs

def add(d,k,v):
    if v is not None and not (isinstance(v,str) and v.strip()==""): d[k]=v

def main():
    p=argparse.ArgumentParser(description='Upload a Geneyx sample')
    p.add_argument('--snvVcf'); p.add_argument('--svVcf'); p.add_argument('--cnvVcf')
    p.add_argument('--sampleId'); p.add_argument('--sampleTakenDate'); p.add_argument('--sampleSequenceDate'); p.add_argument('--sampleReceiveDate')
    p.add_argument('--sampleType',choices=['RnaSeq','DnaSeq'],default='DnaSeq'); p.add_argument('--sampleTarget',choices=['WholeGenome','Exome','GenePanel','TargetRegion','ClinicalExome'],default='Exome')
    p.add_argument('--sampleSource',choices=['GermLine','Tumor','Blood','Buccal','Mitochondria','Saliva'],default='GermLine'); p.add_argument('--seqMachineId'); p.add_argument('--kitId')
    p.add_argument('--genomeBuild',choices=['hg19','hg38'],default='hg19'); p.add_argument('--sampleNotes'); p.add_argument('--sampleQcData'); p.add_argument('--sampleAdvAnalysis'); p.add_argument('--excludeFromLAF')
    p.add_argument('--sampleRelation',choices=['Self','Mother','Father','Sibling','Twin','MotherRelative','FatherRelative','Other'],default='Self')
    p.add_argument('--bamUrl'); p.add_argument('--localBamUrl'); p.add_argument('--methylationUrl'); p.add_argument('--localMethylationUrl')
    p.add_argument('--patientId',required=True); p.add_argument('--patientName'); p.add_argument('--patientGender',choices=['F','M',''],default=''); p.add_argument('--patientDateOfBirth')
    p.add_argument('--patientConsanguinity'); p.add_argument('--patientPopulationType'); p.add_argument('--patientPaternalAncestry'); p.add_argument('--patientMaternalAncestry'); p.add_argument('--patientFamilyHistory')
    p.add_argument('--patientHasBioSample'); p.add_argument('--patientUseConsentPersonal'); p.add_argument('--patientUseConsentClinical'); p.add_argument('--groupAssignmentCode'); p.add_argument('--groupAssignmentName')
    p.add_argument('--skipAnnotation',action='store_true'); p.add_argument('--config','-c',default='ga.config.yml'); p.add_argument('--customerAccountKey','-a'); p.add_argument('--dryRun',action='store_true')
    a=p.parse_args()
    for label,path in [('SNV',a.snvVcf),('SV',a.svVcf),('CNV',a.cnvVcf)]:
        if path and not os.path.exists(path): raise FileNotFoundError(f'{label} file not found: {path}')
    if not any([a.snvVcf,a.svVcf,a.cnvVcf]): raise ValueError('No SNV nor SV/CNV file was provided')
    config=funcs.loadYamlFile(a.config)
    for k in ('server','apiUserId','apiUserKey'):
        if not config or not config.get(k): raise ValueError(f'Config missing required field: {k}')
    sv_path=a.svVcf or a.cnvVcf
    temp_combined=None
    if a.svVcf and a.cnvVcf:
        temp_combined=os.path.splitext(a.svVcf.split('.vcf')[0])[0]+'.sv_cnv.unified.vcf'
        sv_path=unify_vcfs(temp_combined,a.svVcf,a.cnvVcf,bgzip_output=True)
    sample_id=a.sampleId or ntpath.basename(a.snvVcf or sv_path)
    data={
      'ApiUserKey':config['apiUserKey'],'ApiUserID':config['apiUserId'],'CustomerAccountKey':a.customerAccountKey,
      'SampleSerialNumber':sample_id,'SampleSequenceDate':a.sampleSequenceDate,'SampleTakenDate':a.sampleTakenDate,'SampleReceivedDate':a.sampleReceiveDate,
      'SampleType':a.sampleType,'SampleTarget':a.sampleTarget,'SampleSource':a.sampleSource,'SampleSequenceMachineId':a.seqMachineId,'SampleEnrichmentKitId':a.kitId,
      'SampleGenomeBuild':a.genomeBuild,'SampleNotes':a.sampleNotes,'SampleRelation':a.sampleRelation,'SampleQcData':a.sampleQcData,'SampleAdvAnalysis':a.sampleAdvAnalysis,'ExcludeFromLAF':a.excludeFromLAF,
      'bamUrl':a.bamUrl,'localBamUrl':a.localBamUrl,'methylationUrl':a.methylationUrl,'localMethylationUrl':a.localMethylationUrl,
      'SnvFile':ntpath.basename(a.snvVcf) if a.snvVcf else None,'StructFile':ntpath.basename(sv_path) if sv_path else None,
      'SubjectId':a.patientId,'SubjectName':a.patientName,'SubjectGender':a.patientGender,'SubjectDateOfBirth':a.patientDateOfBirth,'SubjectConsanguinity':a.patientConsanguinity,
      'SubjectPopulationType':a.patientPopulationType,'SubjectPaternalAncestry':a.patientPaternalAncestry,'SubjectMaternalAncestry':a.patientMaternalAncestry,'SubjectFamilyHistory':a.patientFamilyHistory,
      'SubjectHasBioSample':a.patientHasBioSample,'SubjectUseConsentPersonal':a.patientUseConsentPersonal,'SubjectUseConsentClinical':a.patientUseConsentClinical,'SkipAnnotation':a.skipAnnotation}
    data={k:v for k,v in data.items() if v is not None and not (isinstance(v,str) and v.strip()=='')}
    if a.groupAssignmentCode and a.groupAssignmentName: data['GroupAssignment']=json.dumps([{'Code':a.groupAssignmentCode,'Name':a.groupAssignmentName}])
    files={}; opened=[]
    try:
        if a.snvVcf: opened.append(open(a.snvVcf,'rb')); files['snvFile']=opened[-1]
        if sv_path: opened.append(open(sv_path,'rb')); files['svFile']=opened[-1]
        api=config['server'].rstrip('/')+'/api/CreateSample'
        if a.dryRun:
            print(f'[DRY RUN] POST {api}'); print('Sample:',sample_id); print('Files:',{k:getattr(v,'name','') for k,v in files.items()}); return 0
        r=requests.post(api,data=data,files=files,timeout=3600); print(r); print(r.content.decode(errors='replace') if hasattr(r.content,'decode') else r.content); r.raise_for_status()
    finally:
        for f in opened: f.close()
    return 0
if __name__=='__main__':
    try: sys.exit(main())
    except Exception as e: print(f'[ERROR] {e}',file=sys.stderr); sys.exit(1)
