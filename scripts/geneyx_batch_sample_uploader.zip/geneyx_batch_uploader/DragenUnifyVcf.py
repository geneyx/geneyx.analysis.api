#!/usr/bin/env python3
import argparse
from UnifyVcf import run
if __name__ == '__main__':
    p=argparse.ArgumentParser(description='Unify DRAGEN structural VCF files')
    p.add_argument('-o','--outputPath',required=True); p.add_argument('-s','--svPath'); p.add_argument('-c','--cnvPath'); p.add_argument('-r','--repeatPath'); p.add_argument('-d','--roh')
    a=p.parse_args(); print(run(a.outputPath,a.svPath,a.cnvPath,a.repeatPath,roh_bed_path=a.roh,skip_svtype=False))
