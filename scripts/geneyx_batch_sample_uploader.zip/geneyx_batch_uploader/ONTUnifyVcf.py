#!/usr/bin/env python3
import argparse
from UnifyVcf import run
if __name__ == '__main__':
    p=argparse.ArgumentParser(description='Unify ONT structural VCF files')
    p.add_argument('-o','--outputPath',required=True); p.add_argument('-s','--svPath'); p.add_argument('-c','--cnvPath'); p.add_argument('-r','--repeatPath')
    p.add_argument('--modify-repeat', action='store_true', help='Add SVTYPE=REP (use for STRaglr-style repeat calls lacking recognized SVTYPE)')
    a=p.parse_args(); print(run(a.outputPath,a.svPath,a.cnvPath,a.repeatPath,skip_svtype=not a.modify_repeat))
