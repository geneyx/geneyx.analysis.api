#!/usr/bin/env python3
import argparse, os, shutil, subprocess, tempfile
from UnifyVcf import run

def filter_repeats(full_repeat_path: str, bed_path: str, output_path: str) -> str:
    if not os.path.exists(full_repeat_path): raise FileNotFoundError(full_repeat_path)
    if not os.path.exists(bed_path): raise FileNotFoundError(bed_path)
    if not shutil.which("bedtools"): raise RuntimeError("bedtools is required for PacBio repeat filtering")
    with open(output_path, "w", encoding="utf-8") as out:
        subprocess.run(["bedtools", "intersect", "-a", full_repeat_path, "-b", bed_path, "-header"], stdout=out, check=True, text=True)
    return output_path

def filter_and_run(output_path, sv_path=None, cnv_path=None, full_repeat_path=None, repeat_bed_file_path=None):
    filtered = None
    with tempfile.TemporaryDirectory(prefix="geneyx_pacbio_") as td:
        if full_repeat_path:
            if not repeat_bed_file_path:
                raise ValueError("PacBio repeat VCF supplied but no repeat BED file was provided")
            filtered = filter_repeats(full_repeat_path, repeat_bed_file_path, os.path.join(td, "repeats.filtered.vcf"))
        return run(output_path, sv_path, cnv_path, filtered, skip_svtype=False)

if __name__ == "__main__":
    p=argparse.ArgumentParser(description="Filter PacBio repeats against disease loci and unify structural VCFs")
    p.add_argument("-o","--outputPath",required=True); p.add_argument("-s","--svPath"); p.add_argument("-c","--cnvPath")
    p.add_argument("-r","--fullRepeatPath"); p.add_argument("-b","--repeatLocationsBedFilePath")
    a=p.parse_args(); print(filter_and_run(a.outputPath,a.svPath,a.cnvPath,a.fullRepeatPath,a.repeatLocationsBedFilePath))
