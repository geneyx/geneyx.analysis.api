#!/usr/bin/env python3
import argparse
import csv
import json
import os
import subprocess
import sys
from datetime import datetime
from typing import Dict, List, Any

# -----------------------------
# Helpers
# -----------------------------

def to_bool(s) -> bool:
    if s is None:
        return False
    s = str(s).strip().lower()
    return s in ("1", "true", "t", "yes", "y")

def to_float_or_none(s):
    if s is None:
        return None
    v = str(s).strip()
    if v == "":
        return None
    try:
        return float(v)
    except ValueError:
        raise ValueError(f"Invalid float value: {s}")

def clean_str(s):
    if s is None:
        return None
    v = str(s).strip()
    return v if v != "" else None

def tail(s: str, n: int = 1200) -> str:
    s = s or ""
    s = s.strip()
    return s[-n:] if len(s) > n else s

def require_cols(fieldnames, required: List[str], label: str):
    fns = fieldnames or []
    for col in required:
        if col not in fns:
            raise ValueError(f"{label} missing required column: {col}")

def now_utc_iso():
    return datetime.utcnow().isoformat() + "Z"

def write_json(path: str, data: Dict[str, Any]):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

# -----------------------------
# Load associated samples TSV
# -----------------------------

def load_associated_samples(path: str) -> Dict[str, List[Dict[str, Any]]]:
    """
    Returns dict: SerialNumber -> list of {Relation, SampleId, Affected}
    """
    assoc_by_case: Dict[str, List[Dict[str, Any]]] = {}

    if not path:
        return assoc_by_case
    if not os.path.exists(path):
        # Associated samples file is optional; if missing, treat as none.
        return assoc_by_case

    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f, delimiter="\t")
        require_cols(reader.fieldnames, ["SerialNumber", "Relation", "SampleId", "Affected"], "case_associated_samples.tsv")

        for row in reader:
            serial = clean_str(row.get("SerialNumber"))
            if not serial:
                continue

            relation = clean_str(row.get("Relation"))
            sample_id = clean_str(row.get("SampleId"))
            affected = clean_str(row.get("Affected"))

            # Skip incomplete lines
            if not (relation and sample_id and affected):
                continue

            assoc_by_case.setdefault(serial, []).append(
                {
                    "Relation": relation,
                    "SampleId": sample_id,   # expected to be sample serial number
                    "Affected": affected,
                }
            )

    return assoc_by_case

# -----------------------------
# Build CreateCase JSON
# -----------------------------

def build_case_payload(row: Dict[str, str], assoc: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Builds a CreateCase payload from a manifest row + associated samples.
    Omits empty fields.
    Applies correct types for boolean/float fields.
    """
    payload: Dict[str, Any] = {}

    # String fields (omit if empty)
    string_fields = [
        "SerialNumber",
        "Name",
        "Description",
        "Phenotypes",
        "Owner",
        "OwnerDepartment",
        "GeneList",
        "GenePanelId",
        "ProtocolId",
        "SubjectId",
        "ProbandSampleId",
        "AssignedToUserId",
        "AssignedToFullName",
    ]

    for k in string_fields:
        v = clean_str(row.get(k))
        if v is not None:
            payload[k] = v

    # PhenAlleleFreq: nullable-double
    phen_af = to_float_or_none(row.get("PhenAlleleFreq"))
    if phen_af is not None:
        payload["PhenAlleleFreq"] = phen_af

    # ConcatSubjectPhenotypes: boolean
    csp = row.get("ConcatSubjectPhenotypes")
    if clean_str(csp) is not None:
        payload["ConcatSubjectPhenotypes"] = to_bool(csp)

    # Optional: PhenotypesFormat is not part of JSON schema you pasted,
    # but you may keep it in manifest for human clarity; we ignore it here.

    # Associated samples
    if assoc:
        payload["AssociatedSamples"] = assoc

    return payload

# -----------------------------
# Main
# -----------------------------

def main():
    ap = argparse.ArgumentParser(description="Batch create Geneyx cases from case_manifest.tsv + case_associated_samples.tsv")
    ap.add_argument("--case-manifest", default="case_manifest.tsv", help="Path to case manifest TSV")
    ap.add_argument("--associated-samples", default="case_associated_samples.tsv",
                    help="Path to associated samples TSV (optional). If missing, no associated samples will be attached.")
    ap.add_argument("--config", default="ga.config.yml", help="Path to ga.config.yml")
    ap.add_argument("--creator", default="ga_createCase.py", help="Path to ga_createCase.py")
    ap.add_argument("--python", default="python3", help="Python executable to use (python3 or python)")
    ap.add_argument("--temp-dir", default="tmp_cases", help="Directory to write temporary JSON files")
    ap.add_argument("--log", default="case_results.csv", help="CSV log output")
    ap.add_argument("--stop-on-fail", action="store_true", help="Stop batch on first failure")
    ap.add_argument("--dry-run", action="store_true", help="Print commands and payload preview; do not create cases")
    args = ap.parse_args()

    if not os.path.exists(args.case_manifest):
        print(f"Case manifest not found: {args.case_manifest}", file=sys.stderr)
        sys.exit(2)

    os.makedirs(args.temp_dir, exist_ok=True)

    assoc_by_case = load_associated_samples(args.associated_samples)

    log_exists = os.path.exists(args.log)
    with open(args.log, "a", newline="", encoding="utf-8") as logf:
        logw = csv.DictWriter(
            logf,
            fieldnames=[
                "timestamp",
                "SerialNumber",
                "SubjectId",
                "ProbandSampleId",
                "ProtocolId",
                "associated_count",
                "returncode",
                "status",
                "stdout_tail",
                "stderr_tail",
                "json_path",
            ],
        )
        if not log_exists:
            logw.writeheader()

        with open(args.case_manifest, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f, delimiter="\t")
            require_cols(reader.fieldnames, ["ProtocolId", "SubjectId", "ProbandSampleId"], "case_manifest.tsv")

            for i, row in enumerate(reader, start=1):
                protocol_id = clean_str(row.get("ProtocolId"))
                subject_id = clean_str(row.get("SubjectId"))
                proband_sample_id = clean_str(row.get("ProbandSampleId"))
                serial = clean_str(row.get("SerialNumber")) or f"ROW_{i}"

                # Skip blank-ish lines
                if not protocol_id and not subject_id and not proband_sample_id:
                    continue

                try:
                    # Validate required fields
                    if not protocol_id:
                        raise ValueError("Missing required field ProtocolId")
                    if not subject_id:
                        raise ValueError("Missing required field SubjectId")
                    if not proband_sample_id:
                        raise ValueError("Missing required field ProbandSampleId")

                    assoc_list = assoc_by_case.get(clean_str(row.get("SerialNumber")) or "", [])
                    payload = build_case_payload(row, assoc_list)

                    json_path = os.path.join(args.temp_dir, f"case_{serial}.json".replace(os.sep, "_"))
                    write_json(json_path, payload)

                    cmd = [args.python, args.creator, "--config", args.config, "--data", json_path, "--quiet"]

                    print(f"\n[{i}] Creating case SerialNumber={payload.get('SerialNumber', serial)} SubjectId={subject_id} ProbandSampleId={proband_sample_id}")
                    if args.dry_run:
                        print("DRY RUN command:", " ".join(cmd))
                        print("DRY RUN payload preview:", json.dumps(payload, indent=2)[:1200] + ("..." if len(json.dumps(payload)) > 1200 else ""))
                        logw.writerow(
                            {
                                "timestamp": now_utc_iso(),
                                "SerialNumber": payload.get("SerialNumber", serial),
                                "SubjectId": subject_id,
                                "ProbandSampleId": proband_sample_id,
                                "ProtocolId": protocol_id,
                                "associated_count": len(assoc_list),
                                "returncode": 0,
                                "status": "DRY_RUN",
                                "stdout_tail": "",
                                "stderr_tail": "",
                                "json_path": json_path,
                            }
                        )
                        logf.flush()
                        continue

                    p = subprocess.run(cmd, capture_output=True, text=True)
                    stdout = (p.stdout or "").strip()
                    stderr = (p.stderr or "").strip()

                    status = "SUCCESS" if p.returncode == 0 else "FAIL"

                    logw.writerow(
                        {
                            "timestamp": now_utc_iso(),
                            "SerialNumber": payload.get("SerialNumber", serial),
                            "SubjectId": subject_id,
                            "ProbandSampleId": proband_sample_id,
                            "ProtocolId": protocol_id,
                            "associated_count": len(assoc_list),
                            "returncode": p.returncode,
                            "status": status,
                            "stdout_tail": tail(stdout),
                            "stderr_tail": tail(stderr),
                            "json_path": json_path,
                        }
                    )
                    logf.flush()

                    if stdout:
                        print(stdout)
                    if stderr:
                        print(stderr, file=sys.stderr)

                    if p.returncode != 0 and args.stop_on_fail:
                        print("Stopping on first failure (--stop-on-fail).", file=sys.stderr)
                        sys.exit(p.returncode)

                except Exception as e:
                    # Log manifest/validation/build errors
                    logw.writerow(
                        {
                            "timestamp": now_utc_iso(),
                            "SerialNumber": clean_str(row.get("SerialNumber")) or f"ROW_{i}",
                            "SubjectId": subject_id or "",
                            "ProbandSampleId": proband_sample_id or "",
                            "ProtocolId": protocol_id or "",
                            "associated_count": len(assoc_by_case.get(clean_str(row.get("SerialNumber")) or "", [])),
                            "returncode": 99,
                            "status": "FAIL",
                            "stdout_tail": "",
                            "stderr_tail": str(e),
                            "json_path": "",
                        }
                    )
                    logf.flush()
                    print(f"[{i}] FAIL SerialNumber={serial} — {e}", file=sys.stderr)
                    if args.stop_on_fail:
                        sys.exit(99)

    print(f"\nDone. Results log: {args.log}")


if __name__ == "__main__":
    main()
