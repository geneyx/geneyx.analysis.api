Geneyx Batch Case Creator

This tool enables batch creation of Geneyx cases using TSV manifests and the existing ga_createCase.py script.

It supports:

Proband-only cases

Trio cases (proband + parents) at creation time

A clean, repeatable, manifest-driven workflow

Optional quiet console output

CSV logging of results

⚠️ Adding associated samples after case creation is intentionally out of scope.

Files in This Package
File	Purpose
batch_create_cases.py	Main batch runner
case_manifest.tsv	Case-level manifest (one row per case)
case_associated_samples.tsv	Optional associated samples (0+ rows per case)
ga_createCase.py	Geneyx case creation script
ga.config.yml	API credentials & environment config
case_results.csv	Auto-generated results log
tmp_cases/	Auto-generated per-case JSON payloads
Requirements

Python 3.8+

Same environment and dependencies required by ga_createCase.py

Access to the Geneyx Analysis API

Samples must already exist in Geneyx (uploaded beforehand)

Quick Start
python3 batch_create_cases.py \
  --case-manifest case_manifest.tsv \
  --config ga.config.yml \
  --creator ga_createCase.py \
  --quiet

Optional Flags
Flag	Description
--associated-samples case_associated_samples.tsv	Attach mother/father at creation time
--quiet	Clean one-line output per case
--dry-run	Print payloads and commands without creating cases
--stop-on-fail	Stop batch on first failure
--log case_results.csv	Output log file (default: case_results.csv)
Manifest Files
1️⃣ case_manifest.tsv (Required)

One row per case

Delimiter: TAB (not commas)

Required Columns

These columns must exist in the header (values may not be empty):

ProtocolId

SubjectId

ProbandSampleId

Full Supported Columns
SerialNumber
Name
Description
PhenAlleleFreq
Phenotypes
PhenotypesFormat
ConcatSubjectPhenotypes
Owner
OwnerDepartment
GeneList
GenePanelId
ProtocolId
SubjectId
ProbandSampleId
AssignedToUserId
AssignedToFullName


Empty fields are skipped automatically.

Example (Proband-only)
SerialNumber	Name	Description	PhenAlleleFreq	Phenotypes	PhenotypesFormat	ConcatSubjectPhenotypes	Owner	OwnerDepartment	GeneList	ProtocolId	SubjectId	ProbandSampleId
CASE_001	Case CASE_001	Proband WGS case	0.01	HP:0000189,HP:0000219	HPO	true	Eli Sward	Genetics	SCN1A,STXBP1	RG_SINGLE	P1234567	S1234567

2️⃣ case_associated_samples.tsv (Optional)

Attach associated samples during case creation (e.g., trio).

Delimiter: TAB

Required Columns
SerialNumber
Relation
SampleId
Affected


SerialNumber: must match case_manifest.tsv

SampleId: sample serial number (not GUID)

Relation: Mother, Father, Sibling, etc.

Affected: Affected, Unaffected, or Unknown

Example (Trio)
SerialNumber	Relation	SampleId	Affected
CASE_TRIO_001	Mother	S1234568	Unaffected
CASE_TRIO_001	Father	S1234569	Unaffected


If a case has no associated samples yet, omit it from this file.

Trio Case Behavior (Important)

The proband is always specified by ProbandSampleId

Parents go into AssociatedSamples

All samples must already exist in Geneyx

Trio is determined automatically when Mother/Father are present

Output & Logging
Console Output (Quiet Mode)
SUCCESS CreateCase serial=CASE_001 subject=P1234567 proband=S1234567 http=200


Only failures or summaries are printed.

case_results.csv

Each case attempt is logged with:

Column	Description
timestamp	UTC timestamp
SerialNumber	Case serial number
SubjectId	Patient ID
ProbandSampleId	Proband sample
ProtocolId	Protocol used
associated_count	Number of associated samples
returncode	Exit code
status	SUCCESS / FAIL / DRY_RUN
stdout_tail	Last uploader output
stderr_tail	Error details
json_path	Path to generated JSON
Recommended Workflow

Upload all samples first (proband + parents if applicable)

Create case_manifest.tsv

(Optional) Create case_associated_samples.tsv

Run batch in --dry-run mode

Run real batch with --quiet

Review case_results.csv

Re-run failed rows only if needed

Common Issues
❌ “Missing required field”

Ensure ProtocolId, SubjectId, and ProbandSampleId are present

❌ Case created but not a trio

Ensure Mother/Father rows exist at creation time

Ensure SampleId values are correct sample serial numbers

❌ No annotation triggered

Check protocol settings

Ensure samples are fully annotated before case creation if required

Out of Scope (By Design)

Adding associated samples to existing cases

Case updates after creation

Parallel uploads

Automatic retries

These can be added later if needed.

Support

For Geneyx API behavior, protocol configuration, or account-specific questions, contact your Geneyx representative.