#!/usr/bin/env python3
import argparse
import json
import requests
import ga_helperFunctions as funcs

def _verifyRequiredFields(data):
    funcs.verifyFieldInData('ProtocolId', data)
    funcs.verifyFieldInData('SubjectId', data)
    funcs.verifyFieldInData('ProbandSampleId', data)

def _mask(s: str, keep: int = 4) -> str:
    if not s:
        return s
    s = str(s)
    if len(s) <= keep:
        return "*" * len(s)
    return "*" * (len(s) - keep) + s[-keep:]

def main():
    parser = argparse.ArgumentParser(prog='ga_createCase.py', description='Creates a case on Geneyx Analysis')
    parser.add_argument('--data','-d', help='data JSON file', default=r'templates\case.json')
    parser.add_argument('--config','-c', help='configuration file', default='ga.config.yml')
    parser.add_argument('--quiet', action='store_true', help='Only print a one-line success/fail summary')
    parser.add_argument('--print-response-json', action='store_true', help='Print parsed JSON response (pretty) on success')
    args = parser.parse_args()

    config = funcs.loadYamlFile(args.config)

    data = funcs.loadDataJson(args.data)
    _verifyRequiredFields(data)

    # add user connection fields
    data['ApiUserKey'] = config['apiUserKey']
    data['ApiUserID'] = config['apiUserId']

    api = config['server'] + '/api/CreateCase'

    try:
        r = requests.post(api, json=data)
        ok = (r.status_code == 200)

        # Try to parse JSON
        resp_json = None
        try:
            resp_json = r.json()
        except Exception:
            resp_json = None

        # QUIET mode: only one line
        if args.quiet:
            serial = data.get("SerialNumber") or data.get("Name") or "(no-serial)"
            subj = data.get("SubjectId") or "(no-subject)"
            prob = data.get("ProbandSampleId") or "(no-proband)"
            if ok:
                # If response includes returned SerialNumber, show it
                returned = None
                if isinstance(resp_json, dict):
                    returned = (resp_json.get("Data") or {}).get("SerialNumber")
                returned_txt = f" returnedSerial={returned}" if returned else ""
                print(f"SUCCESS CreateCase serial={serial}{returned_txt} subject={subj} proband={prob} http={r.status_code}")
                if args.print_response_json and resp_json is not None:
                    print(json.dumps(resp_json, indent=2))
                return 0
            else:
                body_tail = (r.text or "")[-600:]
                print(f"FAIL CreateCase serial={serial} subject={subj} proband={prob} http={r.status_code} body_tail={body_tail!r}")
                return 1

        # Non-quiet: still keep safe (no keys)
        safe_cfg = dict(config)
        safe_cfg["apiUserId"] = _mask(safe_cfg.get("apiUserId"))
        safe_cfg["apiUserKey"] = _mask(safe_cfg.get("apiUserKey"))
        print("Config:", safe_cfg)

        safe_data = dict(data)
        safe_data["ApiUserID"] = _mask(safe_data.get("ApiUserID"))
        safe_data["ApiUserKey"] = _mask(safe_data.get("ApiUserKey"))
        print("Payload:", safe_data)

        print("Creating case")
        print("HTTP:", r.status_code)

        if resp_json is not None:
            print(json.dumps(resp_json, indent=2))
        else:
            print(r.text)

        return 0 if ok else 1

    except Exception as e:
        if args.quiet:
            serial = data.get("SerialNumber") or "(no-serial)"
            print(f"FAIL CreateCase serial={serial} error={e}")
            return 1
        raise

if __name__ == "__main__":
    raise SystemExit(main())
