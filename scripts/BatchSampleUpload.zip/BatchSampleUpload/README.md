# Geneyx Batch Sample Upload

This repository contains the necessary files and instructions for uploading multiple samples to Geneyx Analysis via API.

## 📁 Files

- **`BatchSampleJSON.json`**  
  Contains sample information in JSON format for batch upload.  
  → For a full list of supported API fields, please contact support@geneyx.com.

- **`JSON_Sample_Upload.py`**  
  The main Python script that reads the sample JSON file and performs the upload.

- **`ga_helperFunctions.py`**  
  A helper module used by the main script to manage configuration and utility functions.

- **`ga.config.yml`**  
  Configuration file that stores your API credentials and other upload settings.

---

## 📦 Prerequisites

Ensure you have the following installed on your system:

- Python 3.x
- Required Python modules: `requests`, `pyyaml`
- Valid `ga.config.yml` with your Geneyx API credentials

---

## 🚀 Steps to Upload Samples

1. **Place All Required Files in the Same Directory**

   Ensure the following files are in the same folder as `JSON_Sample_Upload.py`:


2. **Run the Upload Script**

Open a terminal and execute:

```bash
python3 JSON_Sample_Upload.py --jsonFile BatchSampleJSON.json 


If you do not have access to the required credentials, please contact support@geneyx.com or your local Geneyx FAS representative.


