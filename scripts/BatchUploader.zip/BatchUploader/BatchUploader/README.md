# Trio Uploader - Combined Sample & Case Upload

This script automates uploading SNV/SV/CNV files for probands and associated family samples (e.g., parents in a trio) to Geneyx Analysis and then creates a case.

---

## 🧠 Features
- Uploads SNV, SV, and CNV files
- Supports automatic SV+CNV merging
- Handles both .vcf and .vcf.gz
- Windows-compatible (no zcat required)
- Handles trio structure (Proband, Mother, Father)
- Automatically creates Geneyx cases with full trio linkage

---

## 📁 JSON Format

### 🔷 TRIO CASE
```json
{
  "sampleSerialNumber": "Proband001",
  "SubjectId": "Proband001",
  "snvVcf": "path/to/proband.snv.vcf",
  "svVcf": "path/to/proband.sv.vcf",
  "cnvVcf": "path/to/proband.cnv.vcf",
  "ProtocolId": "RG_TRIO",
  "genomeBuild": "hg38",
  "Phenotypes": "HP:0001250,HP:0004322",
  "patientGender": "F",
  "AssociatedSamples": [
    {
      "Relation": "Mother",
      "SampleId": "Mother001",
      "snvVcf": "path/to/mother.snv.vcf",
      "svVcf": "path/to/mother.sv.vcf",
      "cnvVcf": "path/to/mother.cnv.vcf",
      "Affected": "Unaffected"
    },
    {
      "Relation": "Father",
      "SampleId": "Father001",
      "snvVcf": "path/to/father.snv.vcf",
      "svVcf": "path/to/father.sv.vcf",
      "cnvVcf": "path/to/father.cnv.vcf",
      "Affected": "Unaffected",
    }
  ]
}
```

### 🔹 SINGLETON CASE
```json
{
  "sampleSerialNumber": "Sample001",
  "SubjectId": "Sample001",
  "snvVcf": "path/to/sample001.snv.vcf",
  "svVcf": "path/to/sample001.sv.vcf",
  "cnvVcf": "path/to/sample001.cnv.vcf",
  "ProtocolId": "RG_SNV_SV",
  "genomeBuild": "hg38",
  "Phenotypes": "HP:0000189,HP:0000219",
  "patientGender": "M"
}
```

---

## ⚙️ Run the script

```bash
python BatchImporter.py --json CombinedSample.json --config ga.config.yml
```

---

## 📌 Notes
- If `svVcf` and `cnvVcf` are both present, they will be combined.
- Both `.vcf` and `.vcf.gz` formats are supported.
- For associated samples, SNV, SV, and CNV are supported.
- The gender field is optional, must be "M" or "F" if provided.
- The `sampleTarget` is optional. If omitted, defaults to `"Exome"`.
- Trio linkage is now handled explicitly when creating the case.
- Protocol ID used during case creation is displayed after success:
  ```
  ✅ Case creation succeeded. Protocol used: RG_TRIO
  ```

---

## ✅ Requirements

### 🔧 Software
- **Python 3.7+**
- Modules:
  - `requests`
  - `pyyaml` *(only if using `ga_helperFunctions.py` to load config)*
- Recommended: `virtualenv` to manage dependencies

### 📂 File Format Expectations
- Input files must be in `.vcf` or `.vcf.gz` format
- SV and CNV VCFs must be valid and gzip-compressed if ending in `.gz`
- File paths in JSON must be valid relative or absolute paths on your system

### 📄 Config File (`ga.config.yml`)
This must include:
```yaml
server: "https://your.geneyx.server"
apiUserKey: "your-api-key"
apiUserId: "your-api-user-id"
```

### 🔑 JSON Input Rules
- `sampleSerialNumber` and `SubjectId` must be unique per sample
- `ProtocolId` must be a valid protocol for your account (e.g., `RG_TRIO`, `RG_SNV_SV`)
- `Phenotypes` should be comma-separated HPO terms
- `sampleTarget` is optional but defaults to `"Exome"` if omitted
- For trio cases, `AssociatedSamples` must include at least one parent with `"Relation"` and `"SampleId"`

---