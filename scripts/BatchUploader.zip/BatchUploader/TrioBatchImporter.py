#!/usr/bin/env python3
import argparse
import os
import requests
import ntpath
import json
import ga_helperFunctions as funcs
import time

# Define the command line parameters
parser = argparse.ArgumentParser(prog='ga_uploadAndCreateCase.py', description='Uploads samples and creates cases in Geneyx Analysis from a combined JSON file')
parser.add_argument('--json', help='Path to the combined sample+case JSON file', required=True)
parser.add_argument('--config', '-c', help='Configuration file', default='ga.config.yml')
args = parser.parse_args()

# Read the config file
config = funcs.loadYamlFile(args.config)

def verify_case_fields(data):
    funcs.verifyFieldInData('ProtocolId', data)
    funcs.verifyFieldInData('SubjectId', data)
    if 'ProbandSampleId' not in data:
        if 'sampleSerialNumber' in data:
            data['ProbandSampleId'] = data['sampleSerialNumber']
        else:
            raise ValueError("Missing required field: ProbandSampleId or sampleSerialNumber")

def process_entry(entry, skip_case_creation=False):
    snvVcf = entry['snvVcf']
    svVcf = entry.get('svVcf')
    cnvVcf = entry.get('cnvVcf')

    if not svVcf and cnvVcf:
        svVcf = cnvVcf
    genomeBuild = entry.get('genomeBuild', 'hg19')
    subjectId = entry['SubjectId']

    if not os.path.exists(snvVcf):
        raise Exception(f"The file {snvVcf} does not exist")
    if svVcf and not os.path.exists(svVcf):
        raise Exception(f"The file {svVcf} does not exist")
    if cnvVcf and not os.path.exists(cnvVcf):
        raise Exception(f"The file {cnvVcf} does not exist")

    if svVcf and cnvVcf:
        combinedFile = svVcf.split('.vcf')[0] + '.combined.vcf'
        print(f'Combining SV and CNV files into {combinedFile}')
        os.system(f'zcat -f {svVcf} | grep "^#" > {combinedFile}')
        os.system(f'zcat -f {svVcf} | grep -v "^#" >> {combinedFile}')
        os.system(f'zcat -f {cnvVcf} | grep -v "^#" >> {combinedFile}')
        svVcf = combinedFile

    sampleId = entry.get('sampleSerialNumber', ntpath.basename(snvVcf))
    snvBaseName = ntpath.basename(snvVcf)
    svBaseName = ntpath.basename(svVcf) if svVcf else None

    sample_payload = {
        'ApiUserKey': config['apiUserKey'],
        'ApiUserID': config['apiUserId'],
        'CustomerAccountKey': entry.get('customerAccountKey', ''),
        'SampleSerialNumber': sampleId,
        'SampleSequenceDate': entry.get('sampleSequenceDate', ''),
        'SampleTakenDate': entry.get('sampleTakenDate', ''),
        'SampleReceivedDate': entry.get('sampleReceiveDate', ''),
        'SampleType': entry.get('sampleType', 'DnaSeq'),
        'SampleTarget': entry.get('sampleTarget', 'Exome'),
        'SampleSource': entry.get('sampleSource', 'GermLine'),
        'SampleSequenceMachineId': entry.get('seqMachineId', ''),
        'SampleEnrichmentKitId': entry.get('kitId', ''),
        'SampleGenomeBuild': genomeBuild,
        'SampleNotes': entry.get('sampleNotes', ''),
        'SampleRelation': entry.get('sampleRelation', 'Self'),
        'sampleQcData': entry.get('sampleQcData', ''),
        'ExcludeFromLAF': entry.get('excludeFromLAF', False),
        'bamUrl': entry.get('bamUrl', ''),
        'methylationUrl': entry.get('methylationUrl', ''),
        'SnvFile': snvBaseName,
        'StructFile': svBaseName,
        'SubjectId': subjectId,
        'SubjectName': entry.get('patientName', ''),
        'SubjectGender': entry.get('patientGender', '')[:1] if entry.get('patientGender') else '',
        'SubjectDateOfBirth': entry.get('patientDateOfBirth', ''),
        'SubjectConsanguinity': entry.get('patientConsanguinity', ''),
        'SubjectPopulationType': entry.get('patientPopulationType', ''),
        'SubjectPaternalAncestry': entry.get('patientPaternalAncestry', ''),
        'SubjectMaternalAncestry': entry.get('patientMaternalAncestry', ''),
        'SubjectFamilyHistory': entry.get('patientFamilyHistory', ''),
        'SubjectHasBioSample': entry.get('patientHasBioSample', ''),
        'SubjectUseConsentPersonal': entry.get('patientUseConsentPersonal', ''),
        'SubjectUseConsentClinical': entry.get('patientUseConsentClinical', ''),
        'SkipAnnotation': entry.get('skipAnnotation', False)
    }

    if entry.get('groupAssignmentCode') and entry.get('groupAssignmentName'):
        sample_payload['GroupAssignment'] = [{'Code': entry['groupAssignmentCode'], 'Name': entry['groupAssignmentName']}]

    files = {'snvFile': open(snvVcf, "rb")}
    if svVcf:
        files['svFile'] = open(svVcf, "rb")

    sample_api = config['server'] + '/api/CreateSample'
    print(f'Uploading sample {sampleId}')
    start_time = time.time()
    r = requests.post(sample_api, data=sample_payload, files=files)
    upload_time = time.time() - start_time
    print(f'Time taken to upload sample {sampleId}: {upload_time:.2f} seconds')
    print(r)
    print(r.content)

    if skip_case_creation:
        return

    verify_case_fields(entry)
    case_payload = {
        "ApiUserKey": config['apiUserKey'],
        "ApiUserID": config['apiUserId'],
        "ProtocolId": entry['ProtocolId'],
        "SubjectId": entry['SubjectId'],
        "ProbandSampleId": entry['ProbandSampleId'],
        "Phenotypes": entry.get('Phenotypes', ''),
        "Description": entry.get('Description', ''),
        "ConcatSubjectPhenotypes": entry.get('ConcatSubjectPhenotypes', False),
        "AssociatedSamples": []
    }

    for assoc in entry.get('AssociatedSamples', []):
        assoc_sample_id = assoc.get('SampleId')
        if not any(e.get('sampleSerialNumber') == assoc_sample_id for e in entries):
            assoc_vcf_path = assoc.get('snvVcf')
            assoc_sv_path = assoc.get('svVcf')
            if assoc_vcf_path and os.path.exists(assoc_vcf_path):
                print(f"Uploading associated sample {assoc_sample_id} from {assoc_vcf_path}...")
                assoc_entry = {
                    'sampleSerialNumber': assoc_sample_id,
                    'SubjectId': assoc.get('SubjectId', assoc_sample_id),
                    'snvVcf': assoc_vcf_path,
                    'svVcf': assoc_sv_path,
                    'patientGender': assoc.get('Gender', '')[:1] if assoc.get('Gender') else '',
                    'sampleTarget': 'Exome',
                    'sampleType': 'DnaSeq'
                }
                process_entry(assoc_entry, skip_case_creation=True)
            else:
                print(f"⚠️ Warning: Associated sample {assoc_sample_id} not found in uploaded entries and no VCF path provided.")
        case_payload['AssociatedSamples'].append(assoc)

    case_api = config['server'] + '/api/CreateCase'
    print('Creating case...')
    r = requests.post(case_api, json=case_payload)

    try:
        r.raise_for_status()
        response_json = r.json()
        if response_json.get("Success", False) or response_json.get("Code", "").lower() == "success":
            print("✅ Case creation succeeded.")
        else:
            print("❌ Case creation failed:", response_json.get("Message", "No message provided."))
    except requests.HTTPError as http_err:
        print(f"❌ HTTP error occurred: {http_err}")
        print(f"Response content: {r.text}")
    except ValueError:
        print("⚠️ Response is not valid JSON:")
        print(r.text)
    except Exception as err:
        print(f"⚠️ Unexpected error: {err}")

with open(args.json, 'r') as f:
    entries = json.load(f)['entries']
for entry in entries:
    process_entry(entry)
