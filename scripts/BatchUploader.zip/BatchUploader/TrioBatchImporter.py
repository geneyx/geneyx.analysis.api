import os, json, gzip, argparse, requests
import ga_helperFunctions as funcs

def open_file_auto(path):
    return gzip.open(path, 'rt') if path.endswith('.gz') else open(path, 'r')

def merge_sv_cnv(sv_path, cnv_path, output_path):
    with gzip.open(output_path, 'wt') as out:
        for path in [sv_path, cnv_path]:
            with open_file_auto(path) as f:
                for line in f:
                    if not line.startswith('#') or path == sv_path:
                        out.write(line)

def upload_sample(sample, config):
    snv = sample['snvVcf']
    sv = sample.get('svVcf')
    cnv = sample.get('cnvVcf')

    if sv and cnv:
        merged_path = sv.replace('.sv.vcf', '.sv.combined.vcf.gz').replace('.vcf.gz', '.combined.vcf.gz')
        merge_sv_cnv(sv, cnv, merged_path)
        sv = merged_path

    files = {'snvFile': open(snv, 'rb')}
    if sv: files['svFile'] = open(sv, 'rb')

    data = {
        'ApiUserKey': config['apiUserKey'],
        'ApiUserID': config['apiUserId'],
        'CustomerAccountKey': sample.get('customerAccountKey', ''),
        'SampleSerialNumber': sample['sampleSerialNumber'],
        'SampleTarget': sample.get('sampleTarget', 'Exome'),
        'SampleGenomeBuild': sample['genomeBuild'],
        'SnvFile': os.path.basename(snv),
        'StructFile': os.path.basename(sv) if sv else '',
        'SubjectId': sample['SubjectId'],
        'Phenotypes': sample.get('Phenotypes', ''),
        'SubjectGender': sample.get('patientGender', '')
    }

    print(f"Uploading sample {sample['sampleSerialNumber']}")
    r = requests.post(config['server'] + '/api/CreateSample', data=data, files=files)
    print(r)
    print(r.content)
    return sample['sampleSerialNumber']

def create_case_with_family(proband_id, protocol, phenotypes, associated_samples, config):
    case_data = {
        'ApiUserKey': config['apiUserKey'],
        'ApiUserID': config['apiUserId'],
        'ProbandSampleId': proband_id,
        'SubjectId': proband_id,
        'ProtocolId': protocol,
        'Phenotypes': phenotypes,
        'AssociatedSamples': [
            {
                'Relation': s['Relation'],
                'SampleId': s['SampleId'],
                'Affected': s.get('Affected', 'Unaffected')
            } for s in associated_samples
        ]
    }
    print("Creating case with trio linkage...")
    r = requests.post(config['server'] + '/api/CreateCase', json=case_data)
    try:
        r.raise_for_status()
        print(f"✅ Case creation succeeded. Protocol used: {protocol}")
    except:
        print("❌ Case creation failed:", r.text)

def process_entry(entry, config):
    sample_id = upload_sample(entry, config)
    assoc_samples = entry.get('AssociatedSamples', [])
    for assoc in assoc_samples:
        upload_sample({
            **assoc,
            'SubjectId': assoc['SampleId'],
            'sampleSerialNumber': assoc['SampleId'],
            'genomeBuild': entry['genomeBuild'],
            'ProtocolId': entry['ProtocolId'],
            'Phenotypes': entry.get('Phenotypes', ''),
            'sampleTarget': assoc.get('sampleTarget', 'Exome')
        }, config)
    create_case_with_family(sample_id, entry['ProtocolId'], entry.get('Phenotypes', ''), assoc_samples, config)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--json', required=True)
    parser.add_argument('--config', default='ga.config.yml')
    args = parser.parse_args()

    config = funcs.loadYamlFile(args.config)
    with open(args.json, 'r') as f:
        data = json.load(f)['entries']
    for entry in data:
        process_entry(entry, config)