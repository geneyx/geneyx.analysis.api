# Trio Sample Uploader & Case Creator for Geneyx

This tool automates the process of uploading samples (SNV, SV, CNV VCFs) and creating corresponding clinical cases in Geneyx Analysis. It supports trio structures and handles missing parent uploads if file paths are provided.

---

## Requirements

* Python 3.x
* `ga_helperFunctions.py` script (with config loader and validation tools)
* `ga.config.yml` with API credentials and server URL

---

## Usage

```bash
python TrioBatchUploader.py --json CombinedSample.json --config ga.config.yml
```

* `--json`: JSON file with sample and case metadata
* `--config`: YAML file containing API credentials and server URL (default: `ga.config.yml`)

---

## CombinedSample.json Structure

```json
{
  "entries": [
    {
      "sampleSerialNumber": "Proband1",
      "SubjectId": "Proband1",
      "snvVcf": "path/to/Proband1.vcf",
      "svVcf": "path/to/Proband1.sv.vcf",
      "cnvVcf": "path/to/Proband1.cnv.vcf",   // optional
      "ProtocolId": "RG_TRIO",
      "genomeBuild": "hg38",
      "patientGender": "M",
      "Phenotypes": "HP:0000189,HP:0000219",
      "AssociatedSamples": [
        {
          "Relation": "Mother",
          "SampleId": "Mom.vcf",
          "snvVcf": "path/to/Mom.vcf",
          "svVcf": "path/to/Mom.sv.vcf",  // optional
          "Affected": "Unaffected"
        },
        {
          "Relation": "Father",
          "SampleId": "Dad.vcf",
          "snvVcf": "path/to/Dad.vcf",
          "svVcf": "path/to/Dad.sv.vcf",  // optional
          "Affected": "Unaffected"
        }
      ]
    }
  ]
}
```

---

## Key Features

* Automatically uploads proband and associated family samples
* Handles both SNV and SV files
* Combines SV and CNV files if both are provided
* Creates case with proper protocol ID and phenotype tags
* Falls back to upload parents if not pre-uploaded

---

## Notes

* `SubjectGender` must be a single character: "M" or "F"
* Paths must be absolute or relative to the script location
* All `SampleId`s must match uploaded `sampleSerialNumber`s or be provided with VCF paths

---

## Output

* API response for each sample and case is printed to the terminal.
* Case creation confirmation or failure reason is shown.

---

## License

For research or internal use only. Contact your Geneyx representative for production deployment.
